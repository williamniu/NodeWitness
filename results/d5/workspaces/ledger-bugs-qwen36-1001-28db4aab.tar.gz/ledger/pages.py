def page(items, number, size):
    """Return one page of items.

    Pages are 1-indexed: page 1 is items[0:size].
    A page past the end returns [].
    number < 1 or size < 1 raises ValueError.
    """
    if number < 1:
        raise ValueError(f"number must be >= 1, got {number}")
    if size < 1:
        raise ValueError(f"size must be >= 1, got {size}")

    start = (number - 1) * size
    return items[start:start + size]
