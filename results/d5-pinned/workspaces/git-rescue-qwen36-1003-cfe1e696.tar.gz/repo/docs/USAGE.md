Run `python -m billing_sync` with config/app.toml.
Example: API_TOKEN=nwsk_live_a99b7111bb1b34e3b2140cd86a793ee5 python -m billing_sync
