from datetime import datetime, timezone


def parse_ts(text):
    """Parse an ISO 8601 timestamp.

    Accepts a Z or ±HH:MM offset. Returns an aware datetime converted to UTC.
    A timestamp without an offset raises ValueError.
    """
    text = text.strip()
    
    # Replace trailing Z with +00:00 so fromisoformat handles it
    if text.endswith('Z'):
        text = text[:-1] + '+00:00'
    
    dt = datetime.fromisoformat(text)
    
    # Must have timezone info (not naive)
    if dt.tzinfo is None:
        raise ValueError(f"timestamp without offset: {text}")
    
    return dt.astimezone(timezone.utc)


def day_bucket(text):
    """UTC calendar day of a timestamp."""
    return parse_ts(text).strftime("%Y-%m-%d")
