import sys, os, re, gzip, json, math, zlib
from datetime import datetime, timezone, tzinfo, timedelta

class FixedOffset(tzinfo):
    def __init__(self, offset_minutes):
        self._offset = timedelta(minutes=offset_minutes)
    def utcoffset(self, dt):
        return self._offset
    def tzname(self, dt):
        return ""
    def dst(self, dt):
        return None

def parse_ts(s):
    """Parse ISO 8601 timestamp to a datetime in UTC."""
    s = s.strip()
    if s.endswith('Z'):
        s = s[:-1] + '+00:00'
    
    m = re.match(r'(.+?)([+-])(\d{2}):?(\d{2})$', s)
    if not m:
        return None
    
    base_str, sign, hh, mm = m.groups()
    offset_minutes = int(hh) * 60 + int(mm)
    if sign == '-':
        offset_minutes = -offset_minutes
    tz = FixedOffset(offset_minutes)
    
    for fmt in ('%Y-%m-%dT%H:%M:%S.%f', '%Y-%m-%dT%H:%M:%S'):
        try:
            dt = datetime.strptime(base_str, fmt).replace(tzinfo=tz)
            return dt.astimezone(timezone.utc)
        except ValueError:
            continue
    return None

def parse_json_line(line):
    """Try parsing a JSON log line."""
    try:
        obj = json.loads(line)
    except (json.JSONDecodeError, ValueError):
        return None
    
    ts_raw = obj.get('ts')
    user = obj.get('user')
    req_id = obj.get('request_id')
    status = obj.get('status')
    latency = obj.get('latency_ms')
    
    if not all([ts_raw is not None, user is not None, req_id is not None, status is not None, latency is not None]):
        return None
    
    ts = parse_ts(str(ts_raw))
    if ts is None:
        return None
    
    try:
        status_val = int(status)
    except (ValueError, TypeError):
        return None
    
    lat_str = str(latency).strip()
    lat_m = re.match(r'^(\d+)(?:ms)?$', lat_str)
    if not lat_m:
        return None
    latency_val = int(lat_m.group(1))
    
    return {
        'ts': ts,
        'user': user.lower(),
        'request_id': str(req_id),
        'status': status_val,
        'latency_ms': latency_val
    }

def parse_legacy_line(line):
    """Try parsing a legacy log line."""
    m = re.match(
        r'^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z)'
        r'\s+user=(\S+)'
        r'\s+req=(\S+)'
        r'\s+status=(\S+)'
        r'\s+ms=(\S+)\s*$',
        line.strip()
    )
    if not m:
        return None
    
    ts_raw, user, req_id, status_str, latency_str = m.groups()
    
    ts = parse_ts(ts_raw)
    if ts is None:
        return None
    
    try:
        status_val = int(status_str)
    except ValueError:
        return None
    
    lat_m = re.match(r'^(\d+)(?:ms)?$', latency_str)
    if not lat_m:
        return None
    latency_val = int(lat_m.group(1))
    
    return {
        'ts': ts,
        'user': user.lower(),
        'request_id': req_id,
        'status': status_val,
        'latency_ms': latency_val
    }

def parse_line(line):
    """Try both parsers."""
    line = line.strip()
    if not line:
        return None
    result = parse_json_line(line)
    if result is not None:
        return result
    result = parse_legacy_line(line)
    if result is not None:
        return result
    return None

def read_file_lines(filepath):
    """Read lines from a file, handling .gz with possible truncation."""
    if filepath.endswith('.gz'):
        try:
            f = gzip.open(filepath, 'rt', errors='replace')
        except (OSError, IOError):
            return []
        
        lines = []
        try:
            for line in f:
                if line.endswith('\n'):
                    lines.append(line)
                else:
                    # Truncated - stop reading (partial line discarded)
                    break
        except (EOFError, zlib.error):
            pass  # File was truncated or corrupted, take what we have
        finally:
            f.close()
        return lines
    else:
        try:
            with open(filepath, 'r', errors='replace') as f:
                return f.readlines()
        except (OSError, IOError):
            return []

def compute_p95(values):
    """Compute p95 using nearest-rank method."""
    n = len(values)
    if n == 0:
        return 0
    rank = math.ceil(0.95 * n)  # 1-based
    return values[rank - 1]

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 p95.py LOGDIR", file=sys.stderr)
        sys.exit(1)
    
    logdir = sys.argv[1]
    
    if not os.path.isdir(logdir):
        print("Error: directory does not exist", file=sys.stderr)
        sys.exit(1)
    
    all_records = {}  # request_id -> best record (latest timestamp)
    
    for fname in sorted(os.listdir(logdir)):
        fpath = os.path.join(logdir, fname)
        if not os.path.isfile(fpath):
            continue
        
        match = re.match(r'^app\.log(\.(\d+)(\.gz)?)?$', fname)
        if not match:
            continue
        
        lines = read_file_lines(fpath)
        for line in lines:
            record = parse_line(line)
            if record is None:
                continue
            
            req_id = record['request_id']
            
            # Keep only the latest timestamp for each request_id
            if req_id not in all_records or record['ts'] > all_records[req_id]['ts']:
                all_records[req_id] = record
    
    # Group failures by user
    user_failures = {}  # user -> list of latency_ms values
    for req_id, rec in all_records.items():
        if rec['status'] >= 500:
            user = rec['user']
            if user not in user_failures:
                user_failures[user] = []
            user_failures[user].append(rec['latency_ms'])
    
    # Compute p95 for each user with failures
    rows = []
    for user, latencies in user_failures.items():
        if len(latencies) > 0:
            sorted_lats = sorted(latencies)
            p95 = compute_p95(sorted_lats)
            rows.append((user, len(latencies), int(p95)))
    
    # Sort by failures desc, then user asc
    rows.sort(key=lambda x: (-x[1], x[0]))
    
    # Output CSV
    print("user,failures,p95_ms")
    for user, failures, p95 in rows:
        print(f"{user},{failures},{p95}")

if __name__ == '__main__':
    main()
