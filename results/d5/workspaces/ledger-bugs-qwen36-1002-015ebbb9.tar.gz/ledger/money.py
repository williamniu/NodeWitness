import re
from decimal import Decimal, ROUND_HALF_UP


def _validate(text):
    """Check that text matches the expected format."""
    # Optional sign, one or more digits, optional dot + one or more digits
    return bool(re.match(r'^[+-]?(\d+\.?\d*|\d*\.\d+)$', text))


def to_cents(text):
    """Parse a decimal amount string into integer cents."""
    text = text.strip()
    if not _validate(text):
        raise ValueError(f"invalid format: {text!r}")
    val = Decimal(text) * 100
    return int(val.quantize(Decimal('1'), rounding=ROUND_HALF_UP))


def split(total_cents, n):
    """Split an amount into n near-equal parts."""
    if n < 1:
        raise ValueError("n must be >= 1")
    sign = -1 if total_cents < 0 else 1
    abs_val = abs(total_cents)
    base = abs_val // n
    rem = abs_val % n
    # Larger absolute value parts first, then smaller
    result = [sign * (base + 1)] * rem + [sign * base] * (n - rem)
    return result


def allocate(total_cents, weights):
    """Split an amount in proportion to weights."""
    if not weights:
        raise ValueError("weights must be non-empty")
    total_w = sum(weights)
    if total_w == 0 or any(w < 0 for w in weights):
        raise ValueError("weights must be non-negative and sum > 0")

    shares = []
    fracs = []
    for i, w in enumerate(weights):
        share = Decimal(total_cents * w) / total_w
        # Truncate toward zero
        truncated = int(share.to_integral_value(rounding='ROUND_FLOOR' if share >= 0 else 'ROUND_CEILING'))
        shares.append(truncated)
        fracs.append(share - Decimal(truncated))

    remaining = total_cents - sum(shares)

    if remaining > 0:
        # Give each remaining cent to the part with largest fractional remainder
        candidates = sorted(range(len(weights)), key=lambda i: (-fracs[i], i))
        for j in range(remaining):
            shares[candidates[j]] += 1

    elif remaining < 0:
        # Take away from the part with smallest fractional remainder (closest to 1)
        candidates = sorted(range(len(weights)), key=lambda i: (fracs[i], i))
        for j in range(-remaining):
            shares[candidates[j]] -= 1

    return shares
