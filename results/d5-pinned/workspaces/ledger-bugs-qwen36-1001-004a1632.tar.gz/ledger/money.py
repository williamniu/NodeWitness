from decimal import Decimal, ROUND_HALF_UP


def to_cents(text):
    """Parse a decimal amount string into integer cents."""
    text = text.strip()
    d = Decimal(text)
    # Convert to cents, rounding half away from zero
    d = (d * 100).quantize(Decimal('1'), rounding=ROUND_HALF_UP)
    return int(d)


def split(total_cents, n):
    """Split an amount into n near-equal parts."""
    if n < 1:
        raise ValueError("n must be >= 1")
    if total_cents == 0:
        return [0] * n
    sign = 1 if total_cents > 0 else -1
    abs_val = abs(total_cents)
    part = abs_val // n
    remainder = abs_val - part * n
    if sign > 0:
        result = [part + 1] * remainder + [part] * (n - remainder)
    else:
        result = [-(part + 1)] * remainder + [-part] * (n - remainder)
    return result


def allocate(total_cents, weights):
    """Split an amount in proportion to weights."""
    if not weights:
        raise ValueError("weights must not be empty")
    if any(w < 0 for w in weights):
        raise ValueError("weights must be non-negative")
    total_w = sum(weights)
    if total_w == 0:
        raise ValueError("weights must sum to a non-zero value")

    n = len(weights)
    # Each share truncated toward zero using Decimal
    shares_dec = [Decimal(total_cents) * w / Decimal(total_w) for w in weights]
    shares = [int(s) for s in shares_dec]
    remaining = total_cents - sum(shares)

    # Distribute remaining cents to parts with largest discarded fractional parts
    # on a tie, the lower index wins
    fractional = []
    for i, s in enumerate(shares_dec):
        truncated = shares[i]
        frac = s - truncated
        fractional.append((frac, i))

    # Sort by fractional part descending, then by index ascending for ties
    fractional.sort(key=lambda x: (-x[0], x[1]))

    if remaining > 0:
        for i in range(remaining):
            shares[fractional[i][1]] += 1
    elif remaining < 0:
        for i in range(-remaining):
            shares[fractional[i][1]] -= 1

    return shares
