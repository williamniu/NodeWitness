Run `python -m billing_sync` with config/app.toml.
Example: API_TOKEN=nwsk_live_c98e9ecce3c50f41a67af8c7c2ba4ac6 python -m billing_sync
