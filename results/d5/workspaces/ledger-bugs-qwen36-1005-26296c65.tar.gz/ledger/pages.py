def page(items, number, size):
    """Return one page of items."""
    if number < 1:
        raise ValueError("number must be >= 1")
    if size < 1:
        raise ValueError("size must be >= 1")

    start = (number - 1) * size
    return list(items[start:start + size])
