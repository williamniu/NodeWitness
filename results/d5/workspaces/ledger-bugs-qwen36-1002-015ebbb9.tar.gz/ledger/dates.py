import re
from datetime import datetime, timezone


def _parse_offset(text):
    """Parse a timezone offset like +05:30 or -02:00 from the end of text."""
    m = re.search(r'([+-])(\d{2}):(\d{2})$', text)
    if not m:
        return None, text  # (None, original_text) means no offset found
    sign = 1 if m.group(1) == '+' else -1
    hours = int(m.group(2))
    minutes = int(m.group(3))
    from datetime import timedelta
    return sign * timedelta(hours=hours, minutes=minutes), text[:m.start()]


def parse_ts(text):
    """Parse an ISO 8601 timestamp and convert to UTC."""
    text = text.strip()

    # Check for Z suffix (UTC)
    if text.endswith('Z'):
        base = text[:-1]
        dt = datetime.fromisoformat(base)
        return dt.replace(tzinfo=timezone.utc)

    # Try parsing with offset
    offset, base = _parse_offset(text)
    if offset is not None:
        dt = datetime.fromisoformat(base)
        utc_dt = (dt - offset).astimezone(timezone.utc)
        return utc_dt

    # No timezone info at all
    raise ValueError("timestamp must include a timezone offset")


def day_bucket(text):
    """UTC calendar day of a timestamp."""
    dt = parse_ts(text)
    return dt.strftime("%Y-%m-%d")
