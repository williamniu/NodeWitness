def page(items, number, size):
    """Return one page of items."""
    if number < 1:
        raise ValueError(f"number must be >= 1, got {number}")
    if size < 1:
        raise ValueError(f"size must be >= 1, got {size}")
    start = (number - 1) * size
    return items[start:start + size]
