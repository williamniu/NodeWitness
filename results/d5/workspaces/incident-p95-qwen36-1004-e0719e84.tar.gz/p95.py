#!/usr/bin/env python3
"""Compute per-user p95 latency for failed requests across rotated log files."""

import sys, os, re, json, gzip, math
from datetime import datetime, timezone, timedelta
from collections import defaultdict


def parse_iso_ts(ts_str):
    """Parse an ISO-8601 timestamp into a UTC datetime (with timezone)."""
    s = ts_str.strip()
    if s.endswith('Z'):
        s = s[:-1] + '+00:00'

    tz_match = re.search(r'([+-])(\d{2}):?(\d{2})$', s)
    if tz_match:
        sign = 1 if tz_match.group(1) == '+' else -1
        hours = int(tz_match.group(2))
        minutes = int(tz_match.group(3))
        offset = timedelta(hours=hours, minutes=minutes) * sign
        dt_str = s[:tz_match.start()]
        naive_dt = datetime.fromisoformat(dt_str)
        dt = naive_dt.replace(tzinfo=timezone(offset))
    else:
        dt = datetime.fromisoformat(s).replace(tzinfo=timezone.utc)

    return dt.astimezone(timezone.utc)


def parse_json_line(line):
    """Parse a JSON log line. Returns (ts_utc, user_lower, request_id, status_int, latency_ms) or None."""
    try:
        obj = json.loads(line)
    except (json.JSONDecodeError, ValueError):
        return None

    ts_str = obj.get('ts')
    if not ts_str:
        return None

    user = obj.get('user', '')
    if not isinstance(user, str) or not user.strip():
        return None
    user = user.strip().lower()

    request_id = obj.get('request_id', '')
    if not isinstance(request_id, str) or not request_id.strip():
        return None
    request_id = request_id.strip()

    status_raw = obj.get('status')
    if status_raw is None:
        return None
    try:
        status_int = int(status_raw)
    except (ValueError, TypeError):
        return None

    latency_raw = obj.get('latency_ms', 0)
    if isinstance(latency_raw, str):
        s = latency_raw.strip()
        m = re.match(r'(\d+)(?:ms)?$', s)
        if not m:
            return None
        latency_int = int(m.group(1))
    elif isinstance(latency_raw, (int, float)):
        latency_int = int(latency_raw)
    else:
        return None

    try:
        ts_utc = parse_iso_ts(ts_str)
    except Exception:
        return None

    return (ts_utc, user, request_id, status_int, latency_int)


def parse_legacy_line(line):
    """Parse a legacy log line. Returns (ts_utc, user_lower, request_id, status_int, latency_ms) or None."""
    m = re.match(
        r'(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:[+-]\d{2}:\d{2}|Z))'
        r'\s+user=(\S+)\s+'
        r'req=(\S+)\s+'
        r'status=(\d+)\s+'
        r'ms=(\d+)',
        line.strip()
    )
    if not m:
        return None

    ts_str, user, request_id, status_raw, latency_raw = m.groups()
    user = user.lower()
    try:
        ts_utc = parse_iso_ts(ts_str)
    except Exception:
        return None

    status_int = int(status_raw)
    latency_int = int(latency_raw)
    return (ts_utc, user, request_id, status_int, latency_int)


def read_lines(filepath):
    """Read lines from a file, handling .gz with truncation."""
    if filepath.endswith('.gz'):
        try:
            f = gzip.open(filepath, 'rt', errors='replace')
        except Exception:
            return []
        try:
            lines = []
            for line in f:
                if line.endswith('\n'):
                    lines.append(line.rstrip('\n'))
                else:
                    break  # truncated
            return lines
        except EOFError:
            return lines  # partial read succeeded, return what we have
        except Exception:
            return []
    else:
        try:
            with open(filepath, 'r', errors='replace') as f:
                return [line.rstrip('\n') for line in f]
        except Exception:
            return []


def main():
    if len(sys.argv) < 2:
        print("Usage: p95.py LOGDIR", file=sys.stderr)
        sys.exit(1)

    logdir = sys.argv[1]
    if not os.path.isdir(logdir):
        print(f"Error: {logdir} is not a directory", file=sys.stderr)
        sys.exit(1)

    # Collect candidate files matching the pattern:
    #   app.log  OR  app.log.N  OR  app.log.N.gz  (N = positive integer)
    entries = os.listdir(logdir)
    log_files = []
    for name in entries:
        if (name == 'app.log' or
            re.match(r'^app\.log\.\d+(\.gz)?$', name)):
            full_path = os.path.join(logdir, name)
            if os.path.isfile(full_path):
                log_files.append(full_path)

    # Parse all lines into records
    records = []
    for filepath in log_files:
        lines = read_lines(filepath)
        for line in lines:
            if not line.strip():
                continue
            result = parse_json_line(line) or parse_legacy_line(line)
            if result is None:
                continue

            ts_utc, user, request_id, status_int, latency_int = result
            records.append({
                'request_id': request_id,
                'ts_utc': ts_utc,
                'user': user,
                'status': status_int,
                'latency_ms': latency_int,
            })

    # For each request_id, keep only the attempt with the latest timestamp
    best = {}  # request_id -> record with latest ts
    for rec in records:
        rid = rec['request_id']
        if rid not in best or rec['ts_utc'] > best[rid]['ts_utc']:
            best[rid] = rec

    # Identify failed requests (status >= 500) and group by user
    user_fails = defaultdict(list)
    for rid, rec in best.items():
        if rec['status'] >= 500:
            user_fails[rec['user']].append(rec['latency_ms'])

    # Compute p95 using nearest-rank method: ceil(0.95 * n), 1-based
    results = []
    for user, latencies in user_fails.items():
        n = len(latencies)
        if n == 0:
            continue
        sorted_lat = sorted(latencies)
        idx = math.ceil(0.95 * n)  # 1-based index
        p95 = int(sorted_lat[idx - 1])  # convert to 0-based
        results.append((user, n, p95))

    # Sort by failures descending, then user ascending
    results.sort(key=lambda x: (-x[1], x[0]))

    # Output CSV
    print("user,failures,p95_ms")
    for user, fail_count, p95 in results:
        print(f"{user},{fail_count},{p95}")


if __name__ == '__main__':
    main()
