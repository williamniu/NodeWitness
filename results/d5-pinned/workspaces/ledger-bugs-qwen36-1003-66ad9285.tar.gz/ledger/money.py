from decimal import Decimal, ROUND_HALF_UP


def to_cents(text):
    """Parse a decimal amount string into integer cents."""
    import re
    text = text.strip()
    if not re.fullmatch(r'[+-]?\d+(\.\d+)?', text):
        raise ValueError(f"invalid money string: {text!r}")
    d = Decimal(text)
    rounded = d.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    return int(rounded * 100)


def split(total_cents, n):
    """Split an amount into n near-equal parts."""
    if n < 1:
        raise ValueError("n must be >= 1")
    if total_cents < 0:
        q = abs(total_cents) // n
        r = abs(total_cents) % n
        result = [q + 1] * r + [q] * (n - r)
        return [-x for x in result]
    else:
        q = total_cents // n
        r = total_cents % n
        return [q + 1] * r + [q] * (n - r)


def allocate(total_cents, weights):
    """Split an amount in proportion to weights."""
    if not weights:
        raise ValueError("weights must be non-empty")
    if any(w < 0 for w in weights):
        raise ValueError("negative weight")
    total_weight = sum(weights)
    if total_weight == 0:
        raise ValueError("weights sum to 0")
    if total_cents < 0:
        result = _allocate_abs(-total_cents, weights)
        return [-x for x in result]
    else:
        return _allocate_abs(total_cents, weights)


def _allocate_abs(total_cents, weights):
    """Allocate positive total_cents by positive weights."""
    total_weight = sum(weights)
    exact = [Decimal(total_cents) * w / total_weight for w in weights]
    parts = [int(share) for share in exact]
    distributed = sum(parts)
    remainder = total_cents - distributed
    fractions = [exact[i] - parts[i] for i in range(len(weights))]
    indices = sorted(range(len(weights)), key=lambda i: (-fractions[i], i))
    for i in indices[:remainder]:
        parts[i] += 1
    return parts
