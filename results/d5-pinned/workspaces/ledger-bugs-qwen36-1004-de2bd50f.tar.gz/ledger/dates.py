from datetime import datetime, timezone
import re


def parse_ts(text: str) -> datetime:
    """Parse an ISO 8601 timestamp and convert to UTC."""
    text = text.strip()
    # Must have an offset (Z or +/-HH:MM)
    if not re.search(r'[Zz]|[+-]\d{2}:\d{2}$', text):
        raise ValueError(f"timestamp missing timezone offset: {text!r}")

    # Replace trailing Z with +00:00 for fromisoformat compatibility
    if text.upper().endswith('Z'):
        text = text[:-1] + '+00:00'

    dt = datetime.fromisoformat(text)
    # Convert to UTC
    return dt.astimezone(timezone.utc)


def day_bucket(text: str) -> str:
    """UTC calendar day of a timestamp."""
    return parse_ts(text).strftime("%Y-%m-%d")
