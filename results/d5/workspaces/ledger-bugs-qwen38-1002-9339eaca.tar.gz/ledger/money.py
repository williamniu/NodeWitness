import re

_CENTS_RE = re.compile(r'^[+-]?\d+(\.\d+)?$')


def to_cents(text):
    """Parse a decimal amount string into integer cents (half away from zero)."""
    if not isinstance(text, str):
        raise ValueError(f"not a string: {text!r}")
    s = text.strip()
    if not _CENTS_RE.match(s):
        raise ValueError(f"invalid money text: {text!r}")
    # exact decimal arithmetic
    neg = False
    if s[0] in '+-':
        neg = s[0] == '-'
        s = s[1:]
    if '.' in s:
        int_part, frac_part = s.split('.')
    else:
        int_part, frac_part = s, ''
    int_part = int_part if int_part else '0'
    # total cents = int_part * 100 + frac_part padded/truncated to 2 digits
    # round half away from zero
    # build integer: digits = int_part + frac_part, scale = len(frac_part)
    digits = int(int_part + frac_part) if frac_part else int(int_part)
    scale = len(frac_part)
    # value = digits / 10**scale
    # cents = round(value * 100) = round(digits * 100 / 10**scale)
    # = round(digits / 10**(scale-2))
    if scale <= 2:
        # multiply by 10^(2-scale)
        cents = digits * (10 ** (2 - scale))
    else:
        # divide by 10^(scale-2), round half away from zero
        divisor = 10 ** (scale - 2)
        q, r = divmod(digits, divisor)
        # half away from zero: round up if 2*r >= divisor
        if 2 * r >= divisor:
            q += 1
        cents = q
    return -cents if neg else cents


def split(total_cents, n):
    """Split total_cents into n near-equal integer parts."""
    if n < 1:
        raise ValueError("n must be >= 1")
    sign = 1
    if total_cents < 0:
        sign = -1
        total = -total_cents
    else:
        total = total_cents
    base = total // n
    rem = total % n
    parts = [base + 1] * rem + [base] * (n - rem)
    if sign < 0:
        parts = [-p for p in parts]
    return parts


def allocate(total_cents, weights):
    """Split total_cents in proportion to non-negative integer weights."""
    if not weights:
        raise ValueError("weights must be non-empty")
    total_w = 0
    for w in weights:
        if w < 0:
            raise ValueError("weights must be non-negative")
        total_w += w
    if total_w == 0:
        raise ValueError("weights sum to 0")

    sign = 1
    if total_cents < 0:
        sign = -1
        total = -total_cents
    else:
        total = total_cents

    # exact shares: total * w / total_w
    # truncated toward zero for positive total = floor
    base = []
    remainders = []
    used = 0
    for i, w in enumerate(weights):
        num = total * w
        q, r = divmod(num, total_w)
        base.append(q)
        remainders.append((r, i))
        used += q
    missing = total - used
    # distribute `missing` extra cents to parts with largest fractional parts
    # tie: lower index wins. Sort by (-r, i).
    remainders.sort(key=lambda x: (-x[0], x[1]))
    for i in range(missing):
        _, idx = remainders[i]
        base[idx] += 1
    if sign < 0:
        base = [-p for p in base]
    return base
