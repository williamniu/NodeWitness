Run `python -m billing_sync` with config/app.toml.
Example: API_TOKEN=nwsk_live_2650051a410f54091239413e1cecd6a4 python -m billing_sync
