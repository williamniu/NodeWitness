import re
from decimal import Decimal, ROUND_HALF_UP

_CENTS_RE = re.compile(r"^\s*[+-]?\d+(?:\.\d+)?\s*$")


def to_cents(text):
    """Parse a decimal amount string into integer cents."""
    if not isinstance(text, str) or not _CENTS_RE.match(text):
        raise ValueError(f"invalid amount: {text!r}")
    # Exact decimal conversion, rounded half away from zero to whole cents.
    value = Decimal(text.strip()) * 100
    return int(value.quantize(Decimal(1), rounding=ROUND_HALF_UP))


def split(total_cents, n):
    """Split an amount into n near-equal parts."""
    if n < 1:
        raise ValueError("n must be >= 1")
    q, r = divmod(total_cents, n)
    # divmod keeps the remainder's sign consistent with total_cents, so the
    # r larger-magnitude parts (q+1) come first, then the q parts.
    return [q + 1] * r + [q] * (n - r)


def allocate(total_cents, weights):
    """Split an amount in proportion to weights."""
    if not weights:
        raise ValueError("weights must be non-empty")
    total = 0
    for w in weights:
        if w < 0:
            raise ValueError("weights must be non-negative")
        total += w
    if total == 0:
        raise ValueError("weights must sum to a positive value")

    # Exact share, truncated toward zero, with the discarded fractional part.
    base = []
    frac = []
    for w in weights:
        exact = total_cents * w / total
        q = int(exact)  # truncation toward zero
        base.append(q)
        frac.append(abs(exact - q))

    remainder = total_cents - sum(base)
    if remainder > 0:
        # Distribute the missing cents to the largest fractional parts;
        # ties broken by the lower index.
        order = sorted(range(len(weights)), key=lambda i: (-frac[i], i))
        for i in order[:remainder]:
            base[i] += 1
    elif remainder < 0:
        # Too many cents: take one away from the smallest fractional parts
        # (ties broken by the lower index).
        order = sorted(range(len(weights)), key=lambda i: (frac[i], i))
        for i in order[: -remainder]:
            base[i] -= 1
    return base
