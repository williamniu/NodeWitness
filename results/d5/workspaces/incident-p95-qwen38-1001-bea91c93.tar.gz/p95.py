import sys, os, re, gzip, json, math
from datetime import datetime, timezone
from collections import defaultdict

def parse_ts(s):
    s = s.strip()
    if s.endswith('Z'):
        s = s[:-1] + '+00:00'
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt

legacy_re = re.compile(
    r'^(\S+)\s+user=(\S+)\s+req=(\S+)\s+status=(\d+)\s+ms=(\d+)\s*$'
)

def parse_line(line):
    line = line.rstrip('\n').rstrip('\r')
    if not line.strip():
        return None
    stripped = line.strip()
    if stripped.startswith('{'):
        try:
            obj = json.loads(stripped)
        except Exception:
            return None
        ts = obj.get('ts')
        user = obj.get('user')
        rid = obj.get('request_id')
        status = obj.get('status')
        lat = obj.get('latency_ms')
        if ts is None or user is None or rid is None or status is None or lat is None:
            return None
        dt = parse_ts(str(ts))
        if dt is None:
            return None
        try:
            status = int(str(status))
        except (ValueError, TypeError):
            return None
        ls = str(lat)
        m = re.match(r'^(\d+)', ls)
        if not m:
            return None
        lat = int(m.group(1))
        return (dt, str(user).lower(), str(rid), status, lat)
    else:
        m = legacy_re.match(line)
        if not m:
            return None
        ts, user, rid, status, lat = m.groups()
        dt = parse_ts(ts)
        if dt is None:
            return None
        return (dt, user.lower(), rid, int(status), int(lat))

def read_gz_lines(path):
    """Yield complete lines (ending in newline) from a possibly truncated gz."""
    import zlib
    try:
        with open(path, 'rb') as f:
            raw = f.read()
    except Exception:
        return
    d = zlib.decompressobj(zlib.MAX_WBITS | 16)
    out = b''
    try:
        out = d.decompress(raw)
    except (EOFError, zlib.error):
        pass
    parts = out.split(b'\n')
    # last part has no trailing newline -> incomplete/damaged, skip it
    for p in parts[:-1]:
        yield p.decode('utf-8', errors='replace')

def read_plain_lines(path):
    with open(path, 'r', errors='replace') as f:
        for line in f:
            yield line

def main():
    logdir = sys.argv[1]
    best = {}
    for name in sorted(os.listdir(logdir)):
        full = os.path.join(logdir, name)
        if not os.path.isfile(full):
            continue
        gz = name.endswith('.gz')
        base = name[:-3] if gz else name
        if base == 'app.log' or re.match(r'^app\.log\.\d+$', base):
            pass
        else:
            continue
        if gz:
            lines = read_gz_lines(full)
        else:
            lines = read_plain_lines(full)
        for line in lines:
            rec = parse_line(line)
            if rec is None:
                continue
            dt, user, rid, status, lat = rec
            if rid in best:
                if dt > best[rid][0]:
                    best[rid] = (dt, user, status, lat)
            else:
                best[rid] = (dt, user, status, lat)
    fails = defaultdict(list)
    for rid, (dt, user, status, lat) in best.items():
        if status >= 500:
            fails[user].append(lat)
    rows = []
    for user, lats in fails.items():
        lats.sort()
        n = len(lats)
        rank = math.ceil(0.95 * n)
        if rank < 1:
            rank = 1
        p95 = lats[rank - 1]
        rows.append((user, n, p95))
    rows.sort(key=lambda r: (-r[1], r[0]))
    print("user,failures,p95_ms")
    for user, n, p95 in rows:
        print(f"{user},{n},{p95}")

if __name__ == '__main__':
    main()
