#!/usr/bin/env python3
"""Migrate a SQLite database from schema v1 to v2."""
import sys, sqlite3, re

def parse_amount(raw: str) -> int | None:
    """Parse amount string like '$1,234.50' or '($12.50)' into integer cents.
    
    Formats:
        12
        12.5
        $1,234.50
        -12.50
        -$12.50
        ($12.50)
        (12.50)
    """
    s = raw.strip()
    
    if not s:
        return None
    
    # Handle accounting style: (value) means negative
    is_negative = False
    if s.startswith('(') and s.endswith(')'):
        is_negative = True
        s = s[1:-1].strip()
    
    # Check for leading minus sign
    if s.startswith('-'):
        is_negative = not is_negative  # -(-val) is still negative
        s = s[1:].strip()
    elif s.startswith('+'):
        s = s[1:].strip()
    
    # Remove leading $
    if s.startswith('$'):
        s = s[1:].strip()
    
    # Now validate: must be digits with optional decimal part, possibly with commas
    m = re.fullmatch(r'(\d+(?:,\d+)*)(?:\.(\d{1,2}))?', s)
    if not m:
        return None
    
    dollars_str = m.group(1).replace(',', '')
    cents_str = m.group(2)
    
    # If no decimal part provided, assume .00
    if cents_str is None:
        cents_str = '00'
    else:
        # Pad to 2 digits (e.g., "5" -> "50")
        cents_str = cents_str.ljust(2, '0')[:2]
    
    total_cents = int(dollars_str) * 100 + int(cents_str)
    
    if is_negative:
        total_cents = -total_cents
    
    return total_cents

def parse_name(full_name):
    """Split full_name into (first_name, last_name)."""
    if not full_name or not full_name.strip():
        return ('', '')
    
    # Collapse whitespace runs to single space
    name = re.sub(r'\s+', ' ', full_name.strip())
    
    words = name.split(' ')
    
    if len(words) == 0:
        return ('', '')
    elif len(words) == 1:
        return (words[0], '')
    else:
        last = words[-1]
        first = ' '.join(words[:-1])
        return (first, last)

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 migrate.py PATH", file=sys.stderr)
        sys.exit(1)
    
    path = sys.argv[1]
    
    # Open database
    conn = sqlite3.connect(path)
    cur = conn.cursor()
    
    # Check version
    cur.execute("PRAGMA user_version")
    version = cur.fetchone()[0]
    
    if version == 2:
        # Already v2, nothing to do
        conn.close()
        return
    
    if version != 1:
        print(f"Unexpected database version: {version}", file=sys.stderr)
        sys.exit(1)
    
    # Read all data first for validation and processing
    cur.execute("SELECT id, email, full_name FROM users ORDER BY id")
    rows = cur.fetchall()
    
    users_raw = []
    for uid, email, full_name in rows:
        users_raw.append((uid, email, full_name))
    
    cur.execute("SELECT id, user_id, amount, created_at FROM orders ORDER BY id")
    orders_raw = cur.fetchall()
    
    # Step 1: Validate all amounts before modifying anything
    for oid, uid, amt, cat in orders_raw:
        parsed = parse_amount(amt)
        if parsed is None:
            conn.close()
            sys.exit(1)
    
    # Step 2: Process users - trim and lowercase email
    valid_users = {}  # normalized_email -> (id, first_name, last_name)
    for uid, email, full_name in users_raw:
        if email is None or email.strip() == '':
            continue  # Skip deleted users
        
        norm_email = email.strip().lower()
        
        if norm_email not in valid_users:
            fn, ln = parse_name(full_name)
            valid_users[norm_email] = (uid, fn, ln)
        else:
            # Duplicate email - keep smallest id
            existing_id, _, _ = valid_users[norm_email]
            if uid < existing_id:
                fn, ln = parse_name(full_name)
                valid_users[norm_email] = (uid, fn, ln)
    
    # Step 3: Build user lookup: v1 user id -> target v2 user id
    kept_ids = set(v[0] for v in valid_users.values())
    user_id_map = {}
    
    for orig_uid, orig_email, orig_name in users_raw:
        if orig_uid not in kept_ids:
            continue
        if orig_email is None or orig_email.strip() == '':
            continue
        norm = orig_email.strip().lower()
        target_id = valid_users[norm][0]
        user_id_map[orig_uid] = target_id
    
    # Step 4: Process orders
    new_orders = []
    for oid, old_uid, amt, cat in orders_raw:
        if old_uid not in kept_ids:
            continue
        
        parsed_cents = parse_amount(amt)
        target_uid = user_id_map[old_uid]
        new_orders.append((oid, target_uid, parsed_cents, cat))
    
    # Step 5: Now actually modify the database
    conn.execute("BEGIN")
    
    try:
        cur.execute("DROP TABLE IF EXISTS orders")
        cur.execute("DROP TABLE IF EXISTS users")
        
        cur.execute("""
            CREATE TABLE users(
                id INTEGER PRIMARY KEY,
                email TEXT NOT NULL UNIQUE,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL
            )
        """)
        
        for norm_email, (uid, fn, ln) in valid_users.items():
            cur.execute("INSERT INTO users(id, email, first_name, last_name) VALUES (?, ?, ?, ?)",
                       (uid, norm_email, fn, ln))
        
        cur.execute("""
            CREATE TABLE orders(
                id INTEGER PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id),
                amount_cents INTEGER NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        
        for oid, new_uid, cents, cat in new_orders:
            cur.execute(
                "INSERT INTO orders(id, user_id, amount_cents, created_at) VALUES (?, ?, ?, ?)",
                (oid, new_uid, cents, cat)
            )
        
        cur.execute("CREATE INDEX idx_orders_user_id ON orders(user_id)")
        cur.execute("PRAGMA user_version = 2")
        
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    
    conn.close()

if __name__ == '__main__':
    main()
