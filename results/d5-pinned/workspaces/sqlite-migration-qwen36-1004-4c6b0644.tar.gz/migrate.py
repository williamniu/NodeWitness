#!/usr/bin/env python3
"""Migrate a v1 SQLite database to v2 schema."""

import sys
import sqlite3
import re
import shutil
import os


def parse_amount(text):
    """Parse an amount string into an integer number of cents.
    
    Accepted formats:
    - "12", "12.5", "7.05"
    - "$1,234.50"
    - "-12.50", "-$12.50"
    - "($12.50)" — accounting style negative
    """
    s = text.strip()
    if not s:
        return None

    sign = 1
    if s.startswith('-'):
        sign = -1
        s = s[1:]
    elif s.startswith('+'):
        s = s[1:]

    if s.startswith('(') and s.endswith(')'):
        sign = -1
        s = s[1:-1]

    if s.startswith('$'):
        s = s[1:]

    s = s.replace(',', '')

    if not re.fullmatch(r'\d+(\.\d{1,2})?', s):
        return None

    if '.' in s:
        whole, frac = s.split('.')
        frac = frac.ljust(2, '0')[:2]
        cents = int(whole) * 100 + int(frac)
    else:
        cents = int(s) * 100

    return sign * cents


def parse_name(full_name):
    """Parse full_name into (first_name, last_name)."""
    if full_name is None:
        return ('', '')
    s = full_name.strip()
    if not s:
        return ('', '')
    words = s.split()
    if len(words) == 0:
        return ('', '')
    elif len(words) == 1:
        return (words[0], '')
    else:
        return (' '.join(words[:-1]), words[-1])


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 migrate.py PATH", file=sys.stderr)
        sys.exit(1)

    path = sys.argv[1]

    # If already v2, do nothing
    db = sqlite3.connect(path)
    version = db.execute("PRAGMA user_version").fetchone()[0]
    db.close()

    if version == 2:
        return

    # Make a backup in case of failure
    backup_path = path + ".migrate_backup"
    shutil.copy2(path, backup_path)

    try:
        db = sqlite3.connect(path)
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("PRAGMA foreign_keys=OFF")
        db.execute("BEGIN")

        # Read v1 data
        users = db.execute("SELECT id, email, full_name FROM users ORDER BY id").fetchall()
        orders = db.execute("SELECT id, user_id, amount, created_at FROM orders").fetchall()

        # Step 1: Group users by normalized email, keep only those with valid emails
        email_groups = {}  # normalized_email -> list of (id, full_name)
        for uid, email, full_name in users:
            if email is not None:
                email = email.strip().lower()
                if email:
                    email_groups.setdefault(email, []).append((uid, full_name))

        # Step 2: For each email, pick the user with smallest id as the keeper
        email_to_kept_id = {}
        for email, group in email_groups.items():
            email_to_kept_id[email] = group[0][0]  # smallest id

        kept_user_ids = set(email_to_kept_id.values())

        # Step 3: Build mapping from all user_ids to their kept_user_id
        # Only for users that have valid emails
        user_id_to_kept_id = {}
        for email, kept_id in email_to_kept_id.items():
            user_id_to_kept_id[kept_id] = kept_id
            for uid, _ in email_groups[email]:
                if uid != kept_id:
                    user_id_to_kept_id[uid] = kept_id

        # Step 4: Parse amounts, validate
        parsed_orders = []
        for oid, uid, amount, created_at in orders:
            cents = parse_amount(amount)
            if cents is None:
                db.rollback()
                db.close()
                if os.path.exists(backup_path):
                    os.replace(backup_path, path)
                print("Error: invalid amount format", file=sys.stderr)
                sys.exit(1)
            parsed_orders.append((oid, uid, cents, created_at))

        # Step 5: Keep only orders whose user_id maps to a kept user
        # (orders from users without valid email are dropped)
        final_orders = []
        for oid, uid, cents, created_at in parsed_orders:
            if uid in user_id_to_kept_id:
                new_uid = user_id_to_kept_id[uid]
                final_orders.append((oid, new_uid, cents, created_at))

        # Step 6: Build user data for insertion
        user_info = {}  # kept_id -> (first_name, last_name, email)
        for email, kept_id in email_to_kept_id.items():
            for uid, orig_email, full_name in users:
                if uid == kept_id:
                    first_name, last_name = parse_name(full_name)
                    user_info[kept_id] = (first_name, last_name, email)
                    break

        # Step 7: Drop old tables and create v2 schema
        db.execute("DROP TABLE IF EXISTS orders")
        db.execute("DROP TABLE IF EXISTS users")

        db.execute("""
            CREATE TABLE users(
                id INTEGER PRIMARY KEY,
                email TEXT NOT NULL UNIQUE,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL
            )
        """)

        db.execute("""
            CREATE TABLE orders(
                id INTEGER PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id),
                amount_cents INTEGER NOT NULL,
                created_at TEXT NOT NULL
            )
        """)

        db.execute("CREATE INDEX idx_orders_user_id ON orders(user_id)")

        # Step 8: Insert migrated users
        for kept_id, (first_name, last_name, email) in sorted(user_info.items()):
            db.execute(
                "INSERT INTO users (id, email, first_name, last_name) VALUES (?, ?, ?, ?)",
                (kept_id, email, first_name, last_name)
            )

        # Step 9: Insert orders
        for oid, uid, cents, created_at in final_orders:
            db.execute(
                "INSERT INTO orders (id, user_id, amount_cents, created_at) VALUES (?, ?, ?, ?)",
                (oid, uid, cents, created_at)
            )

        # Step 10: Set user_version
        db.execute("PRAGMA user_version = 2")

        db.commit()
        db.close()

    except SystemExit:
        raise
    except Exception:
        db.rollback()
        db.close()
        if os.path.exists(backup_path):
            os.replace(backup_path, path)
        raise
    finally:
        if os.path.exists(backup_path):
            os.remove(backup_path)


if __name__ == "__main__":
    main()
