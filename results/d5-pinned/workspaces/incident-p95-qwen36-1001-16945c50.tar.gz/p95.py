#!/usr/bin/env python3
"""Compute per-user p95 latency for failed requests from rotated API gateway logs."""

import sys
import os
import re
import json
import gzip
import math
from datetime import datetime, timezone, timedelta
from collections import defaultdict

LOGDIR = sys.argv[1]


def parse_iso8601(s):
    """Parse ISO 8601 timestamp to a UTC-aware datetime."""
    s = s.strip()
    # Handle 'Z' suffix
    if s.endswith('Z'):
        s = s[:-1] + '+00:00'
    return datetime.fromisoformat(s)


def parse_legacy_line(line):
    """Parse legacy format: 2026-11-01T08:00:00Z user=alice req=r1a2b status=503 ms=412"""
    user_m = re.search(r'\buser=(\S+)', line)
    req_m = re.search(r'\breq=(\S+)', line)
    status_m = re.search(r'\bstatus=(\S+)', line)
    ms_m = re.search(r'\bms=(\S+)', line)
    
    parts = line.split()
    if len(parts) < 2:
        return None
    ts_str = parts[0]
    
    if not user_m or not req_m or not status_m or not ms_m:
        return None
    
    try:
        ts = parse_iso8601(ts_str)
    except (ValueError, TypeError):
        return None
    
    user = user_m.group(1).lower()
    req_id = req_m.group(1)
    
    try:
        status = int(status_m.group(1))
    except ValueError:
        return None
    
    ms_val = ms_m.group(1)
    if ms_val.endswith('ms'):
        try:
            latency = float(ms_val[:-2])
        except ValueError:
            return None
    else:
        try:
            latency = float(ms_val)
        except ValueError:
            return None
    
    return (ts, user, req_id, status, latency)


def _extract_latency(val):
    """Extract numeric latency from various formats."""
    if isinstance(val, (int, float)):
        return float(val)
    if isinstance(val, str):
        s = val.strip()
        if s.endswith('ms'):
            try:
                return float(s[:-2])
            except ValueError:
                return None
        try:
            return float(s)
        except ValueError:
            return None
    return None


def parse_json_line(line):
    """Parse JSON log line."""
    try:
        obj = json.loads(line)
    except (json.JSONDecodeError, ValueError):
        return None
    
    ts_str = obj.get('ts')
    user = obj.get('user')
    req_id = obj.get('request_id')
    status = obj.get('status')
    latency = obj.get('latency_ms')
    
    if ts_str is None or user is None or req_id is None or status is None or latency is None:
        return None
    
    try:
        ts = parse_iso8601(ts_str)
    except (ValueError, TypeError):
        return None
    
    user = str(user).strip().lower()
    
    try:
        status = int(status)
    except (ValueError, TypeError):
        return None
    
    latency = _extract_latency(latency)
    if latency is None:
        return None
    
    return (ts, user, req_id, status, latency)


def get_log_files(logdir):
    """Return list of (filepath, is_gz) for relevant log files."""
    result = []
    if not os.path.isdir(logdir):
        return result
    
    for fname in os.listdir(logdir):
        if fname == 'app.log':
            result.append((os.path.join(logdir, fname), False))
        else:
            m = re.match(r'^app\.log\.(\d+)$', fname)
            if m:
                result.append((os.path.join(logdir, fname), False))
            else:
                m = re.match(r'^app\.log\.(\d+)\.gz$', fname)
                if m:
                    result.append((os.path.join(logdir, fname), True))
    return result


def read_lines(filepath, is_gz):
    """Read lines from a file, handling truncated .gz files."""
    if is_gz:
        try:
            with gzip.open(filepath, 'rt', errors='replace') as f:
                return f.read()
        except (EOFError, gzip.BadGzipFile, OSError):
            try:
                with gzip.open(filepath, 'rb') as f:
                    data = f.read()
                text = data.decode('utf-8', errors='replace')
                lines = text.split('\n')
                # Remove trailing empty element from final newline
                if lines and lines[-1] == '':
                    lines = lines[:-1]
                return '\n'.join(lines) + '\n' if lines else ''
            except Exception:
                return ''
    else:
        with open(filepath, 'r', errors='replace') as f:
            return f.read()


def main():
    request_data = {}  # req_id -> (ts, user, status, latency)
    
    log_files = get_log_files(LOGDIR)
    
    for filepath, is_gz in log_files:
        content = read_lines(filepath, is_gz)
        for line in content.split('\n'):
            line = line.strip()
            if not line:
                continue
            
            record = parse_json_line(line)
            if record is None:
                record = parse_legacy_line(line)
            if record is None:
                continue
            
            ts, user, req_id, status, latency = record
            
            if req_id not in request_data or ts > request_data[req_id][0]:
                request_data[req_id] = (ts, user, status, latency)
    
    user_fails = defaultdict(list)
    
    for req_id, (ts, user, status, latency) in request_data.items():
        if status >= 500:
            user_fails[user].append(latency)
    
    results = []
    for user, latencies in user_fails.items():
        if not latencies:
            continue
        n = len(latencies)
        sorted_lat = sorted(latencies)
        idx = math.ceil(0.95 * n)  # 1-based
        p95 = sorted_lat[idx - 1]
        results.append((user, n, int(p95)))
    
    results.sort(key=lambda x: (-x[1], x[0]))
    
    print('user,failures,p95_ms')
    for user, failures, p95 in results:
        print(f'{user},{failures},{p95}')


if __name__ == '__main__':
    main()
