#!/usr/bin/env python3
import sys
import os
import gzip
import io
import json
import re
import math
import zlib
from datetime import datetime, timezone, timedelta
from collections import defaultdict

LOGDIR = sys.argv[1]

def parse_timestamp(ts_str):
    ts_str = ts_str.strip()
    if ts_str.endswith('Z'):
        ts_str = ts_str[:-1] + '+00:00'
    m = re.match(r'(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.(\d+))?([+-]\d{2}:\d{2})$', ts_str)
    if not m:
        return None
    date_part = m.group(1)
    frac = m.group(2)
    tz_part = m.group(3)
    
    dt = datetime.strptime(date_part, '%Y-%m-%dT%H:%M:%S')
    
    if frac:
        frac = frac[:6].ljust(6, '0')
        dt = dt.replace(microsecond=int(frac))
    
    sign = 1 if tz_part[0] == '+' else -1
    tz_hours = int(tz_part[1:3])
    tz_minutes = int(tz_part[4:6])
    offset = timedelta(hours=tz_hours, minutes=tz_minutes) * sign
    dt = dt.replace(tzinfo=timezone(offset))
    
    return dt

def parse_latency(val):
    if isinstance(val, (int, float)):
        return int(val)
    val = str(val).strip()
    m = re.match(r'^(\d+(?:\.\d+)?)ms?$', val)
    if m:
        return int(float(m.group(1)))
    try:
        return int(float(val))
    except:
        return None

def parse_json_line(line):
    try:
        obj = json.loads(line)
    except:
        return None
    
    ts = parse_timestamp(obj.get('ts', ''))
    if ts is None:
        return None
    
    user = obj.get('user', '').lower()
    if not user:
        return None
    
    request_id = obj.get('request_id', '')
    if not request_id:
        return None
    
    status = obj.get('status')
    if isinstance(status, str):
        try:
            status = int(status)
        except:
            return None
    else:
        try:
            status = int(status)
        except:
            return None
    
    latency = parse_latency(obj.get('latency_ms'))
    if latency is None:
        return None
    
    return (ts, user, request_id, status, latency)

def parse_legacy_line(line):
    parts = re.split(r'\s+', line.strip())
    if len(parts) < 5:
        return None
    
    ts = parse_timestamp(parts[0])
    if ts is None:
        return None
    
    fields = {}
    for part in parts[1:]:
        if '=' in part:
            key, val = part.split('=', 1)
            fields[key] = val
    
    user = fields.get('user', '').lower()
    if not user:
        return None
    
    request_id = fields.get('req', '')
    if not request_id:
        return None
    
    status_str = fields.get('status', '')
    try:
        status = int(status_str)
    except:
        return None
    
    ms_str = fields.get('ms', '')
    latency = parse_latency(ms_str)
    if latency is None:
        return None
    
    return (ts, user, request_id, status, latency)

def read_lines_from_file(fpath):
    """Read lines from a file, handling truncated .gz files."""
    if fpath.endswith('.gz'):
        with open(fpath, 'rb') as f:
            raw = f.read()
        # Try gzip first
        try:
            dec = gzip.GzipFile(fileobj=io.BytesIO(raw))
            lines = []
            for line in iter(dec.readline, b''):
                decoded = line.decode('utf-8', errors='replace').rstrip('\n\r')
                if decoded:
                    lines.append(decoded)
            return lines
        except:
            pass
        # Fall back to zlib decompression for truncated files
        try:
            decompressor = zlib.decompressobj(16 + 15)
            data = decompressor.decompress(raw)
            return data.decode('utf-8', errors='replace').split('\n')
        except:
            return []
    else:
        with open(fpath, 'r') as f:
            return [line.strip() for line in f if line.strip()]

# Collect all matching log files
LOG_FILES = []
for fname in os.listdir(LOGDIR):
    if fname == 'app.log' or re.match(r'^app\.log\.\d+(\.gz)?$', fname):
        LOG_FILES.append(os.path.join(LOGDIR, fname))

# Parse all log entries
requests = defaultdict(list)

for fpath in LOG_FILES:
    lines = read_lines_from_file(fpath)
    for line in lines:
        if not line:
            continue
        result = parse_json_line(line) or parse_legacy_line(line)
        if result:
            ts, user, request_id, status, latency = result
            requests[request_id].append(result)

# For each request_id, keep only the attempt with the latest timestamp
best_attempts = {}
for req_id, attempts in requests.items():
    best = max(attempts, key=lambda x: x[0])
    best_attempts[req_id] = best

# Find failed requests (status >= 500)
user_failures = defaultdict(list)
for req_id, (ts, user, rid, status, latency) in best_attempts.items():
    if status >= 500:
        user_failures[user].append(latency)

# Compute p95 for each user
results = []
for user, latencies in user_failures.items():
    n = len(latencies)
    if n == 0:
        continue
    latencies_sorted = sorted(latencies)
    rank = math.ceil(0.95 * n)
    p95 = latencies_sorted[rank - 1]
    results.append((user, n, p95))

# Sort by failures descending, then user ascending
results.sort(key=lambda x: (-x[1], x[0]))

# Output CSV
print("user,failures,p95_ms")
for user, failures, p95 in results:
    print(f"{user},{failures},{p95}")
