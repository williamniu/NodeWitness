Run `python -m billing_sync` with config/app.toml.
Example: API_TOKEN=REDACTED python -m billing_sync
