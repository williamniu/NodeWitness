#!/usr/bin/env python3
"""Migrate a v1 SQLite database to v2 schema."""

import sys
import sqlite3
import shutil
import os


def parse_amount(amount_str):
    """Parse amount string and return integer cents, or raise ValueError if invalid."""
    if amount_str is None:
        raise ValueError("None amount")

    s = amount_str.strip()
    if not s:
        raise ValueError("Empty amount")

    sign = 1
    # Handle accounting style: (1234.56)
    if s.startswith('(') and s.endswith(')'):
        sign = -1
        s = s[1:-1].strip()
    else:
        # Handle leading minus
        if s.startswith('-'):
            sign = -1
            s = s[1:].strip()
        elif s.startswith('+'):
            s = s[1:].strip()

    # Remove optional $
    if s.startswith('$'):
        s = s[1:]

    if not s:
        raise ValueError(f"Invalid amount: {amount_str!r}")

    # Remove commas (thousands separators)
    s = s.replace(',', '')

    # Must be a valid number
    try:
        value = float(s)
    except ValueError:
        raise ValueError(f"Invalid amount: {amount_str!r}")

    # Check for non-integer cents (more than 2 decimal places)
    if '.' in s:
        decimals = s.split('.')[1]
        if len(decimals) > 2:
            raise ValueError(f"Too many decimal places in: {amount_str!r}")

    # Round to integer cents to avoid floating-point issues
    cents = int(round(value * 100))
    return sign * cents


def parse_full_name(full_name):
    """Parse full_name into (first_name, last_name)."""
    if full_name is None:
        return ('', '')

    s = full_name.strip()
    if not s:
        return ('', '')

    # Split on whitespace (any run of whitespace counts as one)
    words = s.split()
    if not words:
        return ('', '')

    if len(words) == 1:
        return (words[0], '')
    else:
        return (' '.join(words[:-1]), words[-1])


def migrate(db_path):
    """Migrate the database in-place from v1 to v2."""
    conn = sqlite3.connect(db_path)
    conn.execute('PRAGMA journal_mode=WAL')

    try:
        user_version = conn.execute('PRAGMA user_version').fetchone()[0]
        if user_version >= 2:
            # Already v2, nothing to do
            conn.close()
            return
    except Exception:
        conn.close()
        raise

    # Make a backup to restore on failure (before any modification)
    backup_path = db_path + '.migrate.bak'
    shutil.copy2(db_path, backup_path)

    # Read all v1 data first
    v1_users = conn.execute(
        "SELECT id, email, full_name FROM users ORDER BY id"
    ).fetchall()

    v1_orders = conn.execute(
        "SELECT id, user_id, amount, created_at FROM orders"
    ).fetchall()

    conn.close()

    # Validate ALL amounts before doing any work
    parsed_orders = []
    for oid, oid_user_id, amount_str, created_at in v1_orders:
        cents = parse_amount(amount_str)
        parsed_orders.append((oid, oid_user_id, cents, created_at))

    # Step 1: Parse and normalize emails
    user_map = {}  # original_id -> (id, email_cleaned, first_name, last_name)
    users_to_delete = set()
    email_to_primary_user = {}  # cleaned_email -> smallest id with that email

    for uid, email, full_name in v1_users:
        # Trim and lowercase email
        if email is not None:
            email_clean = email.strip().lower()
        else:
            email_clean = ''

        if not email_clean:
            users_to_delete.add(uid)
            continue

        first_name, last_name = parse_full_name(full_name)
        user_map[uid] = (uid, email_clean, first_name, last_name)

        if email_clean not in email_to_primary_user:
            email_to_primary_user[email_clean] = uid

    # Step 2: Build set of valid user IDs (after dedup)
    final_users = {}  # primary_user_id -> (id, email_clean, first_name, last_name)
    for uid, email_clean, first_name, last_name in user_map.values():
        primary = email_to_primary_user[email_clean]
        if uid == primary:
            final_users[uid] = (uid, email_clean, first_name, last_name)

    # Step 3: Map orders to primary users, skip those whose user_id doesn't exist
    final_orders = []
    for oid, oid_user_id, cents, created_at in parsed_orders:
        if oid_user_id in final_users:
            primary_user_id = oid_user_id
        elif oid_user_id in user_map:
            email_clean = user_map[oid_user_id][1]
            primary_user_id = email_to_primary_user[email_clean]
        else:
            # User doesn't exist, skip the order
            continue

        # Only include if primary user is valid
        if primary_user_id in final_users:
            final_orders.append((oid, primary_user_id, cents, created_at))

    # Step 4: Now apply changes - create v2 schema
    conn = sqlite3.connect(db_path)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA foreign_keys=OFF')

    try:
        conn.execute("DROP TABLE IF EXISTS orders")
        conn.execute("DROP TABLE IF EXISTS users")

        conn.execute("""
            CREATE TABLE users (
                id INTEGER PRIMARY KEY,
                email TEXT NOT NULL UNIQUE,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL
            )
        """)

        conn.execute("""
            CREATE TABLE orders (
                id INTEGER PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id),
                amount_cents INTEGER NOT NULL,
                created_at TEXT NOT NULL
            )
        """)

        conn.execute("CREATE INDEX idx_orders_user_id ON orders(user_id)")

        # Insert users
        for uid, email_clean, first_name, last_name in final_users.values():
            conn.execute(
                "INSERT INTO users (id, email, first_name, last_name) VALUES (?, ?, ?, ?)",
                (uid, email_clean, first_name, last_name)
            )

        # Insert orders
        for oid, oid_user_id, cents, created_at in final_orders:
            conn.execute(
                "INSERT INTO orders (id, user_id, amount_cents, created_at) VALUES (?, ?, ?, ?)",
                (oid, oid_user_id, cents, created_at)
            )

        # Set user_version to 2
        conn.execute("PRAGMA user_version = 2")
        conn.commit()
    except Exception:
        conn.rollback()
        conn.close()
        # Restore from backup
        shutil.copy2(backup_path, db_path)
        os.remove(backup_path)
        raise
    finally:
        conn.close()

    # Clean up backup
    if os.path.exists(backup_path):
        os.remove(backup_path)


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("Usage: python3 migrate.py PATH", file=sys.stderr)
        sys.exit(1)
    db_path = sys.argv[1]
    migrate(db_path)
