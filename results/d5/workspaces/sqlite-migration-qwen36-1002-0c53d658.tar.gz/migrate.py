#!/usr/bin/env python3
"""Migrate SQLite database from schema v1 to v2."""
import sys
import sqlite3
import re


def parse_amount(amount_str):
    """Parse an amount string and return integer cents.

    Supported formats:
      - Plain numbers: 12, 12.5, 7.05
      - Dollar format: $1,234.50
      - Negative: -12.50, -$12.50, ($12.50), ($1,234.56)

    Returns (sign, cents). Raises ValueError on invalid input.
    """
    s = amount_str.strip()
    if not s:
        raise ValueError("empty amount")

    # Check for accounting-style parentheses: ($X.XX) or (XX.XX)
    accounting = False
    if s.startswith('('):
        if s.endswith(')'):
            accounting = True
            s = s[1:-1].strip()
        else:
            raise ValueError(f"invalid amount: {amount_str!r}")

    # Handle negative sign (either leading - or -$ prefix)
    sign = 1
    if s.startswith('-$'):
        sign = -1
        s = s[2:].strip()
    elif s.startswith('-'):
        sign = -1
        s = s[1:].strip()

    # Remove $ if present at start (after handling negative)
    if s.startswith('$'):
        s = s[1:]

    # Validate format: digits with optional commas, optional decimal part
    m = re.fullmatch(r'(\d{1,3}(,\d{3})*|\d+)(\.\d{1,2})?', s)
    if not m:
        raise ValueError(f"invalid amount format: {amount_str!r}")

    # Remove commas and parse decimal
    numeric = s.replace(',', '')
    parts = numeric.split('.')
    dollars = int(parts[0])
    cents_part = parts[1] if len(parts) > 1 else '0'
    
    # Pad or truncate to 2 decimal places
    if len(cents_part) == 0:
        cents_val = 0
    elif len(cents_part) == 1:
        cents_val = int(cents_part + '0')
    else:
        cents_val = int(cents_part[:2])

    total_cents = dollars * 100 + cents_val
    return sign * total_cents


def parse_name(full_name):
    """Parse full_name into (first_name, last_name)."""
    if not full_name or not full_name.strip():
        return ('', '')
    
    # Replace all runs of whitespace with single space, then strip
    trimmed = re.sub(r'\s+', ' ', full_name.strip())
    words = trimmed.split(' ')
    
    if len(words) == 0:
        return ('', '')
    elif len(words) == 1:
        return (words[0], '')
    else:
        last = words[-1]
        first = ' '.join(words[:-1])
        return (first, last)


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 migrate.py PATH", file=sys.stderr)
        sys.exit(1)

    path = sys.argv[1]
    
    # Open the database
    conn = sqlite3.connect(path)
    cursor = conn.cursor()
    
    # Check current version
    cursor.execute("PRAGMA user_version")
    version = cursor.fetchone()[0]
    
    if version == 2:
        # Already v2, nothing to do
        conn.close()
        return
    
    if version != 1:
        print(f"Unknown schema version: {version}", file=sys.stderr)
        sys.exit(1)
    
    # Read all users from v1 schema
    cursor.execute("SELECT id, email, full_name FROM users")
    rows = cursor.fetchall()
    
    # Parse and validate all amounts first (all-or-nothing)
    cursor.execute("SELECT id, user_id, amount, created_at FROM orders")
    order_rows = cursor.fetchall()
    
    parsed_amounts = []
    for oid, uid, amt, cat in order_rows:
        try:
            cents = parse_amount(amt)
        except ValueError as e:
            print(f"Invalid amount '{amt}': {e}", file=sys.stderr)
            conn.close()
            sys.exit(1)
        parsed_amounts.append(cents)
    
    # Process users: trim and lowercase email, filter out invalid ones
    valid_users = []  # (id, clean_email, first_name, last_name)
    for uid, email, full_name in rows:
        if email is None or not email.strip():
            continue  # skip users with NULL/blank email
        
        clean_email = email.strip().lower()
        first_name, last_name = parse_name(full_name)
        valid_users.append((uid, clean_email, first_name, last_name))
    
    # Group by cleaned email and keep only the one with smallest id
    email_to_keeper_uid = {}  # clean_email -> keeper uid (smallest id)
    for uid, clean_email, fn, ln in valid_users:
        if clean_email not in email_to_keeper_uid:
            email_to_keeper_uid[clean_email] = uid
    
    # Build a map from every valid user to their keeper's uid
    email_to_keeper = {}  # (uid) -> keeper_uid
    for uid, clean_email, fn, ln in valid_users:
        email_to_keeper[uid] = email_to_keeper_uid[clean_email]
    
    # Set of all valid user IDs that should remain as keepers
    keeper_ids = set(email_to_keeper.values())
    
    # Now process orders:
    # - Delete orders whose user_id is not a keeper
    # - Move orders from merged users to their keeper
    
    final_orders = []  # (id, new_user_id, cents, created_at)
    for i, (oid, uid, amt_str, cat) in enumerate(order_rows):
        cents = parsed_amounts[i]
        
        # Check if this order's user is valid
        if uid not in keeper_ids:
            continue  # skip - user was deleted
        
        new_user_id = email_to_keeper[uid]
        final_orders.append((oid, new_user_id, cents, cat))
    
    # Now create v2 schema and insert data
    cursor.execute("DROP TABLE IF EXISTS orders")
    cursor.execute("DROP TABLE IF EXISTS users")
    
    cursor.execute("""
        CREATE TABLE users (
            id INTEGER PRIMARY KEY,
            email TEXT NOT NULL UNIQUE,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL
        )
    """)
    
    cursor.execute("""
        CREATE TABLE orders (
            id INTEGER PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id),
            amount_cents INTEGER NOT NULL,
            created_at TEXT NOT NULL
        )
    """)
    
    cursor.execute("CREATE INDEX idx_orders_user_id ON orders(user_id)")
    
    # Insert users (sorted by id for determinism)
    keeper_users = sorted(email_to_keeper_uid.items())  # (clean_email, keeper_uid)
    for clean_email, uid in keeper_users:
        # Find the first_name and last_name for this user
        fn = ln = ''
        for u_id, c_e, f_n, l_n in valid_users:
            if c_e == clean_email:
                fn = f_n
                ln = l_n
                break
        
        cursor.execute("INSERT INTO users (id, email, first_name, last_name) VALUES (?, ?, ?, ?)",
                      (uid, clean_email, fn, ln))
    
    # Insert orders (keep original order from the data)
    for oid, new_uid, cents, cat in final_orders:
        cursor.execute("INSERT INTO orders (id, user_id, amount_cents, created_at) VALUES (?, ?, ?, ?)",
                      (oid, new_uid, cents, cat))
    
    # Set version to 2
    cursor.execute("PRAGMA user_version = 2")
    
    conn.commit()
    conn.close()


if __name__ == "__main__":
    main()
