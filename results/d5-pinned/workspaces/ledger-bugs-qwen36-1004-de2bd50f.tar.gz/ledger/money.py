from decimal import Decimal, ROUND_HALF_UP


def to_cents(text: str) -> int:
    """Parse a decimal amount string into integer cents."""
    text = text.strip()
    import re
    if not re.fullmatch(r'[+-]?\d+(\.\d+)?', text):
        raise ValueError(f"invalid amount: {text!r}")
    d = Decimal(text).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    return int(d * 100)


def split(total_cents: int, n: int) -> list[int]:
    """Split an amount into n near-equal parts."""
    if n < 1:
        raise ValueError(f"n must be >= 1, got {n}")
    part = total_cents // n
    remainder = total_cents - part * n
    if total_cents < 0:
        # For negative: part is more negative (larger abs), part+1 is less negative
        # We want larger abs first, so put part first, part+1 after
        # remainder elements need to be (part+1) (closer to zero, smaller abs)
        # n - remainder elements stay as part (more negative, larger abs)
        return [part if i < (n - remainder) else part + 1 for i in range(n)]
    else:
        return [part + (1 if i < remainder else 0) for i in range(n)]


def allocate(total_cents: int, weights: list[int]) -> list[int]:
    """Split an amount in proportion to weights."""
    if not weights:
        raise ValueError("weights list is empty")
    if any(w < 0 for w in weights):
        raise ValueError("weights must be non-negative")
    total_w = sum(weights)
    if total_w == 0:
        raise ValueError("weights sum to zero")

    exact = [Decimal(total_cents) * w / total_w for w in weights]
    truncated = [int(e) for e in exact]
    remainder = total_cents - sum(truncated)

    # Fractional parts (the discarded amount)
    frac = [e - int(e) for e in exact]
    # Sort by (-frac, index) so largest frac wins, ties go to lower index
    order = sorted(range(len(weights)), key=lambda i: (-frac[i], i))
    for i in order[:remainder]:
        truncated[i] += 1

    return truncated
