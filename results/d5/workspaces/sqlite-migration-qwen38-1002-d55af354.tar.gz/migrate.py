#!/usr/bin/env python3
import sys
import re
import sqlite3
import shutil
import os


def parse_amount(s):
    if s is None:
        raise ValueError("amount is None")
    s = s.strip()
    if not s:
        raise ValueError("amount is empty")
    negative = False
    if s.startswith('(') and s.endswith(')'):
        negative = True
        s = s[1:-1].strip()
    if s.startswith('-'):
        negative = True
        s = s[1:].strip()
    if s.startswith('$'):
        s = s[1:]
    s = s.strip()
    s = s.replace(',', '')
    m = re.match(r'^(\d+)(?:\.(\d{1,2}))?$', s)
    if not m:
        raise ValueError("Invalid amount: " + repr(s))
    integer_part = m.group(1)
    decimal_part = m.group(2) or ''
    cents = int(integer_part) * 100
    if decimal_part:
        decimal_part = decimal_part + '0' * (2 - len(decimal_part))
        cents += int(decimal_part)
    if negative:
        cents = -cents
    return cents


def split_name(full_name):
    if full_name is None:
        return '', ''
    s = full_name.strip()
    s = re.sub(r'\s+', ' ', s)
    if not s:
        return '', ''
    words = s.split(' ')
    if len(words) == 1:
        return words[0], ''
    last_name = words[-1]
    first_name = ' '.join(words[:-1])
    return first_name, last_name


def migrate(path):
    backup_path = path + '.backup'
    shutil.copy2(path, backup_path)
    try:
        conn = sqlite3.connect(path)
        version = conn.execute('PRAGMA user_version').fetchone()[0]
        if version == 2:
            conn.close()
            os.remove(backup_path)
            return
        if version != 1:
            conn.close()
            os.remove(backup_path)
            raise ValueError("Unexpected user_version: " + str(version))
        users = conn.execute('SELECT id, email, full_name FROM users ORDER BY id').fetchall()
        orders = conn.execute('SELECT id, user_id, amount, created_at FROM orders ORDER BY id').fetchall()
        conn.close()

        # Step 1: Identify users to delete (NULL or blank email)
        # and compute clean emails for surviving users
        surviving = []  # list of (uid, clean_email, first_name, last_name)
        deleted_user_ids = set()
        for uid, email, full_name in users:
            if email is None:
                deleted_user_ids.add(uid)
                continue
            clean_email = email.strip().lower()
            if not clean_email:
                deleted_user_ids.add(uid)
                continue
            first_name, last_name = split_name(full_name)
            surviving.append((uid, clean_email, first_name, last_name))

        # Step 2: Among surviving users, if duplicates by email, keep smallest id
        user_map = {}  # clean_email -> uid
        deleted_user_ids2 = set()
        for uid, clean_email, first_name, last_name in surviving:
            if clean_email in user_map:
                deleted_user_ids2.add(uid)
            else:
                user_map[clean_email] = uid

        # All deleted users (blank email or duplicate)
        all_deleted = deleted_user_ids | deleted_user_ids2

        # Build mapping from old user_id to new user_id
        # For duplicate users that are deleted, map to the surviving user with same email
        user_id_map = {}
        for uid, email, full_name in users:
            if uid in deleted_user_ids:
                user_id_map[uid] = None  # blank email user, orders deleted
            elif uid in deleted_user_ids2:
                # Duplicate email, map to surviving user
                clean_email = email.strip().lower()
                user_id_map[uid] = user_map[clean_email]
            else:
                user_id_map[uid] = uid

        # Build user insert data: email -> (uid, first_name, last_name)
        user_inserts = {}
        for uid, clean_email, first_name, last_name in surviving:
            if uid not in deleted_user_ids2:
                user_inserts[uid] = (clean_email, first_name, last_name)

        # Process orders
        new_orders = []
        for oid, user_id, amount, created_at in orders:
            if user_id not in user_id_map:
                continue  # orphan order
            new_user_id = user_id_map[user_id]
            if new_user_id is None:
                continue  # order for blank-email user
            cents = parse_amount(amount)
            new_orders.append((oid, new_user_id, cents, created_at))

        # Perform migration
        conn = sqlite3.connect(path)
        conn.execute('PRAGMA journal_mode=WAL')
        conn.execute('BEGIN')
        try:
            conn.execute('DROP TABLE IF EXISTS orders')
            conn.execute('DROP TABLE IF EXISTS users')
            conn.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, email TEXT NOT NULL UNIQUE, first_name TEXT NOT NULL, last_name TEXT NOT NULL)")
            conn.execute("CREATE TABLE orders (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), amount_cents INTEGER NOT NULL, created_at TEXT NOT NULL)")
            conn.execute('CREATE INDEX idx_orders_user_id ON orders(user_id)')
            for uid in sorted(user_inserts.keys()):
                clean_email, first_name, last_name = user_inserts[uid]
                conn.execute('INSERT INTO users (id, email, first_name, last_name) VALUES (?, ?, ?, ?)', (uid, clean_email, first_name, last_name))
            for oid, new_user_id, cents, created_at in new_orders:
                conn.execute('INSERT INTO orders (id, user_id, amount_cents, created_at) VALUES (?, ?, ?, ?)', (oid, new_user_id, cents, created_at))
            conn.execute('PRAGMA user_version = 2')
            conn.commit()
            conn.close()
            os.remove(backup_path)
        except Exception:
            conn.rollback()
            conn.close()
            shutil.copy2(backup_path, path)
            os.remove(backup_path)
            raise
    except Exception:
        if os.path.exists(backup_path):
            os.remove(backup_path)
        raise


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("Usage: python3 migrate.py PATH", file=sys.stderr)
        sys.exit(1)
    path = sys.argv[1]
    try:
        migrate(path)
    except Exception as e:
        print("Migration failed: " + str(e), file=sys.stderr)
        sys.exit(1)
