def page(items, number, size):
    """Return one page of items."""
    if number < 1:
        raise ValueError("page number must be >= 1")
    if size < 1:
        raise ValueError("page size must be >= 1")
    start = (number - 1) * size
    return items[start:start + size]
