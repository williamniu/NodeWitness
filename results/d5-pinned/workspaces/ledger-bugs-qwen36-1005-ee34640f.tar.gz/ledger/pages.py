def page(items, number, size):
    """Return one page of items.

    Pages are 1-indexed: page 1 is items[0:size].
    A page past the end returns [].
    """
    if number < 1:
        raise ValueError("number must be >= 1")
    if size < 1:
        raise ValueError("size must be >= 1")
    start = (number - 1) * size
    return items[start:start + size]
