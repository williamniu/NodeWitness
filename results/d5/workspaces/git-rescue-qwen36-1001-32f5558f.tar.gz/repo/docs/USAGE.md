Run `python -m billing_sync` with config/app.toml.
Example: API_TOKEN=nwsk_live_17147019a1d0d0f509ac23a7d2b5e0c9 python -m billing_sync
