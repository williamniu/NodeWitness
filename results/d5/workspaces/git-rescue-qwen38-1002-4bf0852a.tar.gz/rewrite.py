import subprocess, hashlib, os

os.chdir('/workspace/repo')

def gitb(*args):
    return subprocess.run(['git']+list(args), capture_output=True).stdout

def sha1(data):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\x00'+data).hexdigest()

T1 = b'nwsk_live_c98e9ecce3c50f41a67af8c7c2ba4ac6'
T2 = b'nwsk_live_281ae73f435e4d6a23d09afb714a8e08'

# 1. redacted USAGE.md blob
usage = gitb('show','d6515f1:docs/USAGE.md')
usage_red = usage.replace(T1, b'REDACTED')
usage_red_sha = sha1(usage_red)
subprocess.run(['git','hash-object','-w','--stdin'], input=usage_red, check=True)
print('usage_red blob', usage_red_sha)

# 2. trees via mktree --batch
def make_tree(entries):
    # entries: list of (mode, type, sha, name)
    lines = ''
    for mode,typ,sha,name in entries:
        lines += mode+' '+typ+' '+sha+'\t'+name+'\n'
    r = subprocess.run(['git','mktree','--batch'], input=lines.encode(), capture_output=True, check=True)
    return r.stdout.decode().split()[0]

app_sha = gitb('rev-parse','6d21507:config/app.toml').strip().decode()
config_tree = make_tree([('100644','blob',app_sha,'app.toml')])
print('config_tree', config_tree)

readme = gitb('rev-parse','6d21507:README.md').strip().decode()
parser = gitb('rev-parse','6d21507:parser.py').strip().decode()
tree_6d = make_tree([
 ('100644','blob',readme,'README.md'),
 ('040000','tree',config_tree,'config'),
 ('100644','blob',parser,'parser.py'),
])
print('tree_6d', tree_6d)

docs_tree = make_tree([('100644','blob',usage_red_sha,'USAGE.md')])
print('docs_tree', docs_tree)
tree_d8 = make_tree([
 ('100644','blob',readme,'README.md'),
 ('040000','tree',config_tree,'config'),
 ('040000','tree',docs_tree,'docs'),
 ('100644','blob',parser,'parser.py'),
])
print('tree_d8', tree_d8)
tree_9b = tree_d8

feature = gitb('rev-parse','d6515f1:feature.py').strip().decode()
tree_d6 = make_tree([
 ('100644','blob',readme,'README.md'),
 ('040000','tree',config_tree,'config'),
 ('040000','tree',docs_tree,'docs'),
 ('100644','blob',feature,'feature.py'),
 ('100644','blob',parser,'parser.py'),
])
print('tree_d6', tree_d6)
tree_1c = tree_d8

# 3. commits
def write_commit(orig_sha, new_tree):
    raw = gitb('cat-file','-p',orig_sha)
    out=[]
    for ln in raw.split(b'\n'):
        if ln.startswith(b'tree '):
            out.append(b'tree '+new_tree.encode())
        else:
            out.append(ln)
    body = b'\n'.join(out)
    h = hashlib.sha1(b'commit '+str(len(body)).encode()+b'\x00'+body).hexdigest()
    subprocess.run(['git','hash-object','-w','--stdin','-t','commit'], input=body, check=True)
    return h

c6d = write_commit('6d21507', tree_6d); print('c6d', c6d)
cd8 = write_commit('d8e9186', tree_d8); print('cd8', cd8)
c9b = write_commit('9b486de', tree_9b); print('c9b', c9b)
cd6 = write_commit('d6515f1', tree_d6); print('cd6', cd6)
c1c = write_commit('1ca3034', tree_1c); print('c1c', c1c)

# 4. annotated tag
tagmsg = gitb('cat-file','-p','abfdd30')
tout=[]
for ln in tagmsg.split(b'\n'):
    if ln.startswith(b'object '):
        tout.append(b'object '+cd8.encode())
    else:
        tout.append(ln)
tagbody = b'\n'.join(tout)
th = hashlib.sha1(b'tag '+str(len(tagbody)).encode()+b'\x00'+tagbody).hexdigest()
subprocess.run(['git','hash-object','-w','--stdin','-t','tag'], input=tagbody, check=True)
print('tag', th)

# 5. refs
subprocess.run(['git','update-ref','refs/heads/main', cd6])
subprocess.run(['git','update-ref','refs/heads/release/1.x', c1c])
subprocess.run(['git','update-ref','refs/tags/v0.1', th])
subprocess.run(['git','update-ref','-d','refs/heads/backup/pre-cleanup'])
subprocess.run(['git','update-ref','-d','refs/stash'])
print('DONE')
