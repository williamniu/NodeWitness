from datetime import datetime, timezone


def parse_ts(text):
    """Parse an ISO 8601 timestamp with Z or +/-HH:MM offset, convert to UTC."""
    s = text.strip()
    if not s:
        raise ValueError("empty timestamp")
    if s.endswith('Z') or s.endswith('z'):
        s = s[:-1] + '+00:00'
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        raise ValueError(repr(text))
    if dt.tzinfo is None:
        raise ValueError("timestamp must include an offset")
    return dt.astimezone(timezone.utc)


def day_bucket(text):
    """UTC calendar day of a timestamp."""
    return parse_ts(text).strftime("%Y-%m-%d")
