from decimal import Decimal, ROUND_HALF_UP


def to_cents(text):
    """Parse a decimal amount string into integer cents."""
    text = text.strip()
    d = Decimal(text) * 100
    return int(d.quantize(Decimal('1'), rounding=ROUND_HALF_UP))


def split(total_cents, n):
    """Split an amount into n near-equal parts."""
    if n < 1:
        raise ValueError("n must be >= 1")

    if total_cents == 0:
        return [0] * n

    abs_total = abs(total_cents)
    base = abs_total // n
    remainder = abs_total % n

    if total_cents < 0:
        result = [-(base + 1)] * remainder + [-base] * (n - remainder)
    else:
        result = [base + 1] * remainder + [base] * (n - remainder)

    return result


def allocate(total_cents, weights):
    """Split an amount in proportion to weights."""
    if not weights or any(w < 0 for w in weights) or sum(weights) == 0:
        raise ValueError("Invalid weights")

    total_weight = sum(weights)

    # Compute exact shares and truncate toward zero
    exact_shares = [Decimal(total_cents * w) / Decimal(total_weight) for w in weights]
    truncated = [int(e.to_integral_value(rounding='ROUND_DOWN')) for e in exact_shares]

    # Fractional remainders: how much each part is short (always non-negative when
    # truncated toward zero from below, but can be negative when truncating up)
    # We use the absolute fractional remainder as the tiebreaker key.
    frac_parts = [abs(e - Decimal(truncated[i])) for i, e in enumerate(exact_shares)]

    leftover = total_cents - sum(truncated)

    if leftover > 0:
        order = sorted(range(len(weights)), key=lambda i: (-frac_parts[i], i))
        for i in range(leftover):
            truncated[order[i]] += 1
    elif leftover < 0:
        # Need to subtract. Give -leftover more to parts with LARGEST abs remainder.
        order = sorted(range(len(weights)), key=lambda i: (frac_parts[i], i))
        for i in range(-leftover):
            truncated[order[i]] -= 1

    return truncated
