import subprocess, os, sys

REPO = "/workspace/repo"

def git(args, input=None, env=None):
    full_env = dict(os.environ)
    if env:
        full_env.update(env)
    r = subprocess.run(["git"] + list(args), cwd=REPO, capture_output=True, text=True, input=input, env=full_env)
    if r.returncode != 0:
        print(f"CMD FAILED: git {' '.join(args)}\nSTDOUT: {r.stdout}\nSTDERR: {r.stderr}", file=sys.stderr)
        sys.exit(1)
    return r.stdout.strip()

def mktree(entries):
    """Create a tree from a list of (mode, type, sha, name) tuples"""
    input_str = "\n".join(f"{mode} {type} {sha}\t{name}" for mode, type, sha, name in entries) + "\n"
    return git(["mktree", "--missing"], input=input_str)

def commit_tree(tree, parent, msg, author_date, committer_date=None):
    """Create a commit object"""
    if committer_date is None:
        committer_date = author_date
    env = {
        "GIT_AUTHOR_NAME": "Dev",
        "GIT_AUTHOR_EMAIL": "dev@example.test",
        "GIT_AUTHOR_DATE": author_date,
        "GIT_COMMITTER_NAME": "Dev",
        "GIT_COMMITTER_EMAIL": "dev@example.test",
        "GIT_COMMITTER_DATE": committer_date,
    }
    args = ["commit-tree", tree]
    if parent:
        args.extend(["-p", parent])
    args.append("-m")
    args.append(msg)
    return git(args, env=env)

# === Step 1: Create clean blob for USAGE.md ===
usage_clean = "Run `python -m billing_sync` with config/app.toml.\nExample: API_TOKEN=REDACTED python -m billing_sync\n"
usage_blob = git(["hash-object", "-w", "--stdin"], input=usage_clean)
print(f"usage_blob={usage_blob}")

# === Step 2: Create clean trees ===
# config tree without secrets.env (just app.toml)
config_tree = mktree([
    ("100644", "blob", "2b259683e89fafe9b5b378acb70a19a1f2d83d1b", "app.toml"),
])
print(f"config_tree={config_tree}")

# docs tree with clean USAGE.md
docs_tree = mktree([
    ("100644", "blob", usage_blob, "USAGE.md"),
])
print(f"docs_tree={docs_tree}")

# Tree for "add config" (7e775c0 -> new): README.md + config/ + parser.py(b8e6cb5)
tree_add_config = mktree([
    ("100644", "blob", "361b2955ee4d07bb84b65712f72ddf9c9c3dbd43", "README.md"),
    ("040000", "tree", config_tree, "config"),
    ("100644", "blob", "b8e6cb5b74507c2fede5cec31800b73b2f9db742", "parser.py"),
])
print(f"tree_add_config={tree_add_config}")

# Tree for "tune parser" (d14ed10 -> new): README.md + config/ + parser.py(67fb2a9)
tree_tune_parser = mktree([
    ("100644", "blob", "361b2955ee4d07bb84b65712f72ddf9c9c3dbd43", "README.md"),
    ("040000", "tree", config_tree, "config"),
    ("100644", "blob", "67fb2a99da37b774cc4bcc99dfc99abdf685157e", "parser.py"),
])
print(f"tree_tune_parser={tree_tune_parser}")

# Tree for "add usage docs" (4994a3f -> new): README.md + config/ + docs/ + parser.py(67fb2a9)
tree_add_usage = mktree([
    ("100644", "blob", "361b2955ee4d07bb84b65712f72ddf9c9c3dbd43", "README.md"),
    ("040000", "tree", config_tree, "config"),
    ("040000", "tree", docs_tree, "docs"),
    ("100644", "blob", "67fb2a99da37b774cc4bcc99dfc99abdf685157e", "parser.py"),
])
print(f"tree_add_usage={tree_add_usage}")

# Tree for "hotfix" (3c2ceeb -> new): README.md + config/ + parser.py(59c0f05)
tree_hotfix = mktree([
    ("100644", "blob", "361b2955ee4d07bb84b65712f72ddf9c9c3dbd43", "README.md"),
    ("040000", "tree", config_tree, "config"),
    ("100644", "blob", "59c0f05f324ab1c4009f0c7e4a742f420c0f983c", "parser.py"),
])
print(f"tree_hotfix={tree_hotfix}")

# Tree for "add feature flag" (f8712af -> new): README.md + config/ + docs/ + feature.py + parser.py
tree_feature = mktree([
    ("100644", "blob", "361b2955ee4d07bb84b65712f72ddf9c9c3dbd43", "README.md"),
    ("040000", "tree", config_tree, "config"),
    ("040000", "tree", docs_tree, "docs"),
    ("100644", "blob", "48c4da18b2f86fd3f2aa0ea87805822d8ef99399", "feature.py"),
    ("100644", "blob", "67fb2a99da37b774cc4bcc99dfc99abdf685157e", "parser.py"),
])
print(f"tree_feature={tree_feature}")

# === Step 3: Create clean commits ===
# "add config" - parent d0b1c82, date 1791028800
commit_add_config = commit_tree(tree_add_config, "d0b1c825a7949008038952d2616c9a6e0c0be2ca",
    "add config", "1791028800 +0000")
print(f"commit_add_config={commit_add_config}")

# "tune parser" - parent add_config, date 1791115200
commit_tune_parser = commit_tree(tree_tune_parser, commit_add_config,
    "tune parser", "1791115200 +0000")
print(f"commit_tune_parser={commit_tune_parser}")

# "add usage docs" - parent tune_parser, date 1791201600
commit_add_usage = commit_tree(tree_add_usage, commit_tune_parser,
    "add usage docs", "1791201600 +0000")
print(f"commit_add_usage={commit_add_usage}")

# "hotfix: skip empty lines" - parent tune_parser, date 1791460800
commit_hotfix = commit_tree(tree_hotfix, commit_tune_parser,
    "hotfix: skip empty lines", "1791460800 +0000")
print(f"commit_hotfix={commit_hotfix}")

# "add feature flag" - parent add_usage, date 1791288000
commit_feature = commit_tree(tree_feature, commit_add_usage,
    "add feature flag", "1791288000 +0000")
print(f"commit_feature={commit_feature}")

# === Step 4: Create annotated tag v0.1 pointing to tune_parser ===
# Original tag: tagger Dev <dev@example.test> 1791118800 +0000, message "first release"
env_tag = {
    "GIT_COMMITTER_NAME": "Dev",
    "GIT_COMMITTER_EMAIL": "dev@example.test",
    "GIT_COMMITTER_DATE": "1791118800 +0000",
}
tag_obj = git(["tag", "-a", "v0.1", "-m", "first release", commit_tune_parser], env=env_tag)
print(f"tag_v0.1 created")

# === Step 5: Set up refs ===
# main -> commit_feature
git(["update-ref", "refs/heads/main", commit_feature])
# release/1.x -> commit_hotfix
git(["update-ref", "refs/heads/release/1.x", commit_hotfix])
# Delete backup/pre-cleanup
git(["update-ref", "-d", "refs/heads/backup/pre-cleanup"])
# Delete stash
git(["update-ref", "-d", "refs/stash"])

# === Step 6: Set HEAD to main ===
git(["symbolic-ref", "HEAD", "refs/heads/main"])

# === Step 7: Reset index to match main ===
git(["reset", "--hard", "main"])

# === Step 8: Pack and prune ===
# First, let's remove old objects by repacking
git(["gc", "--prune=now", "--aggressive"])

# === Step 9: Verify ===
print("\n=== Verification ===")
print("main log:")
print(git(["log", "--oneline", "main"]))
print("\nrelease/1.x log:")
print(git(["log", "--oneline", "release/1.x"]))
print("\nAll refs:")
print(git(["show-ref"]))
print("\nHEAD:")
print(git(["symbolic-ref", "HEAD"]))
print("\nStatus:")
print(git(["status", "--porcelain"]))
print("\nToken search in all reachable objects:")
result = subprocess.run(["git", "rev-list", "--all", "--objects"], cwd=REPO, capture_output=True, text=True)
for line in result.stdout.strip().split("\n"):
    if not line:
        continue
    sha = line.split()[0]
    r = subprocess.run(["git", "cat-file", "-p", sha], cwd=REPO, capture_output=True, text=True)
    if "nwsk_live" in r.stdout:
        print(f"  FOUND TOKEN in {sha}: {line}")

print("\nDone!")
