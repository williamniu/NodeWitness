#!/usr/bin/env python3
import sys, os, json, gzip, math, io
from datetime import datetime, timezone, timedelta

def parse_iso(s):
    """Parse ISO 8601 datetime string to a datetime with timezone info."""
    s = s.strip()
    if s.endswith('Z'):
        s = s[:-1] + '+00:00'
    try:
        dt = datetime.fromisoformat(s)
        return dt
    except:
        return None

def parse_latency(val):
    """Parse latency_ms value which can be int, float, or string like '412ms'."""
    if isinstance(val, (int, float)):
        return int(val)
    s = str(val).strip()
    if s.endswith('ms'):
        s = s[:-2].strip()
    return int(float(s))

def parse_status(val):
    """Parse status which can be int, float, or string of digits."""
    if isinstance(val, (int, float)):
        return int(val)
    s = str(val).strip()
    return int(float(s))

def parse_json_line(line):
    """Try to parse a JSON log line."""
    try:
        obj = json.loads(line)
    except:
        return None
    if not isinstance(obj, dict):
        return None
    ts_raw = obj.get('ts')
    user_raw = obj.get('user')
    req_id = obj.get('request_id')
    status_raw = obj.get('status')
    latency_raw = obj.get('latency_ms')
    if ts_raw is None or user_raw is None or req_id is None:
        return None
    ts = parse_iso(str(ts_raw))
    if ts is None:
        return None
    status = parse_status(status_raw)
    latency = parse_latency(latency_raw)
    return (ts, user_raw.lower(), req_id, status, latency)

def parse_legacy_line(line):
    """Try to parse a legacy format line."""
    import re
    m = re.match(
        r'^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2}))\s+'
        r'user=(\S+)\s+'
        r'req=(\S+)\s+'
        r'status=(\S+)\s+'
        r'ms=(\S+)',
        line
    )
    if not m:
        return None
    ts = parse_iso(m.group(1))
    if ts is None:
        return None
    return (ts, m.group(2).lower(), m.group(3),
            parse_status(m.group(4)),
            parse_latency(m.group(5)))

def read_lines(filepath):
    """Read all complete lines from a file, handling truncated .gz gracefully."""
    if filepath.endswith('.gz'):
        # First try: normal gzip read
        try:
            with gzip.open(filepath, 'rt', errors='replace') as f:
                return f.readlines()
        except Exception:
            pass
        
        # Fallback: try to decompress what's valid from the gzip file
        try:
            with open(filepath, 'rb') as f:
                data = f.read()
            
            # Binary search for the largest valid gzip decompression
            lo, hi = 0, len(data)
            result = None
            while lo <= hi:
                mid = (lo + hi) // 2
                try:
                    obj = gzip.GzipFile(fileobj=io.BytesIO(data[:mid]), mode='rb')
                    result = obj.read()
                    obj.close()
                    lo = mid + 1
                except:
                    hi = mid - 1
            
            if result is not None:
                text = result.decode('utf-8', errors='replace')
                lines = text.split('\n')
                # Keep only complete lines (those that had trailing newline in original)
                result_lines = []
                for i, line in enumerate(lines):
                    if i < len(lines) - 1:
                        result_lines.append(line + '\n')
                return result_lines
        except:
            pass
        
        return []
    else:
        with open(filepath, 'r', errors='replace') as f:
            return f.readlines()

def main():
    if len(sys.argv) < 2:
        print("Usage: p95.py LOGDIR", file=sys.stderr)
        sys.exit(1)
    
    logdir = sys.argv[1]
    
    # Collect all request data: key = request_id, value = (latest_ts, user, status, latency)
    requests = {}  # request_id -> (ts, user, status, latency)
    
    # Find matching log files
    for fname in os.listdir(logdir):
        # Only app.log, app.log.N, app.log.N.gz
        if fname == 'app.log':
            pass
        elif fname.startswith('app.log.'):
            suffix = fname[8:]  # after 'app.log.'
            if suffix == 'gz':
                pass
            else:
                # Check if it's app.log.N where N is positive integer
                if not suffix.isdigit() or int(suffix) <= 0:
                    continue
        else:
            continue
        
        filepath = os.path.join(logdir, fname)
        if not os.path.isfile(filepath):
            continue
        
        lines = read_lines(filepath)
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            result = parse_json_line(line) or parse_legacy_line(line)
            if result is None:
                continue
            
            ts, user, req_id, status, latency = result
            
            # Keep the attempt with the latest timestamp
            if req_id in requests:
                existing_ts = requests[req_id][0]
                # Compare instants: convert to UTC for comparison
                if ts.tzinfo is not None:
                    ts_utc = ts.astimezone(timezone.utc)
                else:
                    ts_utc = ts.replace(tzinfo=timezone.utc)
                
                if existing_ts.tzinfo is not None:
                    existing_utc = existing_ts.astimezone(timezone.utc)
                else:
                    existing_utc = existing_ts.replace(tzinfo=timezone.utc)
                
                if ts_utc <= existing_utc:
                    continue
            
            requests[req_id] = (ts, user, status, latency)
    
    # Find failures: last attempt has status >= 500
    user_failures = {}  # user -> list of latencies
    for req_id, (ts, user, status, latency) in requests.items():
        if status >= 500:
            if user not in user_failures:
                user_failures[user] = []
            user_failures[user].append(latency)
    
    # Compute p95 for each user
    rows = []
    for user, latencies in user_failures.items():
        n = len(latencies)
        if n == 0:
            continue
        sorted_lat = sorted(latencies)
        rank = math.ceil(0.95 * n)  # 1-based
        p95 = sorted_lat[rank - 1]  # convert to 0-based
        rows.append((user, n, p95))
    
    # Sort by failures descending, then user ascending
    rows.sort(key=lambda x: (-x[1], x[0]))
    
    print("user,failures,p95_ms")
    for user, failures, p95 in rows:
        print(f"{user},{failures},{p95}")

if __name__ == '__main__':
    main()
