from datetime import datetime, timezone, timedelta


def parse_ts(text):
    """Parse an ISO 8601 timestamp and return it in UTC."""
    text = text.strip()
    
    # Check for Z suffix (UTC)
    if text.endswith('Z'):
        base = text[:-1]
        dt = datetime.fromisoformat(base)
        if dt.tzinfo is not None:
            raise ValueError("Unexpected timezone info after removing Z")
        return dt.replace(tzinfo=timezone.utc)
    
    # Must have timezone offset (+HH:MM or -HH:MM at end)
    if '+' not in text[10:] and '-' not in text[10:].replace('+', ''):
        raise ValueError("Timestamp missing timezone offset")
    
    dt = datetime.fromisoformat(text)
    if dt.tzinfo is None:
        raise ValueError("Timestamp has no timezone info")
    
    # Convert to UTC
    return dt.astimezone(timezone.utc)


def day_bucket(text):
    """UTC calendar day of a timestamp."""
    return parse_ts(text).strftime("%Y-%m-%d")
