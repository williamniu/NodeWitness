from datetime import datetime, timezone


def parse_ts(text):
    """Parse an ISO 8601 timestamp with an offset, returning UTC-aware datetime."""
    if not isinstance(text, str):
        raise ValueError(text)
    s = text.strip()
    if not s:
        raise ValueError(text)
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    dt = datetime.fromisoformat(s)
    if dt.tzinfo is None:
        raise ValueError("timestamp must include an offset")
    return dt.astimezone(timezone.utc)


def day_bucket(text):
    """UTC calendar day of a timestamp."""
    return parse_ts(text).strftime("%Y-%m-%d")
