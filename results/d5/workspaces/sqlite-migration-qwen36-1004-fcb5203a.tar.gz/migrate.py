#!/usr/bin/env python3
"""Migrate SQLite database from schema v1 to v2."""

import re
import sqlite3
import sys


def parse_amount(raw):
    """Parse amount string into integer cents.

    Supported formats:
      - "746.03", "-$1937.70"
      - "$2,261.23"
      - "(2693.41)", "($1673.04)"  (accounting-style negatives)

    Raises ValueError on any unrecognized format.
    """
    s = raw.strip()
    negative = False

    # Detect accounting-style negatives: (xxx) or ($xxx)
    if s.startswith('('):
        negative = True
        s = s[1:]
        if not s.endswith(')'):
            raise ValueError(f"Unbalanced parenthesis in amount: {raw!r}")
        s = s[:-1]

    # Remove any $ signs (could be anywhere in the string like -$xxx or $xxx)
    s = s.replace('$', '')

    # Now handle leading minus sign for explicit negatives like "-$12.50"
    if s.startswith('-'):
        negative = True
        s = s[1:]

    s = s.strip()

    if not s:
        raise ValueError(f"No digits in amount: {raw!r}")

    # Validate format: digits with optional comma thousands separator, optionally .dd
    if not re.match(r'^\d+(,\d{3})*(\.\d{1,2})?$', s):
        raise ValueError(f"Invalid amount format: {raw!r}")

    parts = s.split('.')
    dollars_str = parts[0].replace(',', '')
    cents_str = parts[1] if len(parts) > 1 else '0'

    # Pad or truncate to exactly 2 decimal places
    if len(cents_str) == 0:
        cents_val = 0
    elif len(cents_str) == 1:
        cents_val = int(cents_str + '0')
    elif len(cents_str) > 2:
        raise ValueError(f"Too many decimal places in amount: {raw!r}")
    else:
        cents_val = int(cents_str)

    total_cents = int(dollars_str) * 100 + cents_val
    return -total_cents if negative else total_cents


def split_name(full_name):
    """Split full_name into (first_name, last_name).

    Rules:
      - Trim the input.
      - Treat any run of whitespace as a single space.
      - Last word is last_name; everything before is first_name.
      - One word: first_name = that word, last_name = ''.
      - Empty/None: both empty strings.
    """
    if full_name is None or not full_name.strip():
        return ('', '')

    words = full_name.split()  # split on any whitespace
    if not words:
        return ('', '')

    last = words[-1]
    first = ' '.join(words[:-1])
    return (first, last)


def main():
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} PATH", file=sys.stderr)
        sys.exit(1)

    path = sys.argv[1]

    # Check if already v2 — nothing to do
    conn = sqlite3.connect(path)
    try:
        version = conn.execute('PRAGMA user_version').fetchone()[0]
        if version >= 2:
            conn.close()
            return
    except Exception:
        conn.close()
        sys.exit(1)

    # Read all v1 data before any mutation (for rollback on parse error)
    users = conn.execute('SELECT id, email, full_name FROM users ORDER BY id').fetchall()
    orders = conn.execute('SELECT id, user_id, amount, created_at FROM orders ORDER BY id').fetchall()

    # --- Validate all amounts first (atomicity guarantee) ---
    parsed_amounts = []
    for oid, uid, raw_amt, _ in orders:
        try:
            parsed_amounts.append(parse_amount(raw_amt))
        except ValueError as e:
            conn.close()
            print(f"Invalid amount {raw_amt!r} on order {oid}: {e}", file=sys.stderr)
            sys.exit(1)

    # --- Phase 1: Build set of valid user IDs (by trimmed, lower-cased email) ---
    # A user is "valid" if their trimmed+lowered email is non-empty.
    # Users with NULL or blank email are deleted along with their orders.
    valid_user_ids = set()
    for uid, raw_email, _ in users:
        if raw_email is None:
            continue
        email = raw_email.strip().lower()
        if not email:
            continue
        valid_user_ids.add(uid)

    # For duplicate emails among valid users, keep only the smallest id.
    # Orders from duplicate users (non-smallest) go to the surviving user.
    best_user_for_email = {}   # email_str -> smallest id with that email
    for uid in sorted(valid_user_ids):
        raw_email = next(r[1] for r in users if r[0] == uid)
        email = raw_email.strip().lower()
        if email not in best_user_for_email or uid < best_user_for_email[email]:
            best_user_for_email[email] = uid

    # --- Phase 2: Build new users table rows (only keep the "best" user per email) ---
    new_users = {}  # id -> (email, first_name, last_name)
    for uid in sorted(valid_user_ids):
        raw_email = next(r[1] for r in users if r[0] == uid)
        full_name = next(r[2] for r in users if r[0] == uid)
        email = raw_email.strip().lower()
        fn, ln = split_name(full_name)
        # Only keep this user if it's the one with the smallest id for this email
        if best_user_for_email[email] == uid:
            new_users[uid] = (email, fn, ln)

    # --- Phase 3: Build new orders table rows ---
    # Keep order if its user_id is in valid_user_ids.
    # If the user_id was from a "duplicate" user, reassign to surviving user.
    new_orders = []
    for (oid, uid, _, created_at), amt in zip(orders, parsed_amounts):
        if uid not in valid_user_ids:
            continue
        final_uid = best_user_for_email.get(None)  # placeholder
        # Map order's user_id to the surviving user with same email
        raw_email_map = {r[0]: r[1] for r in users}
        if uid in raw_email_map:
            e = raw_email_map[uid].strip().lower()
            final_uid = best_user_for_email[e]
        else:
            final_uid = uid
        new_orders.append((oid, final_uid, amt, created_at))

    conn.close()

    # --- Phase 4: Apply migration (in place) ---
    conn = sqlite3.connect(path)
    try:
        conn.execute('BEGIN')
        conn.execute('DROP TABLE IF EXISTS orders')
        conn.execute('DROP TABLE IF EXISTS users')
        conn.execute('''
            CREATE TABLE users(
                id INTEGER PRIMARY KEY,
                email TEXT NOT NULL UNIQUE,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL
            )
        ''')
        conn.execute('''
            CREATE TABLE orders(
                id INTEGER PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id),
                amount_cents INTEGER NOT NULL,
                created_at TEXT NOT NULL
            )
        ''')
        conn.execute('CREATE INDEX idx_orders_user_id ON orders(user_id)')

        for uid in sorted(new_users.keys()):
            email, fn, ln = new_users[uid]
            conn.execute(
                'INSERT INTO users(id, email, first_name, last_name) VALUES (?, ?, ?, ?)',
                (uid, email, fn, ln)
            )
        for oid, uid, amt, created_at in new_orders:
            conn.execute(
                'INSERT INTO orders(id, user_id, amount_cents, created_at) VALUES (?, ?, ?, ?)',
                (oid, uid, amt, created_at)
            )

        conn.execute('PRAGMA user_version = 2')
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


if __name__ == '__main__':
    main()
