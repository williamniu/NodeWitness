from datetime import datetime, timezone
from decimal import Decimal
import re


def parse_ts(text):
    """Parse an ISO 8601 timestamp with Z or ±HH:MM offset.

    Returns an aware datetime converted to UTC.
    A timestamp without an offset raises ValueError.
    """
    text = text.strip()
    
    # Match: date T time [fraction] [offset]
    # offset is either Z or ±HH:MM
    pattern = r'^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2}:\d{2})(?:\.(\d+))?((?:[+-]\d{2}:\d{2})|Z)$'
    m = re.match(pattern, text)
    if not m:
        raise ValueError(f"not ISO 8601 with offset: {text}")
    
    date_str = m.group(1)
    time_str = m.group(2)
    frac_str = m.group(3)
    offset_str = m.group(4)
    
    year, month, day = (int(x) for x in date_str.split('-'))
    hour, minute, second = (int(x) for x in time_str.split(':'))
    
    if frac_str:
        # Pad or truncate to 6 decimal places for microseconds
        frac = frac_str.ljust(6, '0')[:6]
        microsecond = int(frac)
    else:
        microsecond = 0
    
    # Parse offset
    if offset_str == 'Z':
        dt = datetime(year, month, day, hour, minute, second, microsecond, tzinfo=timezone.utc)
    else:
        sign = 1 if offset_str[0] == '+' else -1
        oh, om = (int(x) for x in offset_str[1:].split(':'))
        offset_seconds = sign * (oh * 3600 + om * 60)
        from datetime import timedelta
        tz = timezone(timedelta(seconds=offset_seconds))
        dt = datetime(year, month, day, hour, minute, second, microsecond, tzinfo=tz)
        # Convert to UTC
        dt = dt.astimezone(timezone.utc)
    
    return dt


def day_bucket(text):
    """UTC calendar day of a timestamp."""
    return parse_ts(text).strftime("%Y-%m-%d")
