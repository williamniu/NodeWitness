#!/usr/bin/env python3
"""Migrate SQLite database from schema v1 to v2."""
import re
import sqlite3
import sys
import os


def parse_amount(text):
    """Parse amount string to integer cents. Returns None on failure."""
    s = text.strip()
    if not s:
        return None

    negative = False

    # Accounting style: ($123.45)
    if s.startswith('(') and s.endswith(')'):
        s = s[1:-1]
        negative = True
    elif s.startswith('(-'):
        s = s[2:-1]
        negative = True
    elif s.startswith('-'):
        s = s[1:]
        negative = True
    elif s.startswith('$'):
        s = s[1:]

    # Remove dollar sign if still present
    if s.startswith('$'):
        s = s[1:]

    if not s:
        return None

    # Remove commas (thousands separators)
    s = s.replace(',', '')

    # Parse number
    try:
        value = float(s)
    except ValueError:
        return None

    if negative:
        value = -value

    # Convert to cents
    cents = round(value * 100)
    return int(cents)


def split_name(full_name):
    """Split full_name into (first_name, last_name) per the rules."""
    if not full_name or not full_name.strip():
        return ('', '')
    
    # Trim and collapse runs of whitespace to single spaces
    trimmed = full_name.strip()
    words = trimmed.split()
    
    if len(words) == 0:
        return ('', '')
    elif len(words) == 1:
        return (words[0], '')
    else:
        return (' '.join(words[:-1]), words[-1])


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 migrate.py PATH", file=sys.stderr)
        sys.exit(1)

    db_path = sys.argv[1]
    
    # Check if it's a v2 database (no-op case)
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute("PRAGMA user_version")
    version = cursor.fetchone()[0]
    
    if version == 2:
        # Already v2, nothing to do
        conn.close()
        sys.exit(0)
    
    if version != 1:
        print(f"Unexpected user_version: {version}", file=sys.stderr)
        conn.close()
        sys.exit(1)
    
    # Read all v1 data
    cursor.execute("SELECT id, email, full_name FROM users ORDER BY id")
    users_raw = cursor.fetchall()
    
    cursor.execute("SELECT id, user_id, amount, created_at FROM orders")
    orders_raw = cursor.fetchall()
    
    conn.close()
    
    # ---- Parse and validate amounts first (all-or-nothing) ----
    parsed_orders = []
    for oid, uid, amt, created in orders_raw:
        cents = parse_amount(amt)
        if cents is None:
            # Invalid amount - abort
            sys.exit(1)
        parsed_orders.append((oid, uid, cents, created))
    
    # ---- Process users ----
    # Step 1: Trim and lowercase emails, remove blank/null emails
    users_with_emails = []
    for uid, email, full_name in users_raw:
        if email is None:
            continue
        e = email.strip().lower()
        if not e:
            continue
        users_with_emails.append((uid, e, full_name))
    
    # Step 2: For each email, find the user with smallest id (the "owner")
    email_to_owner = {}
    for uid, email, full_name in users_with_emails:
        if email not in email_to_owner:
            email_to_owner[email] = uid
        else:
            if uid < email_to_owner[email]:
                email_to_owner[email] = uid
    
    # Build valid user info: email -> {id, first_name, last_name}
    valid_users = {}
    for uid, email, full_name in users_with_emails:
        if email not in valid_users:
            first_name, last_name = split_name(full_name)
            valid_users[email] = {
                'id': uid,
                'first_name': first_name,
                'last_name': last_name,
            }
        else:
            # This user has the same email; only keep smallest id (already set)
            # But if this user has smaller id, update
            if uid < valid_users[email]['id']:
                first_name, last_name = split_name(full_name)
                valid_users[email] = {
                    'id': uid,
                    'first_name': first_name,
                    'last_name': last_name,
                }
    
    # Step 3: Build order mapping: user_id -> primary_user_id
    # For each email, collect all user ids that share it
    email_to_all_user_ids = {}
    for uid, email, full_name in users_with_emails:
        if email not in email_to_all_user_ids:
            email_to_all_user_ids[email] = set()
        email_to_all_user_ids[email].add(uid)
    
    def get_primary_email_for_user(uid):
        """For a given user_id, find the email whose primary (owner) is valid."""
        best_email = None
        best_owner_id = float('inf')
        for email, ids in email_to_all_user_ids.items():
            if uid in ids:
                owner_id = email_to_owner[email]
                if owner_id < best_owner_id:
                    best_owner_id = owner_id
                    best_email = email
        return best_email
    
    user_id_to_primary = {}
    for uid in set(u for ids in email_to_all_user_ids.values() for u in ids):
        primary_email = get_primary_email_for_user(uid)
        if primary_email:
            user_id_to_primary[uid] = valid_users[primary_email]['id']
    
    # ---- Create new database in a temp file ----
    tmp_path = db_path + ".migrate_tmp"
    
    new_conn = sqlite3.connect(tmp_path)
    new_cursor = new_conn.cursor()
    
    # Create v2 schema
    new_cursor.executescript("""
        CREATE TABLE users (
            id INTEGER PRIMARY KEY,
            email TEXT NOT NULL UNIQUE,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL
        );
        CREATE TABLE orders (
            id INTEGER PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id),
            amount_cents INTEGER NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE INDEX idx_orders_user_id ON orders(user_id);
    """)
    
    # Insert users
    for email, info in valid_users.items():
        new_cursor.execute(
            "INSERT INTO users (id, email, first_name, last_name) VALUES (?, ?, ?, ?)",
            (info['id'], email, info['first_name'], info['last_name'])
        )
    
    # Insert orders
    for oid, uid, cents, created in parsed_orders:
        primary_id = user_id_to_primary.get(uid)
        if primary_id is None:
            # Order's user_id doesn't match any valid user
            continue
        new_cursor.execute(
            "INSERT INTO orders (id, user_id, amount_cents, created_at) VALUES (?, ?, ?, ?)",
            (oid, primary_id, cents, created)
        )
    
    # Set user_version to 2
    new_cursor.execute("PRAGMA user_version = 2")
    new_conn.commit()
    new_conn.close()
    
    # ---- Replace the original database with the migrated one ----
    os.remove(db_path)
    os.rename(tmp_path, db_path)
    
    sys.exit(0)


if __name__ == "__main__":
    main()
