from datetime import datetime, timezone, timedelta


def _parse_offset(text):
    """Parse offset from end of text like '+05:30' or '-02:00'."""
    sign = 1 if text[0] == '+' else -1
    h_str, m_str = text[1:].split(':')
    return timedelta(hours=sign * int(h_str), minutes=sign * int(m_str))


def parse_ts(text):
    """Parse an ISO 8601 timestamp with Z or ±HH:MM offset. Returns aware datetime in UTC."""
    text = text.strip()

    if text.endswith('Z'):
        # No timezone info — parse as naive, then set to UTC
        dt = datetime.fromisoformat(text[:-1])
        return dt.replace(tzinfo=timezone.utc)
    else:
        # Check for offset at end (like +05:30 or -02:00)
        if text.endswith('+') or text.endswith('-'):
            raise ValueError("Incomplete timezone offset")

        # Try parsing with fromisoformat directly (Python 3.7+)
        dt = datetime.fromisoformat(text)
        return dt.astimezone(timezone.utc)


def day_bucket(text):
    """UTC calendar day of a timestamp."""
    return parse_ts(text).strftime("%Y-%m-%d")
