#!/usr/bin/env python3
"""Compute p95 latency of failed requests per user from rotated API logs."""

import sys, os, re, gzip, zlib, io, json, math


def parse_iso_timestamp(ts_str):
    """Parse ISO 8601 timestamp with Z or ±HH:MM offset into a datetime (UTC-aware)."""
    ts_str = ts_str.strip()
    if ts_str.endswith('Z'):
        ts_str = ts_str[:-1] + '+00:00'
    return datetime.fromisoformat(ts_str)


from datetime import datetime, timezone


def parse_json_line(line):
    """Parse a JSON log line. Returns (timestamp, user_lower, request_id, status_int, latency_ms_float) or None."""
    try:
        obj = json.loads(line)
    except (json.JSONDecodeError, ValueError):
        return None

    ts_str = obj.get('ts')
    if not isinstance(ts_str, str):
        return None
    user = obj.get('user')
    if not isinstance(user, str):
        return None
    req_id = obj.get('request_id')
    if not isinstance(req_id, str):
        return None

    # Parse status: number or string of digits
    try:
        status_raw = obj['status']
        if isinstance(status_raw, str):
            status_int = int(status_raw)
        else:
            status_int = int(status_raw)
    except (ValueError, TypeError):
        return None

    # Parse latency_ms: number or "NNNms" string
    try:
        latency_raw = obj['latency_ms']
        if isinstance(latency_raw, str):
            s = latency_raw.strip().lower()
            if s.endswith('ms'):
                latency_float = float(s[:-2])
            else:
                latency_float = float(s)
        else:
            latency_float = float(latency_raw)
    except (ValueError, TypeError):
        return None

    try:
        ts = parse_iso_timestamp(ts_str)
    except Exception:
        return None

    return (ts, user.lower(), req_id, status_int, latency_float)


def parse_legacy_line(line):
    """Parse legacy format line. Returns (timestamp, user_lower, request_id, status_int, latency_ms_float) or None."""
    m = re.match(
        r'^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2}))'
        r'\s+user=(\S+)\s+req=(\S+)\s+status=(\S+)\s+ms=(\S+)$',
        line.strip()
    )
    if not m:
        return None

    ts_str, user, req_id, status_raw, ms_raw = m.groups()

    try:
        ts = parse_iso_timestamp(ts_str)
    except Exception:
        return None

    try:
        status_int = int(status_raw)
    except ValueError:
        return None

    ms_val = ms_raw.strip().lower()
    if ms_val.endswith('ms'):
        latency_float = float(ms_val[:-2])
    else:
        latency_float = float(ms_val)

    return (ts, user.lower(), req_id, status_int, latency_float)


def read_file_lines(filepath):
    """Read lines from a file, handling .gz and truncated gzip. Returns list of strings."""
    if filepath.endswith('.gz'):
        with open(filepath, 'rb') as f:
            data = f.read()

        # First try normal decompression
        try:
            result = gzip.decompress(data)
        except (gzip.BadGzipFile, EOFError):
            # Truncated gz — stream what we can
            buf = io.BytesIO(data)
            d = zlib.decompressobj(31)
            result = b''
            while True:
                chunk = buf.read(8192)
                if not chunk:
                    break
                try:
                    result += d.decompress(chunk)
                except zlib.error:
                    break

        text = result.decode('utf-8', errors='replace')
        # Keep only complete lines (ending with \n)
        last_newline = text.rfind('\n')
        if last_newline >= 0:
            text = text[:last_newline + 1]
        return text.split('\n')
    else:
        with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
            return f.read().split('\n')


def get_log_files(logdir):
    """Return sorted list of valid log file paths in logdir."""
    valid_names = set()
    for name in os.listdir(logdir):
        if name == 'app.log':
            valid_names.add(name)
        else:
            m = re.match(r'^app\.log\.(\d+)$', name)
            if m and int(m.group(1)) > 0:
                valid_names.add(name)
    return sorted(os.path.join(logdir, n) for n in valid_names)


def main():
    logdir = sys.argv[1]

    # Collect all records: key by request_id -> (timestamp, user_lower, status_int, latency_ms)
    best = {}  # request_id -> (timestamp, user_lower, status_int, latency_ms)

    for filepath in get_log_files(logdir):
        lines = read_file_lines(filepath)
        for line in lines:
            if not line.strip():
                continue
            rec = parse_json_line(line)
            if rec is None:
                rec = parse_legacy_line(line)
            if rec is None:
                continue

            ts, user_lower, req_id, status_int, latency_ms = rec

            if req_id not in best or ts > best[req_id][0]:
                best[req_id] = (ts, user_lower, status_int, latency_ms)

    # For each request where last attempt failed (status >= 500), collect per-user stats.
    user_data = {}  # user -> list of latencies for failures
    for req_id, (ts, user_lower, status_int, latency_ms) in best.items():
        if status_int >= 500:
            user_data.setdefault(user_lower, []).append(latency_ms)

    # Compute p95 per user and output
    rows = []
    for user in sorted(user_data.keys()):
        latencies = sorted(user_data[user])
        n = len(latencies)
        idx = math.ceil(0.95 * n)  # 1-based index
        p95 = latencies[idx - 1]  # convert to 0-based
        rows.append((user, n, int(p95)))

    # Sort by failures descending, then user ascending
    rows.sort(key=lambda r: (-r[1], r[0]))

    print('user,failures,p95_ms')
    for user, failures, p95 in rows:
        print(f'{user},{failures},{p95}')


if __name__ == '__main__':
    main()
