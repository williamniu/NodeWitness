from datetime import datetime, timezone


def parse_ts(text):
    """Parse ISO 8601 timestamp with Z or ±HH:MM offset, return UTC-aware datetime."""
    s = text.strip()
    if not s:
        raise ValueError("empty timestamp")
    if s.endswith('Z') or s.endswith('z'):
        s2 = s[:-1] + '+00:00'
    else:
        s2 = s
    dt = datetime.fromisoformat(s2)
    if dt.tzinfo is None:
        raise ValueError("timestamp must have an offset")
    return dt.astimezone(timezone.utc)


def day_bucket(text):
    """UTC calendar day of a timestamp as YYYY-MM-DD."""
    return parse_ts(text).strftime("%Y-%m-%d")
