import sys
import os
import re
import sqlite3
import shutil


def parse_amount(s):
    """Parse a v1 amount string to integer cents. Return None if invalid."""
    if s is None:
        return None
    s = s.strip()
    if not s:
        return None

    negative = False
    # Check for accounting style: (amount)
    if s.startswith('(') and s.endswith(')'):
        negative = True
        s = s[1:-1].strip()

    # Check for leading minus
    if s.startswith('-'):
        negative = True
        s = s[1:].strip()

    # Check for leading $
    if s.startswith('$'):
        s = s[1:]

    # Remove commas
    s = s.replace(',', '')

    # Validate: must be digits optionally followed by .dd
    m = re.match(r'^(\d+)(?:\.(\d{1,2}))?$', s)
    if not m:
        return None

    dollars = int(m.group(1))
    cents_str = m.group(2)
    if cents_str is None:
        cents = dollars * 100
    elif len(cents_str) == 1:
        cents = dollars * 100 + int(cents_str) * 10
    else:
        cents = dollars * 100 + int(cents_str)

    if negative:
        cents = -cents
    return cents


def split_name(full_name):
    """Split full_name into (first_name, last_name)."""
    if full_name is None:
        return '', ''
    s = full_name.strip()
    if not s:
        return '', ''
    words = s.split()
    if len(words) == 1:
        return words[0], ''
    last = words[-1]
    first = ' '.join(words[:-1])
    return first, last


def main():
    if len(sys.argv) < 2:
        sys.exit(1)
    path = sys.argv[1]

    conn = sqlite3.connect(path)
    ver = conn.execute('PRAGMA user_version').fetchone()[0]

    if ver == 2:
        conn.close()
        return

    if ver != 1:
        conn.close()
        sys.exit(1)

    # Backup the file for atomicity
    backup = path + '.bak'
    shutil.copy2(path, backup)

    try:
        # Read all data
        users = conn.execute('SELECT id, email, full_name FROM users ORDER BY id').fetchall()
        orders = conn.execute('SELECT id, user_id, amount, created_at FROM orders ORDER BY id').fetchall()

        # Validate all amounts first
        parsed_orders = []
        for oid, uid, amount, created_at in orders:
            cents = parse_amount(amount)
            if cents is None:
                raise ValueError("bad amount %r in order %d" % (amount, oid))
            parsed_orders.append((oid, uid, cents, created_at))

        # Process users
        # Group by normalized email
        email_groups = {}   # normalized_email -> list of (uid, first, last)
        deleted_user_ids = set()   # users to delete (null/blank email)

        for uid, email, full_name in users:
            if email is None:
                deleted_user_ids.add(uid)
                continue
            e = email.strip().lower()
            if not e:
                deleted_user_ids.add(uid)
                continue
            first, last = split_name(full_name)
            if e not in email_groups:
                email_groups[e] = []
            email_groups[e].append((uid, first, last))

        # For each email group, keep the user with smallest id
        # Build old_uid -> new_uid mapping for all valid (non-deleted) users
        old_to_new = {}
        valid_users = {}   # email -> (id, first, last)

        for e, group in email_groups.items():
            group.sort(key=lambda x: x[0])
            kept = group[0]
            valid_users[e] = (kept[0], kept[1], kept[2])
            for uid, first, last in group:
                old_to_new[uid] = kept[0]

        # Process orders
        new_orders = []
        for oid, uid, cents, created_at in parsed_orders:
            # Delete orders whose user_id doesn't match any v1 user
            if uid in deleted_user_ids:
                continue
            if uid not in old_to_new:
                continue
            new_uid = old_to_new[uid]
            new_orders.append((oid, new_uid, cents, created_at))

        # Perform the migration in a transaction
        conn.execute('BEGIN')
        conn.execute('DROP TABLE IF EXISTS users')
        conn.execute('DROP TABLE IF EXISTS orders')
        conn.execute('''CREATE TABLE users (
            id INTEGER PRIMARY KEY,
            email TEXT NOT NULL UNIQUE,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL
        )''')
        conn.execute('''CREATE TABLE orders (
            id INTEGER PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id),
            amount_cents INTEGER NOT NULL,
            created_at TEXT NOT NULL
        )''')
        conn.execute('CREATE INDEX idx_orders_user_id ON orders(user_id)')

        for e, (uid, first, last) in valid_users.items():
            conn.execute(
                'INSERT INTO users (id, email, first_name, last_name) VALUES (?,?,?,?)',
                (uid, e, first, last))

        for oid, uid, cents, created_at in new_orders:
            conn.execute(
                'INSERT INTO orders (id, user_id, amount_cents, created_at) VALUES (?,?,?,?)',
                (oid, uid, cents, created_at))

        conn.execute('PRAGMA user_version = 2')
        conn.commit()
        conn.close()
        os.remove(backup)

    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        try:
            conn.close()
        except Exception:
            pass
        shutil.copy2(backup, path)
        os.remove(backup)
        sys.exit(1)


if __name__ == '__main__':
    main()
