import sys, os, re, shutil, sqlite3, tempfile

AMOUNT_RE = re.compile(r'^\s*(?:\()?\s*(?:-)?\s*\$?\s*(\d{1,3}(?:,\d{3})+|\d+)(?:\.(\d{1,2}))?\s*(?:\))?\s*$')

def parse_amount(s):
    if s is None:
        return None
    if not isinstance(s, str):
        return None
    m = AMOUNT_RE.match(s)
    if not m:
        return None
    # check accounting style: if opening paren present, must have closing paren
    stripped = s.strip()
    if stripped.startswith('('):
        if not stripped.endswith(')'):
            return None
    else:
        if stripped.endswith(')'):
            return None
    int_part = m.group(1)
    dec = m.group(2)
    cents = int(int_part.replace(',', '')) * 100
    if dec is not None:
        cents += int(dec.ljust(2, '0'))
    # negative: explicit '-' OR accounting parens
    neg = ('-' in s) or (stripped.startswith('('))
    if neg:
        cents = -cents
    return cents

def split_name(fn):
    if fn is None:
        return ('', '')
    s = ' '.join(fn.split())
    if s == '':
        return ('', '')
    words = s.split(' ')
    last = words[-1]
    first = ' '.join(words[:-1])
    return (first, last)

def migrate(path):
    ver = sqlite3.connect(path).execute('PRAGMA user_version').fetchone()[0]
    if ver >= 2:
        return
    if ver != 1:
        # not a v1 db; nothing to do
        return

    conn = sqlite3.connect(path)
    try:
        users = list(conn.execute('SELECT id, email, full_name FROM users ORDER BY id'))
        orders = list(conn.execute('SELECT id, user_id, amount, created_at FROM orders'))
    finally:
        conn.close()

    # validate all amounts first (all-or-nothing)
    for o in orders:
        cents = parse_amount(o[2])
        if cents is None:
            sys.exit(1)

    # build users
    # determine which user ids are deleted (blank email)
    kept = {}  # email -> representative user id (smallest)
    all_user_ids = set(u[0] for u in users)
    deleted_user_ids = set()
    for uid, email, fn in users:
        em = (email or '').strip().lower()
        if em == '':
            deleted_user_ids.add(uid)
            continue
        if em not in kept:
            kept[em] = uid
        # else: later user with same email -> its orders moved to kept[em]; user deleted
    # user ids that are not representatives (dup emails, not smallest)
    dup_user_ids = set()
    for uid, email, fn in users:
        em = (email or '').strip().lower()
        if em == '':
            continue
        if kept[em] != uid:
            dup_user_ids.add(uid)

    # map: for orders, original user_id -> target user id
    # deleted/dup users: orders go to representative if email valid, else deleted
    # For a dup user, its orders move to kept[em]
    # For a blank-email user, its orders are deleted
    # For orders with user_id not in any v1 user -> deleted
    target_for = {}
    for uid, email, fn in users:
        em = (email or '').strip().lower()
        if em == '':
            target_for[uid] = None  # delete
        else:
            target_for[uid] = kept[em]

    # build new users rows
    new_users = []
    for uid, email, fn in users:
        em = (email or '').strip().lower()
        if em == '':
            continue
        if kept[em] != uid:
            continue
        first, last = split_name(fn)
        new_users.append((uid, em, first, last))

    # build new orders
    new_orders = []
    for oid, user_id, amount, created_at in orders:
        if user_id not in target_for:
            continue  # user_id not matching any v1 user
        tgt = target_for[user_id]
        if tgt is None:
            continue  # deleted
        cents = parse_amount(amount)
        new_orders.append((oid, tgt, cents, created_at))

    # Now write the new schema
    tmp_fd, tmp = tempfile.mkstemp(dir=os.path.dirname(os.path.abspath(path)))
    os.close(tmp_fd)
    try:
        tconn = sqlite3.connect(tmp)
        tconn.execute('PRAGMA journal_mode=OFF')
        tconn.execute('PRAGMA foreign_keys=ON')
        tconn.execute('''CREATE TABLE users(
            id INTEGER PRIMARY KEY,
            email TEXT NOT NULL UNIQUE,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL)''')
        tconn.execute('''CREATE TABLE orders(
            id INTEGER PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id),
            amount_cents INTEGER NOT NULL,
            created_at TEXT NOT NULL)''')
        tconn.execute('CREATE INDEX idx_orders_user_id ON orders(user_id)')
        tconn.executemany('INSERT INTO users VALUES (?,?,?,?)', new_users)
        tconn.executemany('INSERT INTO orders VALUES (?,?,?,?)', new_orders)
        tconn.execute('PRAGMA user_version = 2')
        tconn.commit()
        tconn.close()
        shutil.move(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise

if __name__ == '__main__':
    if len(sys.argv) != 2:
        sys.exit(2)
    migrate(sys.argv[1])
