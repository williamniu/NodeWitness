from datetime import datetime, timezone, timedelta
import re


def parse_ts(text):
    """Parse an ISO 8601 timestamp with Z or ±HH:MM offset, returning UTC datetime."""
    if not text:
        raise ValueError("empty timestamp")
    # Check for Z suffix
    if text.endswith('Z'):
        base = text[:-1]
        tz = timezone.utc
    elif re.search(r'[+-]\d{2}:\d{2}$', text):
        # Extract offset
        m = re.search(r'([+-])(\d{2}):(\d{2})$', text)
        sign = 1 if m.group(1) == '+' else -1
        hours = int(m.group(2))
        minutes = int(m.group(3))
        offset_seconds = sign * (hours * 3600 + minutes * 60)
        tz = timezone(timedelta(seconds=offset_seconds))
        base = text[:m.start()]
    else:
        raise ValueError("timestamp must have a Z or ±HH:MM offset")
    
    # Handle optional fractional seconds
    if '.' in base:
        parts = base.split('.')
        base = parts[0]
        frac = parts[1]
        # Pad or truncate to 6 digits for microseconds
        frac = frac[:6].ljust(6, '0')
        frac_str = '.' + frac
        dt = datetime.strptime(base + frac_str, "%Y-%m-%dT%H:%M:%S.%f")
    else:
        dt = datetime.strptime(base, "%Y-%m-%dT%H:%M:%S")
    
    # Make aware with the offset
    dt = dt.replace(tzinfo=tz)
    # Convert to UTC
    dt_utc = dt.astimezone(timezone.utc)
    return dt_utc


def day_bucket(text):
    """UTC calendar day of a timestamp."""
    dt = parse_ts(text)
    return dt.strftime("%Y-%m-%d")
