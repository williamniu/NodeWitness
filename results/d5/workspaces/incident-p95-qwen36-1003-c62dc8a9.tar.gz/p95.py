#!/usr/bin/env python3
"""Compute p95 latency for failed requests per user."""

import gzip
import json
import math
import os
import re
import sys
import zlib


def parse_iso8601(ts_str):
    """Parse ISO 8601 timestamp to seconds since epoch (UTC)."""
    ts = ts_str.strip()
    # Handle 'Z' suffix
    if ts.endswith('Z'):
        ts = ts[:-1] + '+00:00'

    m = re.match(r'(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?(.*)', ts)
    if not m:
        return None

    year, month, day = int(m.group(1)), int(m.group(2)), int(m.group(3))
    hour, minute = int(m.group(4)), int(m.group(5))
    second = int(m.group(6))

    frac_str = m.group(7) or '0'
    frac_str = frac_str.ljust(9, '0')[:9]
    nanos = int(frac_str)

    tz_part = m.group(8).strip() if m.group(8) else ''

    tz_seconds = 0
    if tz_part:
        sign = 1 if tz_part[0] == '+' else -1
        tz_rest = tz_part[1:]
        parts = tz_rest.split(':')
        tz_hours = int(parts[0])
        tz_mins = int(parts[1]) if len(parts) > 1 else 0
        tz_seconds = sign * (tz_hours * 3600 + tz_mins * 60)

    import datetime
    dt = datetime.datetime(year, month, day, hour, minute, second, nanos // 1000, tzinfo=None)
    epoch = datetime.datetime(1970, 1, 1)
    total_seconds = (dt - epoch).total_seconds() - tz_seconds

    return total_seconds


def parse_status(val):
    """Parse status field which can be int or string of digits."""
    if isinstance(val, int):
        return val
    if isinstance(val, str):
        try:
            return int(val)
        except (ValueError, TypeError):
            return None
    return None


def parse_latency_ms(val):
    """Parse latency_ms which can be number or string like '412ms'."""
    if isinstance(val, (int, float)):
        return val
    if isinstance(val, str):
        m = re.match(r'^(\d+(?:\.\d+)?)\s*ms?$', val)
        if m:
            return float(m.group(1))
        try:
            return float(val)
        except ValueError:
            pass
    return None


def parse_json_line(line):
    """Parse a JSON log line."""
    try:
        obj = json.loads(line)
    except (json.JSONDecodeError, ValueError):
        return None

    ts_str = obj.get('ts')
    if not ts_str:
        return None

    timestamp = parse_iso8601(ts_str)
    if timestamp is None:
        return None

    user = obj.get('user', '')
    request_id = obj.get('request_id', '')

    status = parse_status(obj.get('status'))
    latency = parse_latency_ms(obj.get('latency_ms'))

    if status is not None and latency is not None:
        return (timestamp, user.lower(), request_id, int(status), latency)
    return None


def parse_legacy_line(line):
    """Parse legacy format: 2026-11-01T08:00:00Z user=alice req=r1a2b status=503 ms=412"""
    m = re.match(
        r'(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z?)'
        r'\s+user=(\S+)\s+'
        r'req=(\S+)\s+'
        r'status=(\d+)\s+'
        r'ms=(\d+)',
        line.strip()
    )
    if not m:
        return None

    ts = parse_iso8601(m.group(1))
    if ts is None:
        return None

    user = m.group(2).lower()
    request_id = m.group(3)
    status = int(m.group(4))
    latency = float(m.group(5))

    return (ts, user, request_id, status, latency)


def read_log_file(filepath):
    """Read lines from a log file, handling .gz with truncated content."""
    if filepath.endswith('.gz'):
        try:
            with gzip.open(filepath, 'rt') as f:
                result = []
                for line in f:
                    if line.endswith('\n'):
                        result.append(line)
                    else:
                        break
                return result
        except (EOFError, gzip.BadGzipFile):
            # Truncated file - read raw bytes and decompress with zlib
            try:
                with open(filepath, 'rb') as f:
                    raw = f.read()
                dc = zlib.decompressobj(zlib.MAX_WBITS | 32)
                text_bytes = dc.decompress(raw)
                text = text_bytes.decode('utf-8', errors='replace')
                lines = text.split('\n')
                return [l + '\n' for l in lines if l.strip()]
            except Exception:
                return []
    else:
        try:
            with open(filepath, 'r', errors='replace') as f:
                return f.readlines()
        except Exception:
            return []


def main():
    if len(sys.argv) != 2:
        print("Usage: p95.py LOGDIR", file=sys.stderr)
        sys.exit(1)

    logdir = sys.argv[1]

    # Collect request data: key=request_id, value=(timestamp_utc, user_lower, status, latency_ms)
    requests = {}  # request_id -> (max_timestamp, user_lower, status, latency_ms)

    for fname in sorted(os.listdir(logdir)):
        if fname == 'app.log':
            filepath = os.path.join(logdir, fname)
        elif re.match(r'app\.log\.\d+$', fname):
            filepath = os.path.join(logdir, fname)
        else:
            continue

        if not os.path.isfile(filepath):
            continue

        lines = read_log_file(filepath)

        for line in lines:
            line = line.strip()
            if not line:
                continue

            result = parse_json_line(line)
            if result is None:
                result = parse_legacy_line(line)

            if result is None:
                continue

            timestamp, user, request_id, status, latency_ms = result

            # Keep only the latest attempt per request_id
            if request_id not in requests or timestamp > requests[request_id][0]:
                requests[request_id] = (timestamp, user, status, latency_ms)

    from collections import defaultdict
    user_failures = defaultdict(list)

    for request_id, (timestamp, user, status, latency_ms) in requests.items():
        if status >= 500:
            user_failures[user].append(latency_ms)

    results = []
    for user, latencies in user_failures.items():
        n = len(latencies)
        sorted_latencies = sorted(latencies)

        # Nearest-rank: ceil(0.95 * n), 1-based index
        idx = math.ceil(0.95 * n)
        p95_ms = int(sorted_latencies[idx - 1])

        results.append((user, n, p95_ms))

    # Sort by failures descending, then user ascending
    results.sort(key=lambda x: (-x[1], x[0]))

    # Output CSV
    print("user,failures,p95_ms")
    for user, failures, p95_ms in results:
        print(f"{user},{failures},{p95_ms}")


if __name__ == '__main__':
    main()
