def page(items, number, size):
    """Return one page of items."""
    if number < 1 or size < 1:
        raise ValueError("number and size must be >= 1")
    start = (number - 1) * size
    return items[start:start + size]
