import sqlite3, sys, re, shutil, os

def parse_amount(s):
    if s is None:
        return None
    s = s.strip()
    if s == '':
        return None
    neg = False
    if s.startswith('(') and s.endswith(')'):
        neg = True
        s = s[1:-1].strip()
    elif s.startswith('-'):
        neg = True
        s = s[1:].strip()
    if s.startswith('$'):
        s = s[1:].strip()
    m = re.fullmatch(r'(\d+(?:,\d{3})*(?:\.\d{1,2})?|\.\d{1,2})', s)
    if not m:
        return None
    num = s.replace(',', '')
    if '.' in num:
        intpart, decpart = num.split('.')
        decpart = (decpart + '00')[:2]
        cents = int(intpart) * 100 + int(decpart)
    else:
        cents = int(num) * 100
    if neg:
        cents = -cents
    return cents

def main():
    if len(sys.argv) != 2:
        sys.exit(1)
    path = sys.argv[1]
    conn = sqlite3.connect(path)
    ver = conn.execute('PRAGMA user_version').fetchone()[0]
    if ver == 2:
        conn.close()
        return
    if ver != 1:
        sys.exit(1)

    users = conn.execute('SELECT id, email, full_name FROM users').fetchall()
    orders = conn.execute('SELECT id, user_id, amount, created_at FROM orders').fetchall()

     # Validate all amounts first (all-or-nothing)
    for o in orders:
        if parse_amount(o[2]) is None:
            conn.close()
            sys.exit(1)

     # Process users
    valid_users = {}     # email -> (id, first_name, last_name)
    deleted_user_ids = set()
    for uid, email, full_name in users:
        if email is None:
            deleted_user_ids.add(uid)
            continue
        em = email.strip().lower()
        if em == '':
            deleted_user_ids.add(uid)
            continue
        if full_name is None:
            fn, ln = '', ''
        else:
            norm = re.sub(r'\s+', ' ', full_name).strip()
            if norm == '':
                fn, ln = '', ''
            else:
                words = norm.split(' ')
                ln = words[-1]
                fn = ' '.join(words[:-1])
        if em in valid_users:
            existing = valid_users[em]
            if uid < existing[0]:
                deleted_user_ids.add(existing[0])
                valid_users[em] = (uid, fn, ln)
            else:
                deleted_user_ids.add(uid)
        else:
            valid_users[em] = (uid, fn, ln)

     # Build mapping from old user_id -> kept user_id for duplicates
    email_to_ids = {}
    for uid, email, full_name in users:
        if email is None:
            continue
        em = email.strip().lower()
        if em == '':
            continue
        email_to_ids.setdefault(em, []).append(uid)

    user_id_map = {}
    for em, ids in email_to_ids.items():
        kept = min(ids)
        for uid in ids:
            user_id_map[uid] = kept

    all_v1_user_ids = {u[0] for u in users}
    new_orders = []
    for oid, user_id, amount, created_at in orders:
        if user_id not in all_v1_user_ids:
            continue
        if user_id in deleted_user_ids:
            if user_id in user_id_map:
                user_id = user_id_map[user_id]
            else:
                continue
        new_orders.append((oid, user_id, parse_amount(amount), created_at))

     # Get all existing objects to drop
    existing_tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
    existing_views = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='view'").fetchall()]
    existing_indexes = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='index' AND name NOT LIKE 'sqlite_%'").fetchall()]

    backup = path + '.bak'
    shutil.copy2(path, backup)
    try:
        conn.execute('BEGIN')
        for v in existing_views:
            conn.execute(f'DROP VIEW IF EXISTS "{v}"')
        for t in existing_tables:
            conn.execute(f'DROP TABLE IF EXISTS "{t}"')
        for idx in existing_indexes:
            conn.execute(f'DROP INDEX IF EXISTS "{idx}"')
        conn.execute('''CREATE TABLE users (
            id INTEGER PRIMARY KEY,
            email TEXT NOT NULL UNIQUE,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL
          )''')
        conn.execute('''CREATE TABLE orders (
            id INTEGER PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id),
            amount_cents INTEGER NOT NULL,
            created_at TEXT NOT NULL
          )''')
        conn.execute('CREATE INDEX idx_orders_user_id ON orders(user_id)')
        for em, (uid, fn, ln) in valid_users.items():
            conn.execute('INSERT INTO users (id, email, first_name, last_name) VALUES (?,?,?,?)',
                         (uid, em, fn, ln))
        for oid, user_id, cents, created_at in new_orders:
            conn.execute('INSERT INTO orders (id, user_id, amount_cents, created_at) VALUES (?,?,?,?)',
                         (oid, user_id, cents, created_at))
        conn.execute('PRAGMA user_version = 2')
        conn.commit()
        os.remove(backup)
    except Exception:
        conn.rollback()
        shutil.copy2(backup, path)
        os.remove(backup)
        conn.close()
        sys.exit(1)
    conn.close()

if __name__ == '__main__':
    main()
