#!/usr/bin/env python3
import sys, os, re, json, math, zlib
from datetime import datetime, timezone, timedelta
from collections import defaultdict

def parse_ts(s):
    s = s.strip()
    if s.endswith('Z'):
        s = s[:-1] + '+00:00'
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        pass
    m = re.match(r'(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(\.\d+)?([+-]\d{2}:\d{2}|Z)?', s)
    if m:
        dt = datetime(int(m.group(1)[:4]), int(m.group(1)[5:7]), int(m.group(1)[8:10]),
                      int(m.group(1)[11:13]), int(m.group(1)[14:16]), int(m.group(1)[17:19]))
        if m.group(2):
            dt = dt + timedelta(microseconds=int(m.group(2)[1:] + '000000'[:6]))
        tz = timezone.utc
        if m.group(3) and m.group(3) != 'Z':
            sign = 1 if m.group(3)[0] == '+' else -1
            h = int(m.group(3)[1:3])
            mn = int(m.group(3)[4:6])
            tz = timezone(sign * timedelta(hours=h, minutes=mn))
        return dt.replace(tzinfo=tz)
    raise ValueError(f"Cannot parse ts: {s}")

def parse_latency(val):
    if isinstance(val, (int, float)):
        return int(val)
    if isinstance(val, str):
        m = re.match(r'(\d+)', val)
        if m:
            return int(m.group(1))
    raise ValueError(f"Cannot parse latency: {val}")

def parse_status(val):
    if isinstance(val, (int, float)):
        return int(val)
    if isinstance(val, str):
        return int(val)
    raise ValueError(f"Cannot parse status: {val}")

def parse_json_line(line):
    line = line.strip()
    if not line or not line.startswith('{'):
        return None
    try:
        obj = json.loads(line)
    except json.JSONDecodeError:
        return None
    try:
        ts = parse_ts(obj['ts'])
        user = obj['user'].lower()
        request_id = obj['request_id']
        status = parse_status(obj['status'])
        latency = parse_latency(obj['latency_ms'])
        return (ts, user, request_id, status, latency)
    except (KeyError, ValueError, TypeError):
        return None

LEGACY_RE = re.compile(
    r'^(\S+)\s+user=(\S+)\s+req=(\S+)\s+status=(\d+)\s+ms=(\d+)\s*$'
)

def parse_legacy_line(line):
    line = line.strip()
    if not line:
        return None
    m = LEGACY_RE.match(line)
    if not m:
        return None
    try:
        ts = parse_ts(m.group(1))
        user = m.group(2).lower()
        request_id = m.group(3)
        status = int(m.group(4))
        latency = int(m.group(5))
        return (ts, user, request_id, status, latency)
    except (ValueError, TypeError):
        return None

def read_gz_lines(filepath):
    """Read lines from a possibly-truncated .gz file.
    Return a list of complete lines (those that ended in \\n before the damage)."""
    with open(filepath, 'rb') as f:
        raw = f.read()
    # Use zlib to decompress, handling truncation gracefully
    d = zlib.decompressobj(zlib.MAX_WBITS | 16)
    data = b''
    try:
        data = d.decompress(raw)
    except (OSError, zlib.error):
        pass
    try:
        data += d.flush()
    except (OSError, zlib.error):
        pass
    text = data.decode('utf-8', errors='replace')
    lines = text.split('\n')
    if text.endswith('\n'):
        return lines[:-1]
    else:
        return lines[:-1]

def read_plain_lines(filepath):
    with open(filepath, 'r', errors='replace') as f:
        content = f.read()
    lines = content.split('\n')
    if content.endswith('\n'):
        return lines[:-1]
    else:
        return lines[:-1]

def main():
    logdir = sys.argv[1]
    
    valid_files = []
    for fname in os.listdir(logdir):
        full = os.path.join(logdir, fname)
        if not os.path.isfile(full):
            continue
        m = re.match(r'^app\.log(\.([1-9]\d*)(\.gz)?)?$', fname)
        if m:
            valid_files.append(full)
    
    best = {}
    
    for filepath in valid_files:
        if filepath.endswith('.gz'):
            lines = read_gz_lines(filepath)
        else:
            lines = read_plain_lines(filepath)
        
        for line in lines:
            if not line:
                continue
            result = parse_json_line(line)
            if result is None:
                result = parse_legacy_line(line)
            if result is None:
                continue
            ts, user, request_id, status, latency = result
            if request_id not in best or ts > best[request_id][0]:
                best[request_id] = (ts, user, status, latency)
    
    user_failures = defaultdict(list)
    for request_id, (ts, user, status, latency) in best.items():
        if status >= 500:
            user_failures[user].append(latency)
    
    results = []
    for user, latencies in user_failures.items():
        latencies.sort()
        n = len(latencies)
        rank = math.ceil(0.95 * n)
        if rank < 1:
            rank = 1
        p95 = latencies[rank - 1]
        results.append((user, n, p95))
    
    results.sort(key=lambda x: (-x[1], x[0]))
    
    print("user,failures,p95_ms")
    for user, failures, p95 in results:
        print(f"{user},{failures},{p95}")

if __name__ == '__main__':
    main()
