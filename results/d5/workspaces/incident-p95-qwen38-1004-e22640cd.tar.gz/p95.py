#!/usr/bin/env python3
import sys
import os
import re
import json
import gzip
import math
from datetime import datetime

# Filename patterns: app.log, app.log.N, app.log.N.gz (N positive integer)
RE_PLAIN = re.compile(r'^app\.log$')
RE_NUM = re.compile(r'^app\.log\.[1-9][0-9]*$')
RE_NUM_GZ = re.compile(r'^app\.log\.[1-9][0-9]*\.gz$')

# Legacy line: 2026-11-01T08:00:00Z user=alice req=r1a2b status=503 ms=412
LEGACY_RE = re.compile(
    r'^(\S+)\s+user=(\S+)\s+req=(\S+)\s+status=(\d+)\s+ms=(\d+)\s*$'
)


def parse_ts(s):
    try:
        return datetime.fromisoformat(s.replace('Z', '+00:00'))
    except Exception:
        return None


def parse_latency(v):
    if isinstance(v, (int, float)):
        return int(v)
    if isinstance(v, str):
        m = re.match(r'^(\d+)', v.strip())
        if m:
            return int(m.group(1))
    return None


def parse_status(v):
    if isinstance(v, (int, float)):
        return int(v)
    if isinstance(v, str):
        m = re.match(r'^(\d+)$', v.strip())
        if m:
            return int(m.group(1))
    return None


def parse_json_line(line):
    try:
        obj = json.loads(line)
    except Exception:
        return None
    if not isinstance(obj, dict):
        return None
    ts = obj.get('ts')
    user = obj.get('user')
    rid = obj.get('request_id')
    status = obj.get('status')
    lat = obj.get('latency_ms')
    if ts is None or user is None or rid is None or status is None or lat is None:
        return None
    dt = parse_ts(str(ts))
    if dt is None:
        return None
    st = parse_status(status)
    if st is None:
        return None
    ms = parse_latency(lat)
    if ms is None:
        return None
    return (str(user).lower(), str(rid), dt, st, ms)


def parse_legacy_line(line):
    m = LEGACY_RE.match(line)
    if not m:
        return None
    ts_s, user, rid, st_s, ms_s = m.groups()
    dt = parse_ts(ts_s)
    if dt is None:
        return None
    return (user.lower(), rid, dt, int(st_s), int(ms_s))


def parse_line(line):
    s = line.strip()
    if not s:
        return None
    rec = None
    if s[0] == '{':
        rec = parse_json_line(s)
    if rec is None:
        rec = parse_legacy_line(s)
    return rec


def iter_lines_from_bytes(data):
    # Split on newline; only complete lines (ending in newline) are valid.
    # A trailing segment without a newline is a truncated/incomplete line -> skip.
    parts = data.split(b'\n')
    # The last element is whatever followed the final newline (possibly empty,
    # possibly a truncated line). Drop it.
    for part in parts[:-1]:
        yield part.decode('utf-8', 'replace')


def read_file(path):
    if path.endswith('.gz'):
        out = b''
        try:
            with open(path, 'rb') as f:
                gz = gzip.GzipFile(fileobj=f)
                while True:
                    chunk = gz.read1(65536)
                    if not chunk:
                        break
                    out += chunk
        except (EOFError, OSError):
            pass
        return out
    else:
        with open(path, 'rb') as f:
            return f.read()


def main():
    logdir = sys.argv[1]
    # request_id -> (dt, user, status, latency) keeping the latest timestamp
    best = {}

    for name in sorted(os.listdir(logdir)):
        if not (RE_PLAIN.match(name) or RE_NUM.match(name) or RE_NUM_GZ.match(name)):
            continue
        path = os.path.join(logdir, name)
        if not os.path.isfile(path):
            continue
        data = read_file(path)
        for line in iter_lines_from_bytes(data):
            rec = parse_line(line)
            if rec is None:
                continue
            user, rid, dt, st, ms = rec
            cur = best.get(rid)
            if cur is None or dt > cur[0]:
                best[rid] = (dt, user, st, ms)

    # Group failed requests by user
    user_lat = {}
    for rid, (dt, user, st, ms) in best.items():
        if st >= 500:
            user_lat.setdefault(user, []).append(ms)

    rows = []
    for user, lats in user_lat.items():
        n = len(lats)
        if n == 0:
            continue
        s = sorted(lats)
        rank = math.ceil(0.95 * n)
        if rank < 1:
            rank = 1
        p95 = s[rank - 1]
        rows.append((user, n, p95))

    rows.sort(key=lambda r: (-r[1], r[0]))

    out = sys.stdout
    out.write("user,failures,p95_ms\n")
    for user, n, p95 in rows:
        out.write(f"{user},{n},{p95}\n")


if __name__ == '__main__':
    main()
