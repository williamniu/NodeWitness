def parse(line):
    if not line.strip():
        return []
    return [part.strip() for part in line.split(',')]
