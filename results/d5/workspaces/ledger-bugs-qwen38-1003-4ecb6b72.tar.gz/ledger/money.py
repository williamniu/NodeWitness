import re
from decimal import Decimal, ROUND_HALF_UP

_NUM = re.compile(r'^\s*([+-]?)(\d+)(?:\.(\d+))?\s*$')


def to_cents(text):
    """Parse a decimal amount string into integer cents."""
    m = _NUM.match(text)
    if not m:
        raise ValueError(text)
    sign, intpart, fracpart = m.group(1), m.group(2), m.group(3)
    d = Decimal(sign + intpart + (("." + fracpart) if fracpart is not None else ""))
    return int((d * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def split(total_cents, n):
    """Split an amount into n near-equal parts."""
    if n < 1:
        raise ValueError("n must be >= 1")
    q, r = divmod(total_cents, n)
    return [q + (1 if i < r else 0) for i in range(n)]


def allocate(total_cents, weights):
    """Split an amount in proportion to weights."""
    if not weights:
        raise ValueError("weights must be non-empty")
    total = 0
    for w in weights:
        if w < 0:
            raise ValueError("weights must be non-negative")
        total += w
    if total == 0:
        raise ValueError("weights must sum to non-zero")

    sign = -1 if total_cents < 0 else 1
    mag = abs(total_cents)

    base = [0] * len(weights)
    remainders = []
    for i, w in enumerate(weights):
        q = (mag * w) // total
        base[i] = q
        rem = mag * w - q * total
        remainders.append((rem, i))

    remainder = mag - sum(base)
    remainders.sort(key=lambda x: (-x[0], x[1]))
    for i in range(remainder):
        base[remainders[i][1]] += 1

    return [sign * v if v != 0 else 0 for v in base]
