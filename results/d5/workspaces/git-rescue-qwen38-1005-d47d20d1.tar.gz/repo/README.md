# billing-sync

Syncs invoices between two ledgers.
