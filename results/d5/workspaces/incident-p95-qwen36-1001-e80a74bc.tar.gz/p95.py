#!/usr/bin/env python3
"""Compute per-user p95 latency for failed requests across rotated log files."""

import sys, os, gzip, json, math, re
from datetime import datetime, timezone, timedelta


def parse_iso8601(ts_str):
    """Parse an ISO 8601 timestamp into a UTC-aware datetime."""
    if ts_str.endswith('Z'):
        ts_str = ts_str[:-1] + '+00:00'

    tz_match = re.search(r'([+-]\d{2}:\d{2})$', ts_str)
    if tz_match:
        offset_str = tz_match.group(1)
        sign = 1 if offset_str[0] == '+' else -1
        hours, minutes = map(int, offset_str[1:].split(':'))
        offset = timedelta(hours=hours, minutes=minutes) * sign
        base = ts_str[:tz_match.start()]

        for fmt in ('%Y-%m-%dT%H:%M:%S.%f', '%Y-%m-%dT%H:%M:%S'):
            try:
                dt_naive = datetime.strptime(base, fmt)
                break
            except ValueError:
                continue
        else:
            return None

        if offset == timedelta(0):
            dt = dt_naive.replace(tzinfo=timezone.utc)
        else:
            dt = dt_naive.replace(tzinfo=timezone(offset))
    else:
        for fmt in ('%Y-%m-%dT%H:%M:%S.%f', '%Y-%m-%dT%H:%M:%S'):
            try:
                dt = datetime.strptime(ts_str, fmt)
                break
            except ValueError:
                continue
        else:
            return None

    return dt.astimezone(timezone.utc)


def parse_json_line(line):
    """Parse a JSON log line."""
    try:
        obj = json.loads(line)
    except (json.JSONDecodeError, ValueError):
        return None

    ts_str = obj.get('ts')
    if not isinstance(ts_str, str):
        return None
    dt = parse_iso8601(ts_str)
    if dt is None:
        return None

    user = obj.get('user', '')
    if not isinstance(user, str):
        return None

    request_id = obj.get('request_id', '')
    if not isinstance(request_id, str):
        return None

    status_raw = obj.get('status')
    try:
        status = int(status_raw)
    except (TypeError, ValueError):
        return None

    latency_raw = obj.get('latency_ms', '')
    if isinstance(latency_raw, (int, float)):
        latency_ms = int(float(latency_raw))
    elif isinstance(latency_raw, str):
        m2 = re.match(r'^(\d+(?:\.\d+)?)\s*ms$', latency_raw.strip())
        if m2:
            latency_ms = int(float(m2.group(1)))
        else:
            try:
                latency_ms = int(float(latency_raw))
            except ValueError:
                return None
    else:
        return None

    return (dt, user.lower(), request_id, status, latency_ms)


def parse_legacy_line(line):
    """Parse a legacy-format log line."""
    m = re.match(
        r'(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z?)'
        r'\s+'
        r'user=(\S+)'
        r'\s+'
        r'req=(\S+)'
        r'\s+'
        r'status=(\S+)'
        r'\s+'
        r'ms=(\S+)',
        line, re.IGNORECASE
    )
    if not m:
        return None

    dt = parse_iso8601(m.group(1))
    if dt is None:
        return None

    user = m.group(2).lower()
    request_id = m.group(3)

    try:
        status = int(m.group(4))
    except ValueError:
        return None

    latency_raw = m.group(5)
    if isinstance(latency_raw, (int, float)):
        latency_ms = int(float(latency_raw))
    elif isinstance(latency_raw, str):
        m2 = re.match(r'^(\d+(?:\.\d+)?)\s*ms$', latency_raw.strip())
        if m2:
            latency_ms = int(float(m2.group(1)))
        else:
            try:
                latency_ms = int(float(latency_raw))
            except ValueError:
                return None
    else:
        return None

    return (dt, user, request_id, status, latency_ms)


def read_lines(filepath):
    """Read lines from a file, handling .gz and truncated gzip gracefully."""
    if filepath.endswith('.gz'):
        yield from _read_gz_lines(filepath)
    else:
        with open(filepath, 'r', errors='replace') as f:
            for line in f:
                stripped = line.rstrip('\n\r')
                if stripped:
                    yield stripped


def _read_gz_lines(filepath):
    """Read a potentially truncated .gz file and yield complete lines."""
    import zlib

    with open(filepath, 'rb') as f:
        raw = f.read()

    decomp = zlib.decompressobj(16 + zlib.MAX_WBITS)
    content = b''
    try:
        pos = 0
        while pos < len(raw):
            chunk = decomp.decompress(raw[pos:pos+4096])
            content += chunk
            pos += 4096
    except zlib.error:
        pass

    text = content.decode('utf-8', errors='replace')

    # Split into lines and only yield complete ones (ending in \n)
    parts = text.split('\n')
    for i, part in enumerate(parts):
        if part.endswith('\r'):
            part = part[:-1]
        if i < len(parts) - 1:
            if part.strip():
                yield part


def is_log_file(name):
    """Check if filename matches app.log, app.log.N or app.log.N.gz pattern."""
    if name == 'app.log':
        return True
    m = re.match(r'^app\.log\.(\d+)$', name)
    if m:
        return int(m.group(1)) > 0
    m = re.match(r'^app\.log\.(\d+)\.gz$', name)
    if m:
        return int(m.group(1)) > 0
    return False


def process_logdir(logdir):
    """Process all log files in the directory and return per-user failure data."""
    best = {}  # request_id -> (dt_utc, user_lower, status, latency_ms)

    for filename in os.listdir(logdir):
        if not is_log_file(filename):
            continue
        filepath = os.path.join(logdir, filename)
        if not os.path.isfile(filepath):
            continue

        for line in read_lines(filepath):
            result = parse_json_line(line) or parse_legacy_line(line)
            if result is None:
                continue

            dt, user, request_id, status, latency_ms = result

            key = request_id
            if key not in best or dt > best[key][0]:
                best[key] = (dt, user, status, latency_ms)

    # Aggregate failures per user
    user_fails = {}  # user -> list of latency_ms values
    for _, (dt, user, status, latency_ms) in best.items():
        if status >= 500:
            if user not in user_fails:
                user_fails[user] = []
            user_fails[user].append(latency_ms)

    # Compute p95 per user using nearest-rank method
    results = []
    for user, latencies in user_fails.items():
        n = len(latencies)
        if n == 0:
            continue
        sorted_lat = sorted(latencies)
        rank = math.ceil(0.95 * n)  # 1-based
        p95 = sorted_lat[rank - 1]  # convert to 0-based index
        results.append((user, n, int(p95)))

    # Sort by failures descending, then user ascending
    results.sort(key=lambda x: (-x[1], x[0]))
    return results


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 p95.py LOGDIR", file=sys.stderr)
        sys.exit(1)

    logdir = sys.argv[1]
    rows = process_logdir(logdir)

    print("user,failures,p95_ms")
    for user, failures, p95 in rows:
        print(f"{user},{failures},{p95}")


if __name__ == '__main__':
    main()
