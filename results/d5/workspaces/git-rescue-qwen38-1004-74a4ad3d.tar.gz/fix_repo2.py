import subprocess, os, sys

REPO = "/workspace/repo"

def git(args, input=None, env=None):
    full_env = dict(os.environ)
    if env:
        full_env.update(env)
    r = subprocess.run(["git"] + list(args), cwd=REPO, capture_output=True, text=True, input=input, env=full_env)
    if r.returncode != 0:
        print(f"CMD FAILED: git {' '.join(args)}\nSTDOUT: {r.stdout}\nSTDERR: {r.stderr}", file=sys.stderr)
        sys.exit(1)
    return r.stdout.strip()

# The old tag v0.1 still exists. Delete it first, then recreate.
git(["tag", "-d", "v0.1"])

# Create annotated tag v0.1 pointing to the new tune parser commit
commit_tune_parser = "eb888235bdcf122470c17cbe9ba00955eb7dda05"
env_tag = {
    "GIT_COMMITTER_NAME": "Dev",
    "GIT_COMMITTER_EMAIL": "dev@example.test",
    "GIT_COMMITTER_DATE": "1791118800 +0000",
}
git(["tag", "-a", "v0.1", "-m", "first release", commit_tune_parser], env=env_tag)
print("tag v0.1 created")

# Verify the tag
tag_sha = git(["rev-parse", "v0.1"])
print(f"tag object: {tag_sha}")
print(git(["cat-file", "-p", tag_sha]))

# Verify refs
print("\nAll refs:")
print(git(["show-ref"]))

# Delete stash
git(["update-ref", "-d", "refs/stash"])
print("\nAfter deleting stash:")
print(git(["show-ref"]))

# Reset index
git(["reset", "--hard", "main"])
print("\nStatus:")
print(git(["status", "--porcelain"]))

# GC
git(["gc", "--prune=now", "--aggressive"])
print("\nAfter gc, all objects:")
r = subprocess.run(["git", "cat-file", "--batch-all-objects", "--batch-check"], cwd=REPO, capture_output=True, text=True)
print(r.stdout)

# Check for tokens
print("\nToken search:")
result = subprocess.run(["git", "rev-list", "--all", "--objects"], cwd=REPO, capture_output=True, text=True)
for line in result.stdout.strip().split("\n"):
    if not line:
        continue
    sha = line.split()[0]
    r = subprocess.run(["git", "cat-file", "-p", sha], cwd=REPO, capture_output=True, text=True)
    if "nwsk_live" in r.stdout:
        print(f"  FOUND TOKEN in {sha}: {line}")
        print(f"  Content: {r.stdout[:200]}")

print("\nDone!")
