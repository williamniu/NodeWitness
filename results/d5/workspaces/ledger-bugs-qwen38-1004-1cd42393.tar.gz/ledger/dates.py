from datetime import datetime, timezone


def parse_ts(text):
    """Parse an ISO 8601 timestamp and convert it to UTC."""
    dt = datetime.fromisoformat(text)
    if dt.tzinfo is None:
        raise ValueError("timestamp must include a timezone offset")
    return dt.astimezone(timezone.utc)


def day_bucket(text):
    """UTC calendar day of a timestamp."""
    return parse_ts(text).strftime("%Y-%m-%d")
