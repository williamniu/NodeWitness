#!/usr/bin/env python3
"""Compute p95 latency of failed requests per user from rotated API logs."""

import csv
import gzip
import io
import math
import os
import re
import sys
import zlib
from datetime import datetime, timezone, timedelta

# ISO 8601 with Z or ±HH:MM offset
ISO_RE = re.compile(
    r'^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})'
    r'(?:\.(\d+))?'
    r'(Z|[+-]\d{2}:\d{2})$'
)

# Legacy line: 2026-11-01T08:00:00Z user=alice req=r1a2b status=503 ms=412
LEGACY_RE = re.compile(
    r'(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2}))\s+'
    r'user=(\S+)\s+'
    r'req=(\S+)\s+'
    r'status=(\S+)\s+'
    r'ms=(\S+)'
)

def parse_iso_ts(ts_str):
    """Parse ISO 8601 timestamp to a datetime (UTC) object."""
    m = ISO_RE.match(ts_str)
    if not m:
        return None
    y, mo, d, h, mi, s = map(int, m.group(1, 2, 3, 4, 5, 6))
    frac = m.group(7)
    tz_part = m.group(8)
    if frac:
        frac = frac[:6].ljust(6, '0')
        micro = int(frac)
    else:
        micro = 0
    if tz_part == 'Z':
        tz = timezone.utc
    else:
        sign = 1 if tz_part[0] == '+' else -1
        hh, mm = int(tz_part[1:3]), int(tz_part[4:6])
        tz = timezone(timedelta(hours=sign * hh, minutes=sign * mm))
    try:
        dt = datetime(y, mo, d, h, mi, s, micro, tzinfo=tz)
    except ValueError:
        return None
    return dt.astimezone(timezone.utc)

def parse_status(val):
    try:
        return int(val)
    except (ValueError, TypeError):
        return None

def parse_latency(val):
    if isinstance(val, (int, float)):
        return val
    s = str(val).strip()
    if s.endswith('ms'):
        s = s[:-2]
    try:
        return float(s)
    except ValueError:
        return None

def read_lines(path):
    """Read lines from a file, handling .gz and truncated gz files."""
    if path.endswith('.gz'):
        # Try normal gzip first
        try:
            with gzip.open(path, 'rt', errors='replace') as f:
                for line in f:
                    yield line.rstrip('\n')
            return
        except (gzip.BadGzipFile, EOFError, OSError):
            pass
        # Fallback: read raw bytes, decompress what we can
        try:
            with open(path, 'rb') as f:
                data = f.read()
            # Try decompressing as gzip (handles header automatically)
            d = zlib.decompressobj(zlib.MAX_WBITS | 16)
            decompressed = d.decompress(data)
            parts = decompressed.split(b'\n')
            for part in parts[:-1]:  # last part may be incomplete
                if part.strip():
                    yield part.decode('utf-8', errors='replace')
        except Exception:
            pass
    else:
        with open(path, 'r', errors='replace') as f:
            for line in f:
                yield line.rstrip('\n')

def parse_json_line(line):
    """Parse a JSON log line. Returns dict or None."""
    try:
        obj = __import__('json').loads(line)
    except Exception:
        return None
    if not isinstance(obj, dict):
        return None
    ts_str = obj.get('ts')
    user = obj.get('user')
    request_id = obj.get('request_id')
    status = obj.get('status')
    latency = obj.get('latency_ms')
    if not all([ts_str, user, request_id, status, latency is not None]):
        return None
    dt = parse_iso_ts(ts_str)
    if dt is None:
        return None
    status_val = parse_status(status)
    if status_val is None:
        return None
    latency_val = parse_latency(latency)
    if latency_val is None:
        return None
    return {
        'dt': dt,
        'user': str(user).lower(),
        'request_id': str(request_id),
        'status': status_val,
        'latency_ms': latency_val,
    }

def parse_legacy_line(line):
    """Parse a legacy-format log line. Returns dict or None."""
    m = LEGACY_RE.match(line)
    if not m:
        return None
    ts_str, user, request_id, status, latency = m.groups()
    dt = parse_iso_ts(ts_str)
    if dt is None:
        return None
    status_val = parse_status(status)
    if status_val is None:
        return None
    latency_val = parse_latency(latency)
    if latency_val is None:
        return None
    return {
        'dt': dt,
        'user': user.lower(),
        'request_id': request_id,
        'status': status_val,
        'latency_ms': latency_val,
    }

def main():
    logdir = sys.argv[1]

    # Collect matching files
    files = []
    for fname in os.listdir(logdir):
        full = os.path.join(logdir, fname)
        if not os.path.isfile(full):
            continue
        if fname == 'app.log':
            files.append(full)
        elif fname.startswith('app.log.'):
            suffix = fname[len('app.log.'):]
            if suffix.endswith('.gz'):
                num = suffix[:-3]
            else:
                num = suffix
            try:
                n = int(num)
                if n > 0:
                    files.append(full)
            except ValueError:
                continue
    files.sort()

    # Parse all entries
    # request_id -> best (latest ts) entry
    best = {}
    for fpath in files:
        for line in read_lines(fpath):
            entry = parse_json_line(line) or parse_legacy_line(line)
            if entry is None:
                continue
            rid = entry['request_id']
            if rid not in best or entry['dt'] > best[rid]['dt']:
                best[rid] = entry

    # Group failures by user
    failures = {}
    for rid, entry in best.items():
        if entry['status'] >= 500:
            user = entry['user']
            failures.setdefault(user, []).append(entry['latency_ms'])

    # Compute p95 per user
    rows = []
    for user, latencies in failures.items():
        n = len(latencies)
        if n == 0:
            continue
        latencies.sort()
        idx = math.ceil(0.95 * n)
        p95 = latencies[idx - 1]
        rows.append((user, n, int(round(p95))))

    # Sort by failures desc, then user asc
    rows.sort(key=lambda r: (-r[1], r[0]))

    # Output CSV with Unix line endings
    buf = io.StringIO()
    writer = csv.writer(buf, lineterminator='\n')
    writer.writerow(['user', 'failures', 'p95_ms'])
    for user, count, p95 in rows:
        writer.writerow([user, count, p95])
    sys.stdout.write(buf.getvalue())

if __name__ == '__main__':
    main()
