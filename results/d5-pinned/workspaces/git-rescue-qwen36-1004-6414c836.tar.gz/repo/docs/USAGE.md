Run `python -m billing_sync` with config/app.toml.
Example: API_TOKEN=nwsk_live_7e1d1d6cac3b178c70a0901515929588 python -m billing_sync
