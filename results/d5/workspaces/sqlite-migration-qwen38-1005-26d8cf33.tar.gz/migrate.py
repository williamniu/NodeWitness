#!/usr/bin/env python3
import sys
import os
import shutil
import sqlite3
import re


AMOUNT_RE = re.compile(
    r'^\s*(?P<sign>[-+]?)'
    r'(?:(?P<paren>\()'
    r'\s*(?P<paren_sign>[-+]?)'
    r'(\$\s*)?'
    r'(?P<num1>\d{1,3}(?:,\d{3})*(?:\.\d{1,2})?|\d+(?:\.\d{1,2})?)'
    r'\s*\)|'
    r'(\$\s*)?'
    r'(?P<num2>\d{1,3}(?:,\d{3})*(?:\.\d{1,2})?|\d+(?:\.\d{1,2})?))'
    r'\s*$'
)


def parse_amount(s):
    if s is None:
        raise ValueError("amount is NULL")
    m = AMOUNT_RE.match(s)
    if not m:
        raise ValueError(f"bad amount: {s!r}")
    int_part = m.group('num1') or m.group('num2')
    int_part = int_part.replace(',', '')
    if '.' in int_part:
        whole, frac = int_part.split('.')
        frac = frac + '0' * (2 - len(frac))
        cents = int(whole) * 100 + int(frac)
    else:
        cents = int(int_part) * 100
    sign = m.group('sign')
    paren_sign = m.group('paren_sign')
    if sign == '-' or paren_sign == '-':
        cents = -cents
    return cents


def parse_name(full_name):
    if full_name is None:
        return '', ''
    words = re.split(r'\s+', full_name.strip())
    if not words:
        return '', ''
    last = words[-1]
    first = ' '.join(words[:-1])
    return first, last


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 migrate.py PATH", file=sys.stderr)
        sys.exit(1)
    path = sys.argv[1]

    conn = sqlite3.connect(path)
    conn.execute("PRAGMA journal_mode=DELETE")
    version = conn.execute("PRAGMA user_version").fetchone()[0]
    if version == 2:
        conn.close()
        return
    if version != 1:
        print(f"Unexpected user_version: {version}", file=sys.stderr)
        conn.close()
        sys.exit(1)

      # Load all data
    users = conn.execute("SELECT id, email, full_name FROM users ORDER BY id").fetchall()
    orders = conn.execute("SELECT id, user_id, amount, created_at FROM orders ORDER BY id").fetchall()
    conn.close()

      # Step 1: Process users
    email_map = {}         # normalized_email -> keeper_user_id
    keeper_info = {}       # keeper_id -> (email, first_name, last_name)
    no_email_user_ids = set()
    dup_to_keeper = {}     # dup_user_id -> keeper_id

    for uid, email, full_name in users:
        if email is None:
            no_email_user_ids.add(uid)
            continue
        norm_email = email.strip().lower()
        if not norm_email:
            no_email_user_ids.add(uid)
            continue

        first, last = parse_name(full_name)

        if norm_email in email_map:
            dup_to_keeper[uid] = email_map[norm_email]
        else:
            email_map[norm_email] = uid
            keeper_info[uid] = (norm_email, first, last)

      # Step 2: Validate all amounts (all-or-nothing)
    for oid, user_id, amount, created_at in orders:
        parse_amount(amount)

      # Step 3: Process orders
    new_orders = []
    for oid, user_id, amount, created_at in orders:
        cents = parse_amount(amount)

        if user_id in no_email_user_ids:
            continue
        if user_id in dup_to_keeper:
            user_id = dup_to_keeper[user_id]
        if user_id not in keeper_info:
            continue

        new_orders.append((oid, user_id, cents, created_at))

      # Step 4: Rewrite database
    conn = sqlite3.connect(path)
    conn.execute("PRAGMA journal_mode=DELETE")

    conn.execute("DROP TABLE IF EXISTS orders")
    conn.execute("DROP TABLE IF EXISTS users")

    conn.execute("""CREATE TABLE users (
        id INTEGER PRIMARY KEY,
        email TEXT NOT NULL UNIQUE,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL
      )""")
    conn.execute("""CREATE TABLE orders (
        id INTEGER PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        amount_cents INTEGER NOT NULL,
        created_at TEXT NOT NULL
      )""")
    conn.execute("CREATE INDEX idx_orders_user_id ON orders(user_id)")

    for uid in sorted(keeper_info.keys()):
        email, first, last = keeper_info[uid]
        conn.execute(
             "INSERT INTO users (id, email, first_name, last_name) VALUES (?, ?, ?, ?)",
             (uid, email, first, last)
         )

    for oid, user_id, cents, created_at in new_orders:
        conn.execute(
             "INSERT INTO orders (id, user_id, amount_cents, created_at) VALUES (?, ?, ?, ?)",
             (oid, user_id, cents, created_at)
         )

    conn.execute("PRAGMA user_version = 2")
    conn.commit()
    conn.close()


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print(f"Migration failed: {e}", file=sys.stderr)
        sys.exit(1)
