from decimal import Decimal, ROUND_HALF_UP


def to_cents(text):
    """Parse a decimal amount string into integer cents.

    Converts with 'half away from zero' rounding.
    """
    text = text.strip()
    d = Decimal(text) * 100
    return int(d.to_integral_value(rounding=ROUND_HALF_UP))


def split(total_cents, n):
    """Split an amount into n near-equal parts.

    Larger parts come first.
    """
    if n < 1:
        raise ValueError("n must be >= 1")
    abs_total = abs(total_cents)
    base = abs_total // n
    remainder = abs_total % n
    abs_parts = [base + 1] * remainder + [base] * (n - remainder)
    if total_cents < 0:
        return [-x for x in abs_parts]
    return abs_parts


def allocate(total_cents, weights):
    """Split an amount in proportion to weights.

    Truncates each share toward zero, then distributes remainder
    to parts with largest fractional parts (ties go to lower index).
    """
    if not weights:
        raise ValueError("weights must not be empty")
    if any(w < 0 for w in weights):
        raise ValueError("weights must be non-negative")
    total_w = sum(weights)
    if total_w == 0:
        raise ValueError("weights must sum to > 0")

    parts = []
    for w in weights:
        num = total_cents * w
        # Truncate toward zero
        floored = num // total_w
        if (num > 0 and total_w > 0) or (num < 0 and total_w < 0):
            # Same sign: floor division = truncation toward zero
            floored = num // total_w
        else:
            # Different signs: need to add 1 if there's a remainder
            floored = num // total_w
            if num % total_w != 0:
                floored += 1
        frac = num - floored * total_w  # remainder, in [0, total_w)
        parts.append((floored, frac))

    # Distribute the remainder: parts with larger frac win (lower index on tie)
    remaining = total_cents - sum(p[0] for p in parts)
    order = sorted(range(len(parts)), key=lambda i: (-parts[i][1], i))
    result = [p[0] for p in parts]
    for i in order:
        if remaining <= 0:
            break
        result[i] += 1
        remaining -= 1

    return result
