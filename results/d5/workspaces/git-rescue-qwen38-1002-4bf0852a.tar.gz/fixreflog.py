import os
os.chdir('/workspace/repo')

mapping = {
 '6d2150765e34dbe003bc397d2908f92a83156289':'6b0d02b9d1cb4311dbffc9cfe9d57c4c579fcd9c',
 'd8e91868c0baea39a6341a18a4577425a71a1d78':'7d366e6884ffd55130c4735b2790aa61ebe20202',
 '9b486dee6386253bfae5e344494224c5e90dad7':'ee35d0c955b92db2ec61b212f06edd2084ab9c7d',
 'd6515f15b79eed0c969cafc8fc5bf351d306bbdf':'2019f0172584aa0296efe7ed0614f280ea69c805',
 '1ca30343d1507a22f776c0aa1b55d2b61ed3c5c0':'b7ec0e47df9a5afb5aa7dd79793f389d9c175466',
}
# fix the 9b key (typo above)
mapping['9b486dee6386253bfae53e344494224c5e90dad7']='ee35d0c955b92db2ec61b212f06edd2084ab9c7d'

def transform(path):
    with open(path) as f:
        lines = f.read().split('\n')
    out=[]
    for ln in lines:
        if ln=='':
            out.append(ln); continue
        # split first two fields (old, new)
        parts = ln.split(' ',2)
        old, new = parts[0], parts[1]
        rest = parts[2] if len(parts)>2 else ''
        old2 = mapping.get(old, old)
        new2 = mapping.get(new, new)
        if rest:
            out.append(old2+' '+new2+' '+rest)
        else:
            out.append(old2+' '+new2)
    with open(path,'w') as f:
        f.write('\n'.join(out))

# main reflog: drop the reset line that references old d6515f1->9b486de
with open('.git/logs/refs/heads/main') as f:
    mainlines = f.read().split('\n')
newmain=[]
for ln in mainlines:
    if ln=='':
        newmain.append(ln); continue
    parts = ln.split(' ',2)
    old,new = parts[0],parts[1]
    rest = parts[2] if len(parts)>2 else ''
    # drop the reset line: old=d6515f1 new=9b486de
    if old=='d6515f15b79eed0c969cafc8fc5bf351d306bbdf' and new=='9b486dee6386253bfae53e344494224c5e90dad7':
        continue
    old2 = mapping.get(old, old)
    new2 = mapping.get(new, new)
    if rest:
        newmain.append(old2+' '+new2+' '+rest)
    else:
        newmain.append(old2+' '+new2)
with open('.git/logs/refs/heads/main','w') as f:
    f.write('\n'.join(newmain))

transform('.git/logs/refs/heads/release/1.x')
transform('.git/logs/HEAD')
print('reflogs transformed')
