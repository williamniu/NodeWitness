from decimal import Decimal, ROUND_HALF_UP, ROUND_FLOOR, ROUND_CEILING


def to_cents(text):
    """Parse a decimal amount string into integer cents."""
    text = text.strip()
    if not _is_valid_amount(text):
        raise ValueError(f"Invalid amount string: {text}")
    return int(Decimal(text).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP) * 100)


def _is_valid_amount(s):
    """Check format: optional sign, one or more digits, optionally '.' followed by one or more digits."""
    if not s:
        return False
    i = 0
    if s[i] in '+-':
        i += 1
    if i >= len(s):
        return False
    while i < len(s) and s[i].isdigit():
        i += 1
    if i < len(s) and s[i] == '.':
        i += 1
        if i >= len(s) or not s[i].isdigit():
            return False
        while i < len(s) and s[i].isdigit():
            i += 1
    return i == len(s)


def split(total_cents, n):
    """Split an amount into n near-equal parts."""
    if n < 1:
        raise ValueError("n must be >= 1")
    sign = (total_cents // abs(total_cents)) if total_cents != 0 else 0
    base = abs(total_cents) // n
    remainder = abs(total_cents) % n
    result = []
    for i in range(n):
        part = base + (1 if i < remainder else 0)
        result.append(part * sign)
    return result


def allocate(total_cents, weights):
    """Split an amount in proportion to weights."""
    if not weights:
        raise ValueError("weights must be non-empty")
    for w in weights:
        if w < 0:
            raise ValueError(f"Negative weight: {w}")
    s = sum(weights)
    if s == 0:
        raise ValueError("Weights must sum to a positive number")

    parts = []
    remainders = []
    for i, w in enumerate(weights):
        exact = Decimal(total_cents) * w / s
        # Truncated toward zero
        trunc = int(exact.to_integral_value(rounding=ROUND_FLOOR)) if exact >= 0 else int(exact.to_integral_value(rounding=ROUND_CEILING))
        parts.append(trunc)
        remainders.append(exact - Decimal(trunc))

    remaining = total_cents - sum(parts)

    # Parts with the largest discarded fractional parts get the extra cents first.
    # On tie, lower index wins.
    order = sorted(range(len(weights)), key=lambda i: (-remainders[i], i))

    for k in range(abs(remaining)):
        if remaining > 0:
            parts[order[k]] += 1
        else:
            parts[order[k]] -= 1

    return parts
