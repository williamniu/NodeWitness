from datetime import datetime, timezone


def parse_ts(text):
    """Parse an ISO 8601 timestamp."""
    # Must have Z or offset; reject bare timestamps
    has_offset = False
    if text.endswith('Z'):
        has_offset = True
        text = text[:-1] + '+00:00'
    elif '+' in text[10:] or (text.count('-') > 2):
        # There's an offset somewhere after the date portion
        has_offset = True

    if not has_offset:
        raise ValueError("timestamp must include Z or a UTC offset")

    return datetime.fromisoformat(text).astimezone(timezone.utc)


def day_bucket(text):
    """UTC calendar day of a timestamp."""
    return parse_ts(text).strftime("%Y-%m-%d")
