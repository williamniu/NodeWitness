from decimal import Decimal, ROUND_HALF_UP, ROUND_DOWN, InvalidOperation


def to_cents(text):
    """Parse a decimal amount string into integer cents.

    Uses Decimal for exact arithmetic.  Rounds half-away-from-zero.
    """
    text = text.strip()
    if not text:
        raise ValueError("empty string")
    try:
        d = Decimal(text)
    except InvalidOperation:
        raise ValueError(f"invalid decimal: {text}")
    rounded = d.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return int(rounded * 100)


def split(total_cents, n):
    """Split an amount into n near-equal parts.

    Parts with the larger absolute value come first.
    Every part has the sign of total_cents (except when total_cents is 0).
    """
    if n < 1:
        raise ValueError("n must be >= 1")
    if total_cents == 0:
        return [0] * n
    sign = 1 if total_cents > 0 else -1
    abs_total = abs(total_cents)
    base = abs_total // n
    remainder = abs_total % n
    result = []
    for i in range(n):
        extra = 1 if i < remainder else 0
        result.append(sign * (base + extra))
    return result


def allocate(total_cents, weights):
    """Split total_cents in proportion to weights (non-negative integers).

    Start from every share truncated toward zero.
    Then give the remaining cents one each to parts with the largest
    discarded fractional parts; on a tie, the lower index wins.
    """
    if not weights:
        raise ValueError("empty weights")
    if any(w < 0 for w in weights):
        raise ValueError("negative weight")
    total_w = sum(weights)
    if total_w == 0:
        raise ValueError("weights sum to zero")

    sign = 1 if total_cents > 0 else (-1 if total_cents < 0 else 0)
    abs_total = abs(total_cents)

    # Exact shares
    parts = []
    remainder = []
    for w in weights:
        if w == 0:
            parts.append(0)
            remainder.append(Decimal('0'))
        else:
            exact = Decimal(abs_total) * w / total_w
            truncated = exact.to_integral_value(rounding=ROUND_DOWN)
            frac = exact - truncated
            parts.append(int(truncated))
            remainder.append(frac)

    # Distribute remaining cents
    leftover = abs_total - sum(parts)
    # Sort indices by (fraction desc, index asc)
    indices = list(range(len(weights)))
    indices.sort(key=lambda i: (-remainder[i], i))
    for i in range(leftover):
        parts[indices[i]] += 1

    # Apply sign
    if sign == 0:
        return [0] * len(weights)
    return [sign * p for p in parts]
