from decimal import Decimal, ROUND_HALF_UP


def to_cents(text):
    """Parse a decimal amount string into integer cents."""
    s = text.strip()
    if not s:
        raise ValueError("invalid amount")
    body = s[1:] if s[0] in "+-" else s
    sign = -1 if s[0] == "-" else 1
    if "." in body:
        int_part, frac_part = body.split(".", 1)
    else:
        int_part, frac_part = body, ""
    if not int_part.isdigit() or not (frac_part.isdigit() or frac_part == ""):
        raise ValueError("invalid amount")
    if int_part == "" and frac_part == "":
        raise ValueError("invalid amount")
    amount = int_part + (("." + frac_part) if frac_part else "")
    cents = Decimal(amount) * 100
    cents = cents.quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return int(sign * cents)


def split(total_cents, n):
    """Split an amount into n near-equal parts."""
    if n < 1:
        raise ValueError("n must be >= 1")
    sign = -1 if total_cents < 0 else 1
    mag = abs(total_cents)
    base, rem = divmod(mag, n)
    parts = [base + 1] * rem + [base] * (n - rem)
    if sign == -1:
        parts = [-p for p in parts]
    return parts


def allocate(total_cents, weights):
    """Split an amount in proportion to weights."""
    if not weights:
        raise ValueError("weights must not be empty")
    total = 0
    for w in weights:
        if w < 0:
            raise ValueError("weights must be non-negative")
        total += w
    if total == 0:
        raise ValueError("weights must sum to a positive value")

    sign = -1 if total_cents < 0 else 1
    mag = abs(total_cents)

    base = []
    fracs = []
    for w in weights:
        num = mag * w
        q, r = divmod(num, total)
        base.append(q)
        fracs.append(r)

    parts = list(base)
    remaining = mag - sum(parts)
    order = sorted(range(len(weights)), key=lambda i: (-fracs[i], i))
    for i in range(remaining):
        parts[order[i]] += 1

    if sign == -1:
        parts = [-p for p in parts]
    return parts
