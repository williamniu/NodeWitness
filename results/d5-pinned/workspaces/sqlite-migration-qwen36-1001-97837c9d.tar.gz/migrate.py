#!/usr/bin/env python3
"""Migrate a SQLite database from schema v1 to v2."""

import re
import shutil
import sqlite3
import sys
import os


def parse_amount(amount_str):
    """Parse amount string and return integer cents, or None if invalid."""
    s = amount_str.strip()
    
    # Check for accounting style: (amount) means negative
    accounting = False
    if s.startswith('(') and s.endswith(')'):
        accounting = True
        s = s[1:-1].strip()
    
    # Check for negative
    negative = False
    if s.startswith('-'):
        negative = True
        s = s[1:].strip()
    
    # Check for optional $ prefix
    if s.startswith('$'):
        s = s[1:].strip()
    
    # Must now be digits with optional commas and up to 2 decimals
    m = re.fullmatch(r'(\d{1,3}(,\d{3})*|\d+)(\.\d{1,2})?', s)
    if not m:
        return None
    
    # Remove commas and convert
    cents_str = s.replace(',', '')
    
    # Parse to cents
    if '.' in cents_str:
        integer_part, decimal_part = cents_str.split('.')
        decimal_part = decimal_part.ljust(2, '0')[:2]
        cents = int(integer_part) * 100 + int(decimal_part)
    else:
        cents = int(cents_str) * 100
    
    if negative or accounting:
        cents = -cents
    
    return cents


def split_name(full_name):
    """Split full_name into (first_name, last_name)."""
    if full_name is None:
        return ('', '')
    
    trimmed = full_name.strip()
    if not trimmed:
        return ('', '')
    
    words = trimmed.split()
    
    if len(words) == 1:
        return (words[0], '')
    else:
        return (' '.join(words[:-1]), words[-1])


def validate_amounts(conn):
    """Validate all amounts. Returns True if all valid."""
    for oid, amount in conn.execute("SELECT id, amount FROM orders"):
        s = amount.strip()
        
        # Check for accounting style
        accounting = False
        if s.startswith('(') and s.endswith(')'):
            accounting = True
            s = s[1:-1].strip()
        
        # Check for negative
        negative = False
        if s.startswith('-'):
            negative = True
            s = s[1:].strip()
        
        # Check for optional $ prefix
        if s.startswith('$'):
            s = s[1:].strip()
        
        # Must be digits with optional commas and up to 2 decimals
        m = re.fullmatch(r'(\d{1,3}(,\d{3})*|\d+)(\.\d{1,2})?', s)
        if not m:
            return False
    return True


def migrate(db_path):
    """Perform the migration."""
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=OFF")
    
    user_version = conn.execute("PRAGMA user_version").fetchone()[0]
    
    if user_version == 2:
        conn.close()
        return
    
    # Validate all amounts before making any changes
    if not validate_amounts(conn):
        conn.close()
        sys.exit(1)
    
    # Make a backup copy of the database file before modifying
    backup_path = db_path + '.migrate_backup'
    shutil.copy2(db_path, backup_path)
    
    try:
        # Read all v1 users
        v1_users = conn.execute("SELECT id, email, full_name FROM users ORDER BY id").fetchall()
        
        # Read all v1 orders
        v1_orders = conn.execute("SELECT id, user_id, amount, created_at FROM orders").fetchall()
        
        # Step 1: Process emails - trim and lowercase, filter out NULL/blank
        valid_users = []
        user_ids_to_keep = set()
        
        for uid, email, full_name in v1_users:
            if email is None:
                continue
            email = email.strip().lower()
            if not email:
                continue
            valid_users.append((uid, email, full_name))
            user_ids_to_keep.add(uid)
        
        # Step 2: Handle duplicate emails - keep user with smallest id
        # For each email, determine which user keeps it (smallest id)
        email_to_target_uid = {}
        uid_to_target_uid = {}  # original uid -> target uid (for users whose email is kept)
        
        for uid, email, full_name in valid_users:
            if email not in email_to_target_uid:
                email_to_target_uid[email] = uid
                uid_to_target_uid[uid] = uid
            else:
                target_uid = email_to_target_uid[email]
                uid_to_target_uid[uid] = target_uid
        
        # Step 3: Build final users list
        # Only keep users whose uid == their target uid (the "winner" of each email group)
        final_users = []
        for uid, email, full_name in valid_users:
            target_uid = uid_to_target_uid[uid]
            if uid == target_uid:
                first_name, last_name = split_name(full_name)
                final_users.append((uid, email, first_name, last_name))
        
        # Step 4: Process orders
        final_orders = []
        for oid, old_user_id, amount_str, created_at in v1_orders:
            # Skip orders whose user_id was deleted (no valid user)
            if old_user_id not in user_ids_to_keep:
                continue
            
            # Reassign orders to the winning user for that email
            target_uid = uid_to_target_uid[old_user_id]
            final_orders.append((oid, target_uid, amount_str, created_at))
        
        # Step 5: Create v2 schema
        conn.execute("DROP TABLE IF EXISTS orders")
        conn.execute("DROP TABLE IF EXISTS users")
        
        conn.execute("""
            CREATE TABLE users(
                id INTEGER PRIMARY KEY,
                email TEXT NOT NULL UNIQUE,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL
            )
        """)
        
        conn.execute("""
            CREATE TABLE orders(
                id INTEGER PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id),
                amount_cents INTEGER NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        
        conn.execute("CREATE INDEX idx_orders_user_id ON orders(user_id)")
        
        # Insert users
        for uid, email, first_name, last_name in final_users:
            conn.execute(
                "INSERT INTO users(id, email, first_name, last_name) VALUES (?, ?, ?, ?)",
                (uid, email, first_name, last_name)
            )
        
        # Insert orders with converted amounts
        for oid, user_id, amount_str, created_at in final_orders:
            cents = parse_amount(amount_str)
            conn.execute(
                "INSERT INTO orders(id, user_id, amount_cents, created_at) VALUES (?, ?, ?, ?)",
                (oid, user_id, cents, created_at)
            )
        
        # Set user_version to 2
        conn.execute("PRAGMA user_version = 2")
        
        conn.commit()
    except SystemExit:
        raise
    except Exception:
        conn.rollback()
        conn.close()
        shutil.copy2(backup_path, db_path)
        os.remove(backup_path)
        raise
    finally:
        conn.close()
        os.remove(backup_path)


def main():
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} PATH", file=sys.stderr)
        sys.exit(1)
    
    db_path = sys.argv[1]
    migrate(db_path)


if __name__ == "__main__":
    main()
