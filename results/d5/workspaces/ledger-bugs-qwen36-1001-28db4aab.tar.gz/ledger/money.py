from decimal import Decimal, ROUND_HALF_UP


def to_cents(text):
    """Parse a decimal amount string into integer cents.

    text is an optional sign, one or more digits, and an optional '.'
    followed by one or more digits.  Surrounding whitespace is allowed.
    Anything else raises ValueError.
    Convert exactly (no binary floating point) and round to whole cents,
    half away from zero.
    """
    text = text.strip()
    # Validate: optional sign, digits, optional dot+digits
    if not text:
        raise ValueError("empty input")

    i = 0
    if text[i] in ('+', '-'):
        i += 1
    if i >= len(text):
        raise ValueError("no digits before decimal point")
    while i < len(text) and text[i].isdigit():
        i += 1
    if i < len(text) and text[i] == '.':
        i += 1
        if i >= len(text) or not text[i].isdigit():
            raise ValueError("no digits after decimal point")
        while i < len(text) and text[i].isdigit():
            i += 1

    if i != len(text):
        raise ValueError(f"unexpected character at position {i}")

    result = Decimal(text).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    return int(result * 100)


def split(total_cents, n):
    """Split total_cents into n near-equal integer parts.

    Parts with the larger absolute value come first.  All non-zero parts
    have the sign of total_cents.
    """
    if n < 1:
        raise ValueError(f"n must be >= 1, got {n}")
    
    # Use abs to compute base part and remainder magnitude
    abs_total = abs(total_cents)
    base = abs_total // n
    remainder = abs_total % n
    
    # Distribute the larger parts first (larger absolute value comes first)
    if total_cents >= 0:
        result = [base + 1] * remainder + [base] * (n - remainder)
    else:
        result = [-(base + 1)] * remainder + [-base] * (n - remainder)
    
    return result


def allocate(total_cents, weights):
    """Split total_cents in proportion to weights.

    Each part's exact share is total_cents * w / sum(weights).  Start from
    every share truncated toward zero.  Then give the cents still missing,
    one each, to the parts with the largest discarded fractional parts; on
    a tie, the lower index wins.
    """
    if not weights:
        raise ValueError("weights must be non-empty")
    if any(w < 0 for w in weights):
        raise ValueError("negative weight encountered")
    total_w = sum(weights)
    if total_w == 0:
        raise ValueError("weights sum to zero")

    n = len(weights)
    
    # Work with absolute value, then apply sign at the end
    abs_total_cents = abs(total_cents)
    exact_abs = [Decimal(abs_total_cents) * w / Decimal(total_w) for w in weights]
    
    # Truncate toward zero (floor for non-negative)
    floored = []
    frac = []  # fractional parts (always non-negative since we work with abs)
    for e in exact_abs:
        f = int(e.to_integral_value(rounding='ROUND_FLOOR'))
        floored.append(f)
        frac.append(e - Decimal(f))
    
    # Residual: what's left to distribute, computed by subtraction to avoid precision issues
    residual_int = abs_total_cents - sum(floored)

    # Sort by (-fraction, index) so largest fraction first, ties broken by lower index
    order = sorted(range(n), key=lambda i: (-frac[i], i))

    result = list(floored)
    for i in range(residual_int):
        result[order[i]] += 1
    
    # Apply original sign
    if total_cents < 0:
        result = [-x for x in result]
    
    return result
