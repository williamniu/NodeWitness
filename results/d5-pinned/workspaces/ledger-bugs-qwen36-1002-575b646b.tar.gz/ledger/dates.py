from datetime import datetime, timezone


def parse_ts(text):
    """Parse an ISO 8601 timestamp and return aware datetime in UTC.

    Accepts 'Z' suffix or ±HH:MM offset.
    Timestamps without any offset raise ValueError.
    """
    text = text.strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    dt = datetime.fromisoformat(text)
    if dt.tzinfo is None:
        raise ValueError("timestamp must have timezone offset")
    utc_dt = dt.astimezone(timezone.utc)
    return utc_dt


def day_bucket(text):
    """UTC calendar day of a timestamp as YYYY-MM-DD."""
    return parse_ts(text).strftime("%Y-%m-%d")
