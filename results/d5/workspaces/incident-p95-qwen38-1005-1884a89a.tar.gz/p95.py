#!/usr/bin/env python3
import sys
import os
import re
import json
import gzip
import zlib
import math
import io
from datetime import datetime, timezone, timedelta


def parse_ts(s):
    """Parse ISO 8601 timestamp with Z or +/-HH:MM offset."""
    s = s.strip()
    if s.endswith('Z'):
        s = s[:-1] + '+00:00'
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        pass
    m = re.match(r'(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(\.\d+)?([+-]\d{2}:\d{2})', s)
    if m:
        base = m.group(1) + (m.group(2) or '')
        fmt = '%Y-%m-%dT%H:%M:%S.%f' if m.group(2) else '%Y-%m-%dT%H:%M:%S'
        dt = datetime.strptime(base, fmt)
        sign = 1 if m.group(3)[0] == '+' else -1
        h = int(m.group(3)[1:3])
        mm = int(m.group(3)[4:6])
        dt = dt.replace(tzinfo=timezone(sign * timedelta(hours=h, minutes=mm)))
        return dt
    return None


def parse_latency(val):
    """Parse latency_ms which can be a number or string like '412ms'."""
    if isinstance(val, (int, float)):
        return int(val)
    if isinstance(val, str):
        m = re.match(r'(\d+)', val)
        if m:
            return int(m.group(1))
    return None


def parse_status(val):
    """Parse status which can be a number or string of digits."""
    if isinstance(val, (int, float)):
        return int(val)
    if isinstance(val, str):
        m = re.match(r'(\d+)', val)
        if m:
            return int(m.group(1))
    return None


def parse_json_line(line):
    """Parse a JSON log line. Returns (ts, user, request_id, status, latency_ms) or None."""
    line = line.strip()
    if not line:
        return None
    try:
        obj = json.loads(line)
    except (json.JSONDecodeError, ValueError):
        return None
    if not isinstance(obj, dict):
        return None
    ts_str = obj.get('ts')
    user = obj.get('user')
    req_id = obj.get('request_id')
    status = obj.get('status')
    latency = obj.get('latency_ms')
    if ts_str is None or user is None or req_id is None or status is None or latency is None:
        return None
    ts = parse_ts(str(ts_str))
    if ts is None:
        return None
    status_int = parse_status(status)
    if status_int is None:
        return None
    latency_int = parse_latency(latency)
    if latency_int is None:
        return None
    return (ts, str(user).lower(), str(req_id), status_int, latency_int)


legacy_re = re.compile(
    r'^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2}))\s+'
    r'user=(\S+)\s+req=(\S+)\s+status=(\S+)\s+ms=(\S+)\s*$'
)


def parse_legacy_line(line):
    """Parse a legacy log line. Returns (ts, user, request_id, status, latency_ms) or None."""
    line = line.strip()
    if not line:
        return None
    m = legacy_re.match(line)
    if not m:
        return None
    ts_str, user, req_id, status_str, latency_str = m.groups()
    ts = parse_ts(ts_str)
    if ts is None:
        return None
    status_int = parse_status(status_str)
    if status_int is None:
        return None
    latency_int = parse_latency(latency_str)
    if latency_int is None:
        return None
    return (ts, user.lower(), req_id, status_int, latency_int)


def parse_line(line):
    """Try JSON first, then legacy. Returns parsed tuple or None."""
    result = parse_json_line(line)
    if result is not None:
        return result
    return parse_legacy_line(line)


def read_lines_from_file(filepath, is_gz=False):
    """Read lines from a file. For gz, handle truncation gracefully.
    Only return complete lines (those that ended in a newline)."""
    if is_gz:
        with open(filepath, 'rb') as f:
            raw = f.read()
        try:
            with gzip.GzipFile(fileobj=io.BytesIO(raw)) as gz:
                data = gz.read()
        except Exception:
            d = zlib.decompressobj(zlib.MAX_WBITS | 16)
            try:
                data = d.decompress(raw)
            except Exception:
                data = b''
            try:
                data += d.flush()
            except Exception:
                pass
        # Split on newline; only keep lines that had a trailing newline
        # If data ends with \n, the last split element is b'' (skip it)
        # If data doesn't end with \n, the last element is incomplete (skip it)
        parts = data.split(b'\n')
        lines = []
        for i, part in enumerate(parts[:-1]):
            lines.append(part.decode('utf-8', errors='replace'))
        return lines
    else:
        lines = []
        with open(filepath, 'r', errors='replace') as f:
            for line in f:
                lines.append(line.rstrip('\n'))
        return lines


def get_log_files(logdir):
    """Get valid log files from the directory."""
    valid_files = []
    for fname in sorted(os.listdir(logdir)):
        if fname == 'app.log':
            valid_files.append((fname, False))
            continue
        m = re.match(r'^app\.log\.(\d+)$', fname)
        if m:
            valid_files.append((fname, False))
            continue
        m = re.match(r'^app\.log\.(\d+)\.gz$', fname)
        if m:
            valid_files.append((fname, True))
            continue
    return valid_files


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 p95.py LOGDIR", file=sys.stderr)
        sys.exit(1)
    logdir = sys.argv[1]

    log_files = get_log_files(logdir)

    # Collect all records: request_id -> (ts, user, status, latency)
    # Keep only the attempt with the latest timestamp per request_id
    best = {}

    for fname, is_gz in log_files:
        filepath = os.path.join(logdir, fname)
        try:
            lines = read_lines_from_file(filepath, is_gz)
        except Exception:
            continue
        for line in lines:
            parsed = parse_line(line)
            if parsed is None:
                continue
            ts, user, req_id, status, latency = parsed
            if req_id not in best:
                best[req_id] = (ts, user, status, latency)
            else:
                old_ts = best[req_id][0]
                if ts > old_ts:
                    best[req_id] = (ts, user, status, latency)

    # For each user, collect failed requests (status >= 500)
    user_failures = {}
    for req_id, (ts, user, status, latency) in best.items():
        if status >= 500:
            if user not in user_failures:
                user_failures[user] = []
            user_failures[user].append(latency)

    # Compute p95 for each user
    results = []
    for user, latencies in user_failures.items():
        n = len(latencies)
        latencies.sort()
        rank = math.ceil(0.95 * n)
        if rank < 1:
            rank = 1
        if rank > n:
            rank = n
        p95 = latencies[rank - 1]
        results.append((user, n, p95))

    # Sort by failures descending, then user ascending
    results.sort(key=lambda x: (-x[1], x[0]))

    # Output
    print("user,failures,p95_ms")
    for user, failures, p95 in results:
        print(f"{user},{failures},{p95}")


if __name__ == '__main__':
    main()
