import re

_CENTS_RE = re.compile(r'^\s*([+-]?)(\d+)(?:\.(\d+))?\s*$')


def to_cents(text):
    """Parse a decimal amount string into integer cents (half away from zero)."""
    if not isinstance(text, str):
        raise ValueError(repr(text))
    m = _CENTS_RE.match(text)
    if not m:
        raise ValueError(repr(text))
    sign_str, intpart, fracpart = m.groups()
    sign = -1 if sign_str == '-' else 1
    total = sign * int(intpart) * 100
    if fracpart:
        frac = int(fracpart)
        if len(fracpart) <= 2:
            extra = frac * 10 ** (2 - len(fracpart))
            total += sign * extra
        else:
            div = 10 ** (len(fracpart) - 2)
            q, r = divmod(frac, div)
            if 2 * r >= div:
                q += 1
            total += sign * q
    return total


def split(total_cents, n):
    """Split an amount into n near-equal parts."""
    if n < 1:
        raise ValueError("n must be >= 1")
    sign = 1
    t = total_cents
    if t < 0:
        sign = -1
        t = -t
    q, r = divmod(t, n)
    parts = [q + 1] * r + [q] * (n - r)
    return [sign * p for p in parts]


def allocate(total_cents, weights):
    """Split an amount in proportion to weights."""
    if not weights:
        raise ValueError("weights must be non-empty")
    for w in weights:
        if w < 0:
            raise ValueError("weights must be non-negative")
    total_w = sum(weights)
    if total_w == 0:
        raise ValueError("weights must sum to a positive value")

    sign = 1
    t = total_cents
    if t < 0:
        sign = -1
        t = -t

    base = [t * w // total_w for w in weights]
    remainder = t - sum(base)

    fracs = []
    for i, w in enumerate(weights):
        num = t * w
        q, r = divmod(num, total_w)
        fracs.append((r, i))

    fracs.sort(key=lambda x: (-x[0], x[1]))

    result = base[:]
    for j in range(remainder):
        result[fracs[j][1]] += 1

    return [sign * p for p in result]
