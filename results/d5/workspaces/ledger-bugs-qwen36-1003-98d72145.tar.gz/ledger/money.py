from decimal import Decimal, ROUND_HALF_UP


def to_cents(text):
    """Parse a decimal amount string into integer cents."""
    text = text.strip()
    d = Decimal(text) * 100
    # Round half away from zero
    if d >= 0:
        return int(d.quantize(Decimal('1'), rounding=ROUND_HALF_UP))
    else:
        return -int((-d).quantize(Decimal('1'), rounding=ROUND_HALF_UP))


def split(total_cents, n):
    """Split an amount into n near-equal parts."""
    if n < 1:
        raise ValueError("n must be >= 1")
    quotient = abs(total_cents) // n
    remainder = abs(total_cents) % n
    # larger absolute value parts first, all with sign of total_cents
    result = []
    for i in range(remainder):
        result.append(-quotient - 1 if total_cents < 0 else quotient + 1)
    for i in range(n - remainder):
        result.append(-quotient if total_cents < 0 else quotient)
    return result


def allocate(total_cents, weights):
    """Split an amount in proportion to weights."""
    if not weights:
        raise ValueError("weights must not be empty")
    if any(w < 0 for w in weights):
        raise ValueError("weights must be non-negative")
    total_w = sum(weights)
    if total_w == 0:
        raise ValueError("weights must sum to > 0")

    n = len(weights)
    # exact share as Decimal
    shares = [Decimal(total_cents) * w / total_w for w in weights]
    # truncated toward zero (toward 0, so -3.5 -> -3, 3.5 -> 3)
    floored = []
    for s in shares:
        if s >= 0:
            floored.append(int(s // 1))
        else:
            # int() truncates toward zero in Python
            floored.append(int(s))

    # Determine which positions need adjustment
    # For positive total_cents: share is like 3.5, floored is 3, need +1 for larger fractions
    # For negative total_cents: share is like -3.5, floored is -3, need -1 for larger fractions
    if total_cents >= 0:
        fracs = [(shares[i] - Decimal(floored[i]), i) for i in range(n)]
        fracs.sort(key=lambda x: (-x[0], x[1]))
        # How many extra cents to distribute
        remaining = total_cents - sum(floored)
        result = list(floored)
        for k in range(remaining):
            result[fracs[k][1]] += 1
    else:
        fracs = [(Decimal(floored[i]) - shares[i], i) for i in range(n)]
        fracs.sort(key=lambda x: (-x[0], x[1]))
        # How many cents to subtract
        remaining = sum(floored) - total_cents
        result = list(floored)
        for k in range(remaining):
            result[fracs[k][1]] -= 1
    return result
