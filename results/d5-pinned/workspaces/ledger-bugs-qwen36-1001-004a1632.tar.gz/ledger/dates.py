from datetime import datetime, timezone, timedelta
import re


def parse_ts(text):
    """Parse an ISO 8601 timestamp, returning an aware datetime in UTC."""
    # Detect if there's a timezone offset
    # Pattern: ends with Z or ±HH:MM
    m = re.search(r'([+-]\d{2}:\d{2})$', text)
    if m:
        offset_str = m.group(1)
        base = text[:m.start()]
        sign = 1 if offset_str[0] == '+' else -1
        hours = int(offset_str[1:3])
        minutes = int(offset_str[4:6])
        offset_hours = sign * hours
        offset_minutes = sign * minutes
    elif text.endswith('Z'):
        base = text[:-1]
        offset_hours = 0
        offset_minutes = 0
    else:
        raise ValueError("Timestamp must have a timezone offset (Z or ±HH:MM)")
    
    dt = datetime.fromisoformat(base)
    tz = timezone(timedelta(hours=offset_hours, minutes=offset_minutes))
    dt = dt.replace(tzinfo=tz)
    # Convert to UTC
    dt_utc = dt.astimezone(timezone.utc)
    return dt_utc


def day_bucket(text):
    """UTC calendar day of a timestamp."""
    return parse_ts(text).strftime("%Y-%m-%d")
