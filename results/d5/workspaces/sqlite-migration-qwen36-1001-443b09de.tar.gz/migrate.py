#!/usr/bin/env python3
"""Migrate a SQLite database from schema v1 to v2."""

import sqlite3
import sys


def parse_amount(amount_str):
    """Parse an amount string and return (cents, sign) or raise ValueError.
    
    Supported formats:
      - '12', '12.5', '7.05'
      - '$1,234.50'
      - '-12.50', '-$1,234.50'
      - '(12.50)', '($12.50)' — accounting style for refunds
    
    Returns (abs_cents, is_negative). Raises ValueError on bad input.
    """
    s = amount_str.strip()
    if not s:
        raise ValueError(f"empty amount string")

    # Detect accounting-style negatives: (...) or ($...)
    is_neg = False
    if s.startswith('(') and s.endswith(')'):
        is_neg = True
        s = s[1:-1]
    else:
        # Check for leading minus sign (after stripping)
        neg_count = 0
        while s and s[0] == '-':
            neg_count += 1
            s = s[1:]
        if neg_count % 2 == 1:
            is_neg = True

    # Strip optional dollar sign
    if s.startswith('$'):
        s = s[1:]
    
    # Remove thousand-separator commas
    s = s.replace(',', '')

    if not s:
        raise ValueError(f"no digits in amount after removing $, commas")

    parts = s.split('.')
    dollars = int(parts[0]) if parts[0] else 0
    
    if len(parts) == 1:
        cents = 0
    elif len(parts) == 2:
        frac_str = parts[1]
        if len(frac_str) > 2:
            raise ValueError(f"too many decimal places in amount")
        frac_str = frac_str.ljust(2, '0')
        cents = int(frac_str)
    else:
        raise ValueError(f"multiple dots in amount")

    total_cents = dollars * 100 + cents
    
    if is_neg:
        return (total_cents, True)
    else:
        return (total_cents, False)


def split_name(full_name):
    """Split full_name into first_name and last_name."""
    if full_name is None:
        return ('', '')
    
    s = full_name.strip()
    if not s:
        return ('', '')
    
    words = s.split()
    if len(words) == 0:
        return ('', '')
    elif len(words) == 1:
        return (words[0], '')
    else:
        return (' '.join(words[:-1]), words[-1])


def migrate(db_path):
    """Migrate database at db_path from v1 to v2 in-place."""
    
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=OFF")
    
    user_version = conn.execute("PRAGMA user_version").fetchone()[0]
    
    if user_version == 2:
        conn.close()
        return
    
    if user_version != 1:
        sys.exit(1)
    
    users = conn.execute("SELECT id, email, full_name FROM users").fetchall()
    orders = conn.execute("SELECT id, user_id, amount, created_at FROM orders").fetchall()
    
    # --- Phase 1: Process users ---
    email_map = {}
    for uid, email, _ in users:
        if email is None:
            continue
        norm = email.strip().lower()
        if not norm:
            continue
        email_map.setdefault(norm, []).append(uid)
    
    kept_users = set()
    orphan_to_keeper = {}  # old_user_id -> keeper_user_id
    
    for norm, cands in email_map.items():
        cands.sort()
        keeper_id = cands[0]
        kept_users.add(keeper_id)
        for uid in cands[1:]:
            orphan_to_keeper[uid] = keeper_id
    
    # --- Phase 2: Parse and validate all amounts ---
    parsed_orders = []
    for oid, uid, amount_str, created_at in orders:
        cents, is_neg = parse_amount(amount_str)
        if is_neg:
            cents = -cents
        parsed_orders.append((oid, uid, cents, created_at))
    
    # --- Phase 3: Build new users list ---
    new_users = []
    for norm in email_map:
        keeper_id = None
        cands = sorted(email_map[norm])
        keeper_id = cands[0]
        fn, ln = split_name(
            next(fn_ for uid_, fn_ in [(u, f) for u, e, f in users if u == keeper_id] if True)
        )
        # Actually let me just look up the full_name directly
        pass
    
    # Let me redo this more cleanly:
    kept_user_info = {}  # keeper_id -> (email_norm, first_name, last_name)
    for norm, cands in email_map.items():
        cands.sort()
        keeper_id = cands[0]
        # Find the full_name of the keeper
        fn = None
        for u, e, f in users:
            if u == keeper_id and e.strip().lower() == norm:
                fn = f
                break
        first, last = split_name(fn)
        kept_user_info[keeper_id] = (norm, first, last)
    
    new_users = []
    for uid in sorted(kept_user_info):
        email_norm, first, last = kept_user_info[uid]
        new_users.append((uid, email_norm, first, last))
    
    # --- Phase 4: Build new orders list ---
    new_orders = []
    for oid, uid, cents, created_at in parsed_orders:
        if uid not in kept_users and uid not in orphan_to_keeper:
            continue  # User had blank/null email -> delete order
        new_uid = orphan_to_keeper.get(uid, uid)
        new_orders.append((oid, new_uid, cents, created_at))
    
    # --- Phase 5: Write changes atomically ---
    conn.execute("BEGIN")
    
    try:
        conn.execute("DROP TABLE IF EXISTS orders")
        conn.execute("DROP TABLE IF EXISTS users")
        
        conn.execute("""
            CREATE TABLE users(
                id INTEGER PRIMARY KEY,
                email TEXT NOT NULL UNIQUE,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE orders(
                id INTEGER PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id),
                amount_cents INTEGER NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        
        conn.execute("CREATE INDEX idx_orders_user_id ON orders(user_id)")
        
        for uid, email, fn, ln in new_users:
            conn.execute(
                "INSERT INTO users(id, email, first_name, last_name) VALUES (?, ?, ?, ?)",
                (uid, email, fn, ln)
            )
        
        for oid, uid, cents, created_at in new_orders:
            conn.execute(
                "INSERT INTO orders(id, user_id, amount_cents, created_at) VALUES (?, ?, ?, ?)",
                (oid, uid, cents, created_at)
            )
        
        conn.execute("PRAGMA user_version = 2")
        conn.commit()
    except:
        conn.rollback()
        raise
    
    conn.close()


def main():
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} PATH", file=sys.stderr)
        sys.exit(1)
    
    migrate(sys.argv[1])


if __name__ == '__main__':
    main()
