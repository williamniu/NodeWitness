import subprocess, os, sys

REPO = "/workspace/repo"

def git(args, input=None, env=None):
    full_env = dict(os.environ)
    if env:
        full_env.update(env)
    r = subprocess.run(["git"] + list(args), cwd=REPO, capture_output=True, text=True, input=input, env=full_env)
    if r.returncode != 0:
        print(f"CMD FAILED: git {' '.join(args)}\nSTDOUT: {r.stdout}\nSTDERR: {r.stderr}", file=sys.stderr)
        sys.exit(1)
    return r.stdout.strip()

# The new commits from the first run
commit_add_config = "06ba648683854a9d1678ddcc07d9bdbced248e28"
commit_tune_parser = "eb888235bdcf122470c17cbe9ba00955eb7dda05"
commit_add_usage = "2e585f9a612f650fc15eaf7ade7561374fea98ff"
commit_hotfix = "e62d1c059f224fc88471a190b1a83726799fcc35"
commit_feature = "d792c3478ff56d72acf956a49f8db5c68d196a80"

# Update refs
git(["update-ref", "refs/heads/main", commit_feature])
git(["update-ref", "refs/heads/release/1.x", commit_hotfix])
git(["update-ref", "-d", "refs/heads/backup/pre-cleanup"])
print("Refs updated")
print(git(["show-ref"]))

# Set HEAD to main
git(["symbolic-ref", "HEAD", "refs/heads/main"])

# Reset index to match main
git(["reset", "--hard", "main"])
print("\nStatus:")
print(git(["status", "--porcelain"]))

# Verify main log
print("\nmain log:")
print(git(["log", "--oneline", "main"]))
print("\nrelease/1.x log:")
print(git(["log", "--oneline", "release/1.x"]))

# Verify tag
print("\ntag v0.1:")
print(git(["cat-file", "-p", "v0.1"]))
print(f"tag target: {git(['rev-parse', 'v0.1^{{commit}}'])}")
print(f"tune parser: {commit_tune_parser}")

