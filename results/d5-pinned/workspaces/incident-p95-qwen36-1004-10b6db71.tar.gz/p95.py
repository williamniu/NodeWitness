#!/usr/bin/env python3
"""Incident report: failed-request p95 per user."""

import sys
import os
import re
import gzip
import json
import math
import zlib
from datetime import datetime, timezone, timedelta
from collections import defaultdict


def parse_iso_ts(ts_str):
    """Parse an ISO 8601 timestamp string into a UTC datetime."""
    if ts_str.endswith('Z'):
        ts_str = ts_str[:-1] + '+00:00'
    dt = datetime.fromisoformat(ts_str)
    return dt.astimezone(timezone.utc)


def parse_latency_ms(lat_val):
    """Parse latency_ms value which can be int, float, or string like '412ms'."""
    if isinstance(lat_val, (int, float)):
        return lat_val
    s = str(lat_val).strip()
    if s.endswith('ms'):
        s = s[:-2]
    return float(s)


def parse_status(status_val):
    """Parse status value which can be int or string of digits."""
    if isinstance(status_val, (int, float)):
        return int(status_val)
    return int(str(status_val).strip())


def parse_json_line(line):
    """Try to parse a JSON log line. Returns (ts, user, request_id, status, latency_ms) or None."""
    try:
        obj = json.loads(line)
    except json.JSONDecodeError:
        return None
    ts_str = obj.get('ts')
    user = obj.get('user')
    req_id = obj.get('request_id')
    status = obj.get('status')
    latency = obj.get('latency_ms')
    if ts_str is None or user is None or req_id is None or status is None or latency is None:
        return None
    try:
        ts = parse_iso_ts(str(ts_str))
    except (ValueError, TypeError):
        return None
    return (ts, user.lower(), str(req_id), parse_status(status), parse_latency_ms(latency))


# Legacy format: 2026-11-01T08:00:00Z user=alice req=r1a2b status=503 ms=412
LEGACY_RE = re.compile(
    r'^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2}))\s+'
    r'user=(\S+)\s+'
    r'req=(\S+)\s+'
    r'status=(\S+)\s+'
    r'ms=(\S+)\s*$'
)


def parse_legacy_line(line):
    """Try to parse a legacy log line. Returns (ts, user, request_id, status, latency_ms) or None."""
    m = LEGACY_RE.match(line)
    if not m:
        return None
    ts_str, user, req_id, status_str, ms_str = m.groups()
    try:
        ts = parse_iso_ts(ts_str)
    except (ValueError, TypeError):
        return None
    return (ts, user.lower(), req_id, parse_status(status_str), parse_latency_ms(ms_str))


def parse_line(line):
    """Parse a single log line. Returns (ts, user, request_id, status, latency_ms) or None."""
    line = line.strip()
    if not line:
        return None
    result = parse_json_line(line)
    if result:
        return result
    return parse_legacy_line(line)


def get_log_files(logdir):
    """Return list of (filepath, is_gz) for valid log files."""
    result = []
    for name in os.listdir(logdir):
        filepath = os.path.join(logdir, name)
        if not os.path.isfile(filepath):
            continue
        if name == 'app.log':
            result.append((filepath, False))
        elif name.startswith('app.log.'):
            suffix = name[len('app.log.'):]
            if suffix.endswith('.gz'):
                num_str = suffix[:-3]
                if num_str.isdigit() and int(num_str) > 0:
                    result.append((filepath, True))
            else:
                if suffix.isdigit() and int(suffix) > 0:
                    result.append((filepath, False))
    return result


def read_lines(filepath, is_gz):
    """Read complete lines from a file, handling gzip truncation gracefully."""
    if is_gz:
        try:
            with open(filepath, 'rb') as f:
                raw = f.read()
            if len(raw) < 2 or raw[:2] != b'\x1f\x8b':
                return []
            dc = zlib.decompressobj(47)
            decompressed = dc.decompress(raw)
            text = decompressed.decode('utf-8', errors='replace')
        except (zlib.error, OSError):
            return []
        lines = text.split('\n')
        # Return only complete lines (those ending in newline)
        return [l for l in lines[:-1] if l.strip()]
    else:
        with open(filepath, 'r', errors='replace') as f:
            return [line for line in f.readlines() if line.strip()]


def compute_p95(values):
    """Compute p95 using nearest-rank: sort ascending, take element ceil(0.95 * n) (1-based)."""
    values = sorted(values)
    n = len(values)
    rank = math.ceil(0.95 * n)
    return values[rank - 1]  # Convert to 0-based


def main():
    if len(sys.argv) != 2:
        print("Usage: p95.py LOGDIR", file=sys.stderr)
        sys.exit(1)

    logdir = sys.argv[1]
    if not os.path.isdir(logdir):
        print(f"{logdir} is not a directory", file=sys.stderr)
        sys.exit(1)

    # Collect all log files
    files = get_log_files(logdir)

    # For each request_id, keep only the attempt with the latest timestamp
    request_map = {}

    for filepath, is_gz in files:
        lines = read_lines(filepath, is_gz)
        for line in lines:
            parsed = parse_line(line)
            if parsed is None:
                continue
            ts, user, req_id, status, latency_ms = parsed
            if req_id not in request_map or ts > request_map[req_id][0]:
                request_map[req_id] = (ts, user, status, latency_ms)

    # Find failed requests (status >= 500) and group by user
    user_failures = defaultdict(list)
    for req_id, (ts, user, status, latency_ms) in request_map.items():
        if status >= 500:
            user_failures[user].append(latency_ms)

    # Compute p95 for each user with failures
    results = []
    for user, latencies in user_failures.items():
        if len(latencies) == 0:
            continue
        failures = len(latencies)
        p95 = compute_p95(latencies)
        results.append((user, failures, int(p95)))

    # Sort by failures descending, then user ascending
    results.sort(key=lambda x: (-x[1], x[0]))

    # Output CSV
    print("user,failures,p95_ms")
    for user, failures, p95 in results:
        print(f"{user},{failures},{p95}")


if __name__ == '__main__':
    main()
