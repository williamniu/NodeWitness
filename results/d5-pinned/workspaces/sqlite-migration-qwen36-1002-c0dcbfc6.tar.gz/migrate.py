#!/usr/bin/env python3
"""Migrate a v1 SQLite database to v2 schema."""
import sys
import sqlite3
import re


def parse_amount(raw: str) -> int | None:
    """Parse an amount string into integer cents. Return None on failure."""
    s = raw.strip()
    if not s:
        return None

    sign = 1
    remaining = s

    # Check for accounting-style (negative): ($1,234.50) or (12.50)
    if remaining.startswith('(') and remaining.endswith(')'):
        sign = -1
        remaining = remaining[1:-1].strip()
        if remaining.startswith('$'):
            remaining = remaining[1:].strip()

    # Check for explicit negative sign
    if remaining.startswith('-'):
        sign = -1
        remaining = remaining[1:].strip()

    # Check for explicit positive sign
    if remaining.startswith('+'):
        remaining = remaining[1:].strip()

    # Remove leading $
    if remaining.startswith('$'):
        remaining = remaining[1:].strip()

    # Validate: digits with optional commas and up to two decimal places
    m = re.fullmatch(r'(\d+)(,?\d{3})*(?:\.\d{1,2})?', remaining)
    if not m:
        return None

    # Remove commas and convert
    cleaned = remaining.replace(',', '')
    if '.' in cleaned:
        dollars, frac = cleaned.split('.')
        frac_padded = frac.ljust(2, '0')
        cents = int(dollars) * 100 + int(frac_padded)
    else:
        cents = int(cleaned) * 100

    return sign * cents


def split_full_name(full_name: str | None) -> tuple[str, str]:
    """Split full_name into (first_name, last_name)."""
    if not full_name or not full_name.strip():
        return ('', '')
    # Trim and collapse whitespace
    s = ' '.join(full_name.strip().split())
    words = s.split()
    if not words:
        return ('', '')
    # Last word is last_name; everything before is first_name
    last_name = words[-1]
    first_name = ' '.join(words[:-1]) if len(words) > 1 else ''
    return (first_name, last_name)


def main():
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} PATH", file=sys.stderr)
        sys.exit(1)

    db_path = sys.argv[1]

    # Read the database into memory first for validation
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row

    # Check version
    v = conn.execute("PRAGMA user_version").fetchone()[0]
    if v == 2:
        conn.close()
        sys.exit(0)  # Already v2, nothing to do
    if v != 1:
        print(f"Expected v1 database, got version {v}", file=sys.stderr)
        conn.close()
        sys.exit(1)

    # Read all users
    users = conn.execute("SELECT id, email, full_name FROM users ORDER BY id").fetchall()

    # Read all orders
    orders = conn.execute("SELECT id, user_id, amount, created_at FROM orders").fetchall()

    # Build a set of valid user ids (before any processing)
    valid_user_ids = set(u['id'] for u in users)

    # Process users: trim/lower email, delete if blank
    # Build mapping: cleaned_email -> list of (id, full_name)
    email_to_users: dict[str, list[tuple[int, str | None]]] = {}
    for u in users:
        raw_email = u['email']
        if raw_email is not None:
            email = raw_email.strip().lower()
        else:
            email = ''

        if not email:
            # User has no valid email - will be deleted
            continue

        if email not in email_to_users:
            email_to_users[email] = []
        email_to_users[email].append((u['id'], u['full_name']))

    # For duplicate emails, keep smallest id, move orders to that user
    # Build final users dict: cleaned_email -> (first_name, last_name)
    new_users: dict[str, tuple[str, str]] = {}
    # Map: original user id -> new email (for dedup)
    user_id_to_email: dict[int, str] = {}
    for email, user_list in email_to_users.items():
        user_list.sort(key=lambda x: x[0])
        winner = user_list[0]  # (id, full_name) with smallest id
        winner_name = split_full_name(winner[1])
        new_users[email] = winner_name
        for uid, _ in user_list:
            user_id_to_email[uid] = email

    # Parse all amounts first - if any fail, exit with error without modifying DB
    parsed_orders: list[tuple[int, int, int, str]] = []  # (id, user_id, amount_cents, created_at)
    for o in orders:
        cents = parse_amount(o['amount'])
        if cents is None:
            conn.close()
            sys.exit(1)
        parsed_orders.append((o['id'], o['user_id'], cents, o['created_at']))

    # Process orders:
    # - Keep only those whose user_id is in valid_user_ids
    # - Map user_id to the deduped email's target user
    new_orders: list[tuple[int, int, int, str]] = []
    for oid, uid, cents, created_at in parsed_orders:
        if uid not in valid_user_ids:
            continue  # Delete orders whose user doesn't exist
        target_email = user_id_to_email.get(uid)
        if target_email is None:
            continue  # User was deleted (no valid email)
        new_orders.append((oid, target_email, cents, created_at))

    conn.close()

    # Now apply changes to the database
    conn = sqlite3.connect(db_path)

    # Create v2 schema
    conn.execute("DROP TABLE IF EXISTS orders_v2")
    conn.execute("DROP TABLE IF EXISTS users_v2")
    conn.execute("DROP TABLE IF EXISTS orders")
    conn.execute("DROP TABLE IF EXISTS users")

    conn.execute("""
        CREATE TABLE users(
            id INTEGER PRIMARY KEY,
            email TEXT NOT NULL UNIQUE,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE orders(
            id INTEGER PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id),
            amount_cents INTEGER NOT NULL,
            created_at TEXT NOT NULL
        )
    """)

    conn.execute("CREATE INDEX idx_orders_user_id ON orders(user_id)")

    # Insert new users - we need to assign new sequential ids
    emails_sorted = sorted(new_users.keys())
    for i, email in enumerate(emails_sorted, start=1):
        first, last = new_users[email]
        conn.execute("INSERT INTO users (id, email, first_name, last_name) VALUES (?, ?, ?, ?)",
                     (i, email, first, last))

    # Build user_id lookup: email -> new id
    email_to_new_id = {}
    for new_id, email in enumerate(emails_sorted, start=1):
        email_to_new_id[email] = new_id

    # Insert orders
    for oid, email, cents, created_at in new_orders:
        new_uid = email_to_new_id[email]
        conn.execute("INSERT INTO orders (id, user_id, amount_cents, created_at) VALUES (?, ?, ?, ?)",
                     (oid, new_uid, cents, created_at))

    conn.execute("PRAGMA user_version = 2")
    conn.commit()
    conn.close()


if __name__ == '__main__':
    main()
