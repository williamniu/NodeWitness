#!/usr/bin/env python3
"""Migrate app.db from schema v1 to v2."""
import re
import sqlite3
import sys


def parse_amount(amount_str):
    """Parse amount string and return integer cents, or None if invalid.

    Supported formats:
      12, 12.5, 12.50 -> 1200, 1250, 1250
      $1,234.50 -> 123450
      -12.50, -$12.50 -> -1250
      ($12.50) -> -1250 (accounting style)
    """
    s = amount_str.strip()
    if not s:
        return None

    negative = False

    # Accounting style: (amount)
    if s.startswith('(') and s.endswith(')'):
        negative = True
        s = s[1:-1].strip()
        if not s:
            return None

    # Handle leading minus sign
    if s.startswith('-'):
        negative = True
        s = s[1:].strip()
        if not s:
            return None
    elif s.startswith('+'):
        s = s[1:].strip()
        if not s:
            return None

    # Handle leading $
    if s.startswith('$'):
        s = s[1:]

    # Remove commas (thousands separators)
    s = s.replace(',', '')

    # Parse decimal part
    parts = s.split('.')
    if len(parts) > 2:
        return None  # too many dots
    integer_part = parts[0] or '0'
    decimal_part = parts[1] if len(parts) == 2 else ''

    if not integer_part.isdigit():
        return None

    if len(decimal_part) > 2:
        return None

    # Pad decimal to exactly 2 digits
    if len(decimal_part) == 0:
        cents = int(integer_part) * 100
    elif len(decimal_part) == 1:
        cents = int(integer_part) * 100 + int(decimal_part) * 10
    else:
        cents = int(integer_part) * 100 + int(decimal_part[:2])

    if negative:
        cents = -cents

    return cents


def split_name(full_name):
    """Split full_name into (first_name, last_name)."""
    if not full_name or not full_name.strip():
        return ('', '')

    words = re.split(r'\s+', full_name.strip())
    if len(words) == 0:
        return ('', '')
    elif len(words) == 1:
        return (words[0], '')
    else:
        return (' '.join(words[:-1]), words[-1])


def main():
    path = sys.argv[1]

    # Open database and read v1 data
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row

    user_version = conn.execute("PRAGMA user_version").fetchone()[0]
    if user_version == 2:
        conn.close()
        return  # already migrated, nothing to do

    if user_version != 1:
        print(f"Expected v1 database, got {user_version}", file=sys.stderr)
        sys.exit(1)

    users = conn.execute("SELECT id, email, full_name FROM users ORDER BY id").fetchall()
    orders = conn.execute("SELECT id, user_id, amount, created_at FROM orders ORDER BY id").fetchall()

    # Validate all amounts before doing anything (rule 7: all or nothing)
    for order in orders:
        if parse_amount(order['amount']) is None:
            print(f"Invalid amount: {order['amount']!r}", file=sys.stderr)
            conn.close()
            sys.exit(1)

    # Phase 1: Process emails and users
    valid_users = {}  # normalized_email -> first user row seen (smallest id since ordered by id)
    for u in users:
        email = u['email']
        if email is None or not email.strip():
            continue  # skip users with NULL/blank email

        email_lower = email.strip().lower()
        if email_lower not in valid_users:
            valid_users[email_lower] = u

    kept_user_ids = {u['id'] for u in valid_users.values()}

    # Phase 2: Process orders - collect those that should be kept (valid user_id) or moved
    new_orders = []  # list of (orig_id, new_user_id, cents, created_at)
    orphan_orders = []  # orders from deleted users whose email matches a valid email

    for o in orders:
        orig_uid = o['user_id']
        if orig_uid not in kept_user_ids:
            # Check if the original user was removed (blank/NULL email) but has a valid email match
            orig_user = None
            for u in users:
                if u['id'] == orig_uid:
                    orig_user = u
                    break

            if orig_user and orig_user['email']:
                email_lower = orig_user['email'].strip().lower()
                if email_lower in valid_users:
                    # Assign to the kept user with this email (smallest id)
                    new_orders.append((o['id'], valid_users[email_lower]['id'], parse_amount(o['amount']), o['created_at']))
            # else: truly orphaned order, delete it
        else:
            # Valid user - keep the order as-is
            new_orders.append((o['id'], orig_uid, parse_amount(o['amount']), o['created_at']))

    # Phase 3: Build output users mapping
    output_users = {}  # normalized_email -> (orig_id, first_name, last_name)
    for email_lower, u in valid_users.items():
        fn, ln = split_name(u['full_name'])
        output_users[email_lower] = (u['id'], fn, ln)

    conn.close()
    conn = sqlite3.connect(path)
    c = conn.cursor()

    # Drop old tables and recreate v2 schema
    c.execute("DROP TABLE IF EXISTS orders")
    c.execute("DROP TABLE IF EXISTS users")

    c.execute("""
        CREATE TABLE users(
            id INTEGER PRIMARY KEY,
            email TEXT NOT NULL UNIQUE,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL
        )
    """)
    c.execute("""
        CREATE TABLE orders(
            id INTEGER PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id),
            amount_cents INTEGER NOT NULL,
            created_at TEXT NOT NULL
        )
    """)
    c.execute("CREATE INDEX idx_orders_user_id ON orders(user_id)")

    # Insert new users
    for email_lower, (orig_id, first_name, last_name) in output_users.items():
        c.execute(
            "INSERT INTO users(id, email, first_name, last_name) VALUES (?, ?, ?, ?)",
            (orig_id, email_lower, first_name, last_name),
        )

    # Insert new orders
    for orig_id, new_uid, cents, created_at in new_orders:
        c.execute(
            "INSERT INTO orders(id, user_id, amount_cents, created_at) VALUES (?, ?, ?, ?)",
            (orig_id, new_uid, cents, created_at),
        )

    # Set user_version to 2
    c.execute("PRAGMA user_version = 2")
    conn.commit()
    conn.close()


if __name__ == '__main__':
    main()
